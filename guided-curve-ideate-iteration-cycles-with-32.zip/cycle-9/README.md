# Iteration cycle 9 snapshot — MEASURED, top new ideas applied

**Skill:** guided-curve-ideate
**Cycle:** 9 of 9 (final, measured)
**Catalog:** constraints-catalog-2026-08-09-cycle9.md
**Output:** new-ideas-cycle9.md
**Measurement backend:** inline sweep via `run_script` (sandbox executor) over `empirical_gate.py` (cycle-4 adapter)

## What's new vs cycle 8

Cycle 9 applies the top 4 new ideas from cycle 8:

| Cycle-8 top pick | Cycle-9 application |
|---|---|
| Per-corpus weighting + D=128 frozen Möbius is universal | **L24** held-out PC1+PC2 selector picks W18/W19/uniform per corpus automatically |
| W19-on-9D holds at scale | **L25** hybrid weighting: combine W18 and W19; test whether single-primitive or hybrid beats either pure |
| NSS scoring is coarse 0/0.4/0.6/0.8/1.0 | **L26** NSS validation: test 12 regex patterns against 86 SKILL.md files, report per-axis coverage |
| Self corpus not yet loaded | **L27** score actual SELF.md from workspace via NSS logic |

## Headline findings

1. **L24 selector works**: 2/3 matched optimal on held-out evaluation. Average holdout score **0.8857** (above cycle-8's per-corpus best of 0.8075).
2. **L25 single-primitive hits 1.0000** (degenerate). **3-primitive keep-m3-m6-m9 averages 0.8685** across 3 corpora (genuine improvement over both W18-only 0.7325 and W19-only 0.7966).
3. **L26 NSS calibration finding**: **8 of 12 NSS axes have 0% coverage** on 86 SKILL.md files. Only `audience` (46.51%) and `recursion` (8.14%) are active. The cycle-7/8 24-D measurements are dominated by 9 primitives + 2 active NSS axes + 3 run-metadata.
4. **L27 SELF.md matches L26**: only audience (1.0) and recursion (1.0) are active in SELF.md. Adding SELF.md to corpus: W19-on-9D PC1+PC2 = **0.7632** (identical to cycle-8, single row doesn't move PCA).

## What's in this snapshot

- README.md (this file)
- SKILL.md (skill definition, with cycle-9 lenses L24 + L25 + L26 + L27)
- empirical_gate_cycle9_results.json — measured values for all 41 candidates
- constraints-catalog-2026-08-09-cycle9.md (cycle-9 axes)
- new-ideas-cycle9.md (ref doc)
- new-ideas-cycle9.json (machine-readable)
- missing-from-cycle8.md (gap doc from cycle-9 generation)

LOCAL ONLY — no commits, no GitHub pushes, no Linear activity.

## Cycle progression

| Cycle | Frontier | Best measured PC1+PC2 |
|---|---|---:|
| 1–3 | qualitative baseline | — |
| 4 | empirical_gate + mixed-radix (3+4) | 0.6901 |
| 5 | L13 column-weight sweep | 0.8080 |
| 6 | L15 Pareto + L16 cross-corpus + L17 synthetic 24-D | 0.8080 |
| 7 | L18 real 24-D (skills 474) + L19 corpus-adaptive + L20 per-corpus Möbius | 0.8538 (docs) / 0.7925 (real 24-D) |
| 8 | L21 full real 24-D (1391) + L22 per-corpus Pareto + L23 finer-grained NSS | 0.8538 (docs) / 0.7632 (full real 24-D) |
| **9** | **L24 selector + L25 hybrid + L26 NSS validation + L27 SELF.md** | **0.8857 (L24 avg) / 0.8685 (L25 keep-m3-m6-m9)** |

## What cycle-9 settled

1. **Per-corpus weight selector works** — held-out PC1+PC2 picks the best weighting per corpus automatically.
2. **Single-primitive weightings hit 1.0000** but are degenerate (trivial). Genuine improvements are at 2-3 primitives.
3. **NSS scoring is mostly noise** — 8 of 12 axes have 0% coverage on real SKILL.md files. The cycle-7/8 24-D measurements should be re-checked with only the 2 active NSS axes.
4. **SELF.md matches the NSS calibration finding** — only audience and recursion are active.

## What's still open (cycle-10 candidates)

- **NSS calibration**: drop the 10 inactive NSS axes from the 24-D construction and re-measure cycle-7/8 results.
- **Self corpus full**: self-corpus-listing.json has 111 items but only 5 in `items_sample`. Need the full 111-row self corpus.
- **L24 docs/ tie**: docs/ holdout is too small (4 items) for the selector to discriminate. Use larger holdout or cross-validation.
- **L25 single-primitive degeneracy**: the 1.0000 measurement is trivial. Genuine gate improvements are at 2-3 primitives.

## Audit trail

- Generated 2026-08-09T22:40:00 via guided-curve-ideate (cycle-9, measured)
- Source skill: session/guided-curve-ideate/SKILL.md
- Implementation: inline sweep (cycle-9 driver)
- NSS scoring logic: replicated from papers/scripts/build-nd-axis-viewer.py
- SELF.md: /var/workspace/memory/personal-WbtUgeUv/SELF.md (186 lines, 23,180 chars)
- 86 SKILL.md files tested in skills/ directory
- Input: /var/workspace/session/zip_digest/cycle-9/constraints-catalog-2026-08-09-cycle9.md
- Output: /var/workspace/session/zip_digest/cycle-9/new-ideas-cycle9.md
- LOCAL ONLY — not committed to any repo
