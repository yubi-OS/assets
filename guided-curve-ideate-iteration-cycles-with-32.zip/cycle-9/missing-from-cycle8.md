# What's missing from cycle 8 — and how cycle 9 addresses it

## Gaps in cycle 8

1. **Per-corpus weight selection was manual.** Cycle-8 L22 found W18 for skills, W19 for docs/refs, but the selection logic was external. No automated selector.
2. **W18+W19 hybrid weighting untested.** Cycle-8 used pure W18 or pure W19. No test of whether a hybrid (e.g., keep-m3-m6-m9) beats either pure.
3. **NSS scoring validation missing.** Cycle-8 used NSS scoring from `build-nd-axis-viewer.py` but didn't validate whether the 12 regex patterns actually fire on real SKILL.md files.
4. **Self corpus not yet loaded.** Cycle-8 used skills (474) + docs (126) + refs (791) = 1391 rows. Self corpus (~895 rows per main paper) not loaded.

## Cycle-9 fix

| Gap | Cycle-9 fix |
|---|---|
| Manual per-corpus weight selection | **L24** held-out PC1+PC2 selector: split 80/20, measure on train, pick best, verify on holdout. 2/3 matched optimal. Average holdout 0.8857. |
| Hybrid weighting untested | **L25** 12 hybrid candidates × 3 corpora = 36 measurements. Found single-primitive hits 1.0000 (degenerate); 3-primitive keep-m3-m6-m9 averages 0.8685 (genuine improvement). |
| NSS scoring validation | **L26** test 12 regex patterns against 86 SKILL.md files. **Found 8 of 12 axes have 0% coverage.** Only audience (46.51%) and recursion (8.14%) are active. |
| Self corpus not loaded | **L27** score actual SELF.md from /var/workspace/memory/personal-WbtUgeUv/SELF.md via NSS logic, add to 24-D matrix. SELF.md: only audience (1.0) and recursion (1.0) are active. Adding SELF.md doesn't move PCA (single row effect). |

## What cycle-9 still doesn't address (open for cycle 10)

1. **NSS calibration.** 8 of 12 NSS axes have 0% coverage. Cycle-7/8 24-D measurements should be re-checked with only the 2 active NSS axes (audience, recursion). If the gate still holds, cycle-7/8 findings are robust to the 10 inactive axes.
2. **Self corpus full.** self-corpus-listing.json has 111 items but only 5 in `items_sample`. The full self corpus would add ~106 more rows, reaching ~1497 total (vs the main paper's 2286).
3. **L24 docs/ tie.** docs/ holdout is only 4 items (21 × 20% = 4.2). The selector can't discriminate when all 3 weightings hit 1.0 on a tiny holdout. Cycle-10 should use a larger holdout or cross-validation.
4. **L25 single-primitive degeneracy.** The 1.0000 measurement is trivial (no noise to spread variance). Genuine gate improvements are at 2-3 primitives. Cycle-10 should characterize the signal-to-noise ratio per primitive count.

## Cycle-10 candidate lenses

- **L28 — NSS calibration**: drop 10 inactive NSS axes from 24-D construction, re-measure cycle-7/8 results.
- **L29 — Self corpus full**: locate and load full self corpus (111 items), re-measure full 24-D.
- **L30 — L24 cross-validation**: use k-fold CV instead of single 80/20 split, especially for docs/.
- **L31 — Signal-to-noise per primitive count**: characterize when gate measurement is meaningful (≥2 non-degenerate primitives).

These are the cycle-10 lenses if the user wants another iteration.
