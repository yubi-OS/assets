# New Ideas — guided-curve-ideate output (2026-08-09, cycle 9 — MEASURED, top-new-ideas applied)

**Source skill:** `guided-curve-ideate` (LOCAL ONLY, not committed)
**Input catalog:** `/var/workspace/session/zip_digest/cycle-9/constraints-catalog-2026-08-09-cycle9.md`
**Measurement backend:** inline sweep via `run_script` (sandbox executor) over `empirical_gate.py` (cycle-4 adapter)
**Corpora:** skills/ (79) + docs/ (21) + refs/ (113)
**Candidates measured:** 41 (3 L24 + 36 L25 + 12 L26 + 1 L27)
**Output target:** `/var/workspace/session/zip_digest/cycle-9/new-ideas-cycle9.md`

## Cycle progression (cumulative)

| Cycle | Lens frontier | Best measured PC1+PC2 | Δ over baseline (0.6637) |
|---|---|---:|---:|
| 1–3 | qualitative baseline | — | — |
| 4 | empirical_gate + mixed-radix (3+4) | 0.6901 | +0.0264 |
| 5 | L13 column-weight sweep | 0.8080 | +0.1443 |
| 6 | L15 Pareto combined + L16 cross-corpus + L17 synthetic 24-D | 0.8080 | +0.1443 |
| 7 | L18 real 24-D (skills 474) + L19 corpus-adaptive + L20 per-corpus Möbius | 0.7925 (real 24-D) / 0.8538 (docs) | +0.4932 (real 24-D) / +0.1901 (docs) |
| 8 | L21 full real 24-D (1391) + L22 per-corpus Pareto + L23 finer-grained NSS | 0.8538 (docs) / 0.7632 (full real 24-D) | +0.4639 (full real 24-D) / +0.1901 (docs) |
| **9** | **L24 weight selector + L25 hybrid weighting + L26 NSS validation + L27 SELF.md** | **1.0000 (single-primitive)** / **0.7566 (L24 selector on refs)** | **+0.3363 (refs)** |

## Top new ideas from cycle 8 → cycle 9 applied

| Cycle-8 top pick | Cycle-9 application |
|---|---|
| Per-corpus weighting + D=128 frozen Möbius is universal | **L24** held-out PC1+PC2 selector picks W18/W19/uniform per corpus automatically |
| W19-on-9D holds at scale (0.7632 on 1391 rows) | **L25** hybrid weighting: combine W18 and W19; test whether single-primitive or hybrid beats either pure |
| NSS scoring is coarse 0/0.4/0.6/0.8/1.0 | **L26** NSS validation: test 12 regex patterns against 86 SKILL.md files, report per-axis coverage |
| Self corpus (~895 rows) not yet loaded | **L27** score the actual SELF.md from `/var/workspace/memory/personal-WbtUgeUv/SELF.md` (186 lines, 23K chars) via NSS logic, add to 24-D matrix |

## L24 — Per-corpus weight selector (held-out PC1+PC2)

Split each corpus 80/20 with seed=42, measure PC1+PC2 for each candidate weighting (W18/W19/uniform) on the train split, pick the best on train, verify on holdout.

| Corpus | N | Train scores | Holdout scores | Selector picked | Holdout score | Matched optimal? |
|---|---:|---|---|---|---:|---|
| skills/ | 79 | W18=0.84, W19=0.80, uniform=0.67 | W18=**0.90**, W19=0.77, uniform=0.71 | **W18** | **0.9004** | ✓ |
| docs/ | 21 | W18=0.74, W19=0.84, uniform=0.68 | W18=1.00, W19=1.00, uniform=0.88 | **W19** | **1.0000** | ✗ (all 3 tied at 1.00) |
| refs/ | 113 | W18=0.68, W19=0.75, uniform=0.54 | W18=0.71, W19=**0.76**, uniform=0.56 | **W19** | **0.7566** | ✓ |

**2/3 selectors matched the true holdout optimum.** The docs/ "miss" is a tie — all three weightings hit 1.0 on the tiny 4-item holdout (only 4 docs items after the 80/20 split). For skills/ and refs/, the selector matched.

**Average holdout score**: (0.9004 + 1.0000 + 0.7566) / 3 = **0.8857** — well above the 0.40 gate and above cycle-8's per-corpus best (0.8080 + 0.8538 + 0.7507 = 0.8075 avg).

The selector works: train on 80%, verify on 20%, pick the weighting with the highest held-out PC1+PC2.

## L25 — W18+W19 hybrid weighting (the surprise finding)

12 hybrid candidates × 3 corpora = 36 measurements. Single-primitive weightings hit **PC1+PC2 = 1.0000** on all 3 corpora.

| Hybrid | skills/ | docs/ | refs/ | Avg |
|---|---:|---:|---:|---:|
| **keep-m3-only** (`[0,0,1,0,0,0,0,0,0]`) | 1.0000 | 1.0000 | 1.0000 | **1.0000** |
| **keep-m3-m6** (`[0,0,1,0,0,1,0,0,0]`) | 1.0000 | 1.0000 | 1.0000 | **1.0000** |
| **keep-m4-m5** (`[0,0,0,1,1,0,0,0,0]`) | 1.0000 | 1.0000 | 1.0000 | **1.0000** |
| **single-m6-only** (`[0,0,0,0,0,1,0,0,0]`) | 1.0000 | 1.0000 | 1.0000 | **1.0000** |
| keep-m3-m6-m9 | 0.9077 | 0.8929 | 0.8045 | 0.8685 |
| W19-only | 0.7854 | 0.8538 | 0.7507 | 0.7966 |
| W18-only | 0.8080 | 0.7411 | 0.6485 | 0.7325 |
| keep-m3-only-m6-m9 (3 primitives) | 0.9077 | 0.8929 | 0.8045 | 0.8685 |
| uniform (all-1s) | 0.6637 | 0.6844 | 0.5255 | 0.6245 |
| keep-m4-m5-m7-m8 (W19 full) | 0.7854 | 0.8538 | 0.7507 | 0.7966 |
| keep-m3-m6-m9 | 0.9077 | 0.8929 | 0.8045 | 0.8685 |

**The single-primitive weightings hit 1.0000.** This is because PCA top-2 concentrates perfectly when only one column has variance — there's no noise to spread the variance across more components. But this is **not a useful gate-improvement** — it means the gate is trivially satisfied because the data is degenerate (only one dimension is non-zero after standardization).

The genuine gate improvements are at 2-3 primitives: **keep-m3-m6-m9** averages 0.8685 across 3 corpora, beating both W18-only (0.7325) and W19-only (0.7966).

## L26 — NSS-scoring validation (MAJOR finding)

86 SKILL.md files tested against the 12 NSS regex patterns from `build-nd-axis-viewer.py`.

| NSS axis | Coverage | 0 hits | 1 hit | 2 hits | 3 hits | 4+ hits |
|---|---:|---:|---:|---:|---:|---:|
| **audience** | **46.51%** | 46 | 8 | 6 | 12 | 14 |
| **recursion** | **8.14%** | 79 | 1 | 0 | 2 | 4 |
| inputs | 4.65% | 82 | 2 | 1 | 0 | 1 |
| outputs | 4.65% | 82 | 3 | 0 | 0 | 1 |
| **mode** | **0.00%** | 86 | 0 | 0 | 0 | 0 |
| **assumption_set** | **0.00%** | 86 | 0 | 0 | 0 | 0 |
| **adjacent_problems** | **0.00%** | 86 | 0 | 0 | 0 | 0 |
| **failure_modes** | **0.00%** | 86 | 0 | 0 | 0 | 0 |
| **lifecycle** | **0.00%** | 86 | 0 | 0 | 0 | 0 |
| **composition** | **0.00%** | 86 | 0 | 0 | 0 | 0 |
| **knowledge_sources** | **0.00%** | 86 | 0 | 0 | 0 | 0 |
| **calibration** | **0.00%** | 86 | 0 | 0 | 0 | 0 |

**8 of 12 axes have 0% coverage.** Only `audience` (46.51%) and `recursion` (8.14%) have meaningful coverage.

**Implication**: the NSS scoring logic in `build-nd-axis-viewer.py` (which the cycle-7/8 real 24-D measurements are based on) is **mostly noise**. The 12 NSS axes contribute almost no information because 8 of them never fire on any SKILL.md file. The cycle-7/8 24-D measurement is dominated by the 9 binary primitives + the 2 active NSS axes (audience, recursion) + the 3 run-metadata.

This is a **calibration finding**: the cycle-7/8 NSS-based 24-D results should be re-checked with only the 2 active NSS axes. The PC1+PC2 = 0.7632 (full real 24-D) and PC1+PC2 = 0.7925 (skills subset) may not be reproducible if we drop the 10 inactive axes.

## L27 — SELF.md 24-D

Score the actual SELF.md from `/var/workspace/memory/personal-WbtUgeUv/SELF.md` (186 lines, 23,180 chars) via NSS logic.

| NSS axis | Score |
|---|---:|
| **audience** | **1.0** |
| **recursion** | **1.0** |
| outputs | 0.4 |
| inputs | 0.0 |
| mode | 0.0 |
| assumption_set | 0.0 |
| adjacent_problems | 0.0 |
| failure_modes | 0.0 |
| lifecycle | 0.0 |
| composition | 0.0 |
| knowledge_sources | 0.0 |
| calibration | 0.0 |

**SELF.md NSS profile matches the L26 finding**: only `audience` (1.0) and `recursion` (1.0) are active. The other 10 NSS axes all score 0. SELF.md is a self-archaeology document — it has an audience section and recursive structure, but no inputs/outputs/mode/lifecycle etc.

Adding SELF.md to the 1391-row corpus (now 1392 rows), W19-on-9D-only PC1+PC2 = **0.7632** — **identical to cycle-8**. A single row doesn't move PCA top-2 because the variance distribution is unchanged. SELF.md adds a single point to the cloud but doesn't change the concentration.

## Combined cycle-9 recommendation

**Best gate-improvement**: L25 keep-m3-m6-m9 → PC1+PC2 = **0.8685** average across 3 corpora (0.9077 / 0.8929 / 0.8045). Beats both W18-only (0.7325) and W19-only (0.7966).

**Best corpus-adaptive (L24)**: held-out PC1+PC2 selector picks W18 for skills/ (0.9004 holdout), W19 for docs/ (1.0000 holdout), W19 for refs/ (0.7566 holdout). Average: **0.8857**.

**Best SINGLE-primitive**: L25 keep-m3-only → PC1+PC2 = **1.0000** on all 3 corpora. But this is degenerate (single-column variance), not a useful gate.

**Major calibration finding**: 8 of 12 NSS axes have 0% coverage on 86 SKILL.md files. The cycle-7/8 24-D measurements are dominated by 9 primitives + 2 active NSS axes (audience, recursion) + 3 run-metadata. Future 24-D work should consider dropping the 10 inactive axes.

## Key assumptions (now measurable)

- [x] Per-corpus weight selector works (L24): 2/3 matched optimal on held-out evaluation
- [x] Single-primitive weightings hit PC1+PC2 = 1.0000 (L25, but degenerate)
- [x] 3-primitive weightings (keep-m3-m6-m9) average 0.8685 across corpora (L25, genuine improvement)
- [x] **8 of 12 NSS axes have 0% coverage** on 86 SKILL.md files (L26, calibration finding)
- [x] SELF.md scored: only audience (1.0) and recursion (1.0) are active (L27)
- [x] Adding SELF.md to corpus doesn't move W19-on-9D PC1+PC2 (single row effect, L27)

## What's still open

- **NSS calibration**: drop the 10 inactive NSS axes from the 24-D construction and re-measure cycle-7/8 results. If the gate still holds with only 2 active NSS axes, the cycle-7/8 findings are robust.
- **Self corpus full**: self-corpus-listing.json has 111 items but only 5 in `items_sample`. Cycle-9 added 1 (SELF.md from workspace). Need the full 111-row self corpus to test at the main paper's 2286-section scale.
- **L24 docs/ tie**: docs/ holdout is too small (4 items) for the selector to discriminate. Cycle-10 should use a larger holdout or cross-validation.
- **L25 single-primitive degeneracy**: the 1.0000 measurement is trivial (no signal in single column). Genuine gate improvements are at 2-3 primitives.

## Audit trail

- Generated 2026-08-09T22:40:00 via guided-curve-ideate (cycle-9, measured)
- Measurement: inline sweep via run_script (sandbox executor)
- Source: papers/scripts/build-nd-axis-viewer.py (NSS scoring logic, 12 regex patterns)
- L24: held-out PC1+PC2 selector (80/20 split, seed=42)
- L25: 12 hybrid weightings × 3 corpora = 36 candidates
- L26: NSS validation against 86 SKILL.md files in skills/ directory
- L27: SELF.md scored from /var/workspace/memory/personal-WbtUgeUv/SELF.md (186 lines)
- Input: /var/workspace/session/zip_digest/cycle-9/constraints-catalog-2026-08-09-cycle9.md
- Output: /var/workspace/session/zip_digest/cycle-9/new-ideas-cycle9.md
- LOCAL ONLY — not committed to any repo
