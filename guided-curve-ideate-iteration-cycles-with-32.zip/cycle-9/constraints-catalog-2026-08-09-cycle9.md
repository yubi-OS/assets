# Constraints Catalog — 2026-08-09 cycle 9

**Cycle:** 9 (applies top 4 new ideas from cycle 8)
**Driver:** close cycle-8 limitations — automate per-corpus selection, test hybrid weighting, validate NSS scoring, add SELF.md.

## Cycle-8 limitations addressed

1. **Manual per-corpus weight selection** → cycle-9 L24 held-out PC1+PC2 selector
2. **Hybrid weighting untested** → cycle-9 L25 tests W18+W19 hybrid candidates
3. **NSS scoring validation missing** → cycle-9 L26 tests 12 regex patterns against 86 SKILL.md files
4. **Self corpus not loaded** → cycle-9 L27 scores actual SELF.md from workspace

## Current operational instantiation (UNCHANGED)

| Axis | Value |
|---|---|
| ℓ | 384 |
| m | 3 |
| sin^n θ polar | n = 384 |
| D | 384 |
| Sampling | Fibonacci (Vogel's golden-angle) |
| Möbius | frozen (refine-once at corpus creation) |
| freq_sym | 3-fold (m_k = 3k, k=1..128) |
| Per-item basis dim | 384 |
| Realized P | 147,840 |

## Cycle-9 axes (NEW)

- **Axis 20 — Held-out PC1+PC2 selector**: split corpus 80/20, measure on train, pick best on train, verify on holdout
- **Axis 21 — Hybrid weighting**: combine W18 and W19 in various ways (single-primitive, 2-primitive, 3-primitive)
- **Axis 22 — NSS scoring coverage**: per-axis hit rate on real SKILL.md files
- **Axis 23 — SELF.md scoring**: score the actual SELF.md from workspace via NSS logic

## Cycle-9 lens coverage

| Lens | Tests | Source |
|---|---|---|
| L24 — Per-corpus weight selector | 80/20 split, measure on train, verify on holdout | Cycle-8 L22 needed automation |
| L25 — W18+W19 hybrid weighting | 12 hybrid candidates × 3 corpora = 36 candidates | Cycle-8 used pure W18/W19 only |
| L26 — NSS scoring validation | 12 regex patterns × 86 SKILL.md files | NSS scoring may be unreliable |
| L27 — SELF.md 24-D | Score SELF.md from workspace via NSS logic | Self corpus not yet loaded |

## Cycle-9 calculations

Identical to cycle-8, plus:
- **Held-out selector**: 80/20 split with seed=42, measure PC1+PC2 for each candidate weighting, pick the best on train, verify on holdout
- **Hybrid weighting**: combine W18 and W19 in various ways (single-primitive, 2-primitive, 3-primitive)
- **NSS coverage**: per-axis hit rate on 86 SKILL.md files in skills/ directory
- **SELF.md scoring**: apply NSS logic to /var/workspace/memory/personal-WbtUgeUv/SELF.md

## Audit trail

- Generated 2026-08-09T22:40:00
- Source: cycle-8 limitations (cycle-9 closes them)
- Output: new-ideas-cycle9.md
