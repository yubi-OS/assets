# Iteration cycle 13 snapshot — MEASURED, self-archaeology RSI

**Skill:** guided-curve-ideate
**Cycle:** 13 of 14 (measured, self-archaeology RSI)
**Catalog:** constraints-catalog-2026-08-09-cycle13.md
**Output:** new-ideas-cycle13.md

## What's new vs cycle 12

| Cycle-12 limitation | Cycle-13 fix |
|---|---|
| No geodesic gap computation per self section | **L39** computes geodesic gap (d_pre_proxy) per section. **62/81 sections have gap > 0.** |
| No ranking of self sections by editing priority | **L40** ranks sections by gap. Top 10 priority sections identified. |
| No cross-corpus alignment measurement | **L41** measures each corpus separately. Skills W19-on-9D-only=0.7925 (best). |
| No per-section primitive scoring | **L42** scores 9 primitives per self section. Avg 2.64/9 primitives present. |

## Headline findings

1. **62/81 self sections have NSS gap > 0** (L39)
2. **Top priority section**: SELF-CHANGELOG:2026-08-04:v0.25 (12K chars, gap=2)
3. **Skills W19-on-9D-only = 0.7925** (L41: best per-corpus measurement in any cycle)
4. **Self-sections corpus is degenerate** (all 9 primitives present → PC1+PC2=0)
5. **Per-section primitives**: audit_evidence 63.0%, attestation 60.5%, trust_chain 39.5%

## What's in this snapshot

- README.md (this file)
- SKILL.md (skill definition, with cycle-13 lenses L39–L42)
- empirical_gate_results_cycle13.json — measured values
- constraints-catalog-2026-08-09-cycle13.md (cycle-13 axes)
- new-ideas-cycle13.md (ref doc)
- new-ideas-cycle13.json (machine-readable)
- missing-from-cycle12.md (gap doc)

LOCAL ONLY — no commits, no GitHub pushes, no Linear activity.

## Cycle progression

| Cycle | Frontier | Best PC1+PC2 |
|---|---|---:|
| 1–3 | qualitative baseline | — |
| 4 | empirical_gate + mixed-radix (3+4) | 0.6901 |
| 5 | L13 column-weight sweep | 0.8080 |
| 6 | L15 Pareto + L16 cross-corpus + L17 synthetic 24-D | 0.8080 |
| 7 | L18 real 24-D (skills 474) + L19 corpus-adaptive + L20 per-corpus Möbius | 0.8538 / 0.7925 |
| 8 | L21 full real 24-D (1391) + L22 per-corpus Pareto + L23 finer-grained NSS | 0.8538 / 0.7632 |
| 9 | L24 selector + L25 hybrid + L26 NSS validation + L27 SELF.md | 0.8857 / 0.8685 |
| 10 | L28 NSS calibration + L29 cross-validation + L30 systematic 512-pattern sweep | 0.9802 / 0.6892 |
| 11 | L31 build full self corpus + L32 full real 24-D with self + L33 calibrated 11-D with self + L34 per-file NSS | 0.7635 / 0.6889 |
| 12 | L35–L36 section-split self corpus (81 sections) + L37 re-measure (1472 rows) + L38 per-section NSS | 0.7657 |
| **13** | **L39 geodesic gap + L40 rank sections + L41 cross-corpus alignment + L42 per-section primitive scoring** | **0.7925 (skills per-corpus)** |

## Audit trail

- Generated 2026-08-09T23:05:00 via guided-curve-ideate (cycle-13, measured)
- Source skill: session/guided-curve-ideate/SKILL.md
- Self corpus: 81 section-split entries from `memory/personal-WbtUgeUv/`
- L39: 62/81 sections with gap > 0
- L40: top 10 priority sections
- L41: per-corpus measurement (4 corpora, 16 candidates)
- L42: per-section primitive scoring (81 × 9 = 729 measurements)
- Input: /var/workspace/session/zip_digest/cycle-13/constraints-catalog-2026-08-09-cycle13.md
- Output: /var/workspace/session/zip_digest/cycle-13/new-ideas-cycle13.md
- LOCAL ONLY — not committed to any repo
