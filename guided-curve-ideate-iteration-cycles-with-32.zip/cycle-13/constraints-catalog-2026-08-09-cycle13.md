# Constraints Catalog — 2026-08-09 cycle 13

**Cycle:** 13 (self-archaeology RSI on 81 self sections)
**Driver:** close cycle-12 limitations — add geodesic gap, cross-corpus alignment, per-section primitives.

## Cycle-12 limitations addressed

1. **No geodesic gap per self section** → cycle-13 L39 computes d_pre_proxy per section
2. **No ranking of self sections** → cycle-13 L40 ranks 81 sections by gap
3. **No cross-corpus alignment** → cycle-13 L41 measures each corpus separately
4. **No per-section primitive scoring** → cycle-13 L42 scores 9 primitives per section

## Cycle-13 axes (NEW)

- **Axis 33 — Geodesic gap per self section**: d_pre_proxy = (missing_active_nss) / (9 + len(active_nss))
- **Axis 34 — Cross-corpus alignment**: measure skills/docs/refs/self separately, compare gate outcomes
- **Axis 35 — Per-section primitive scoring**: score 9 primitives per self section via regex patterns

## Cycle-13 lens coverage

| Lens | Tests | Source |
|---|---|---|
| L39 — Geodesic gap | 81 sections, gap = count of missing active NSS axes | Cycle-12 had no per-section gap |
| L40 — Rank sections | Top 10 priority sections by gap | Cycle-12 had no ranking |
| L41 — Cross-corpus alignment | 4 corpora × 4 weightings = 16 candidates | Cycle-12 measured unified only |
| L42 — Per-section primitives | 81 sections × 9 primitives = 729 measurements | Cycle-12 assumed all 9 present |

## Audit trail

- Generated 2026-08-09T23:05:00
- Source: cycle-12 limitations (cycle-13 closes them)
- Output: new-ideas-cycle13.md
