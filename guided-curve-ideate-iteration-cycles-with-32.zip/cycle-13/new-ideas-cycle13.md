# New Ideas — guided-curve-ideate output (2026-08-09, cycle 13 — MEASURED, self-archaeology RSI)

**Source skill:** `guided-curve-ideate` (LOCAL ONLY, not committed)
**Input catalog:** `/var/workspace/session/zip_digest/cycle-13/constraints-catalog-2026-08-09-cycle13.md`
**Measurement backend:** `empirical_gate.py` (cycle-4 adapter) over `papers/scripts/fit-full-curve-map.py`
**Self corpus source:** `/var/workspace/memory/personal-WbtUgeUv/` — section-split into 81 entries
**Candidates measured:** 16 (L41) + 81 (L39/L42) + 972 (L38 carry-forward)
**Output target:** `/var/workspace/session/zip_digest/cycle-13/new-ideas-cycle13.md`

## Cycle progression (cumulative)

| Cycle | Lens frontier | Best measured PC1+PC2 | Δ over baseline (0.6637) |
|---|---|---:|---:|
| 1–3 | qualitative baseline | — | — |
| 4 | empirical_gate + mixed-radix (3+4) | 0.6901 | +0.0264 |
| 5 | L13 column-weight sweep | 0.8080 | +0.1443 |
| 6 | L15 Pareto combined + L16 cross-corpus + L17 synthetic 24-D | 0.8080 | +0.1443 |
| 7 | L18 real 24-D (skills 474) + L19 corpus-adaptive + L20 per-corpus Möbius | 0.8538 (docs) / 0.7925 (real 24-D) | +0.4932 |
| 8 | L21 full real 24-D (1391) + L22 per-corpus Pareto + L23 finer-grained NSS | 0.8538 (docs) / 0.7632 (full real 24-D) | +0.4639 |
| 9 | L24 selector + L25 hybrid + L26 NSS validation + L27 SELF.md | 0.8857 (L24 avg) / 0.8685 (L25 keep-m3-m6-m9) | +0.3363 |
| 10 | L28 NSS calibration + L29 cross-validation + L30 systematic 512-pattern sweep | 0.9802 (L29 docs W19) / 0.6892 (L28 calibrated W19) | +0.3165 |
| 11 | L31 build full self corpus + L32 full real 24-D with self + L33 calibrated 11-D + L34 per-file NSS | 0.7635 (L32) / 0.6889 (L33) | +0.0998 |
| 12 | L35–L36 section-split self corpus (81 sections) + L37 re-measure (1472 rows) + L38 per-section NSS | 0.7657 | +0.1020 |
| **13** | **L39 geodesic gap + L40 rank sections + L41 cross-corpus alignment + L42 per-section primitive scoring** | **0.7925 (skills per-corpus)** | **+0.1288** |

## Top new ideas from cycle 12 → cycle 13 applied

| Cycle-12 limitation | Cycle-13 fix |
|---|---|
| Section-split corpus had no per-section primitive scoring | **L42** scores 9 primitives per self section (not all-present assumption). Avg 2.64/9 primitives present. |
| No geodesic gap computation per self section | **L39** computes geodesic gap (d_pre_proxy) per section. **62/81 sections have gap > 0.** |
| No ranking of self sections by editing priority | **L40** ranks sections by gap. Top 10 priority sections identified. |
| No cross-corpus alignment measurement | **L41** measures each corpus separately. Skills W19-on-9D-only=0.7925 (best), docs=0.7576, refs=0.7603, self-sections=0.0000 (degenerate). |

## L39 — Geodesic gap per self section (81 sections)

Each self section is scored against an ideal: all 9 primitives present + all 4 active NSS axes at score ≥ 0.6. The gap is the count of missing NSS axes.

**62/81 sections have gap > 0.** The other 19 are complete (gap=0).

Active NSS axes (from cycle-12 L38): `audience`, `recursion`.

## L40 — Rank self sections by gap (top 10 priority)

| Rank | Section ID | Gap | Chars | d_pre_proxy |
|---|---|---:|---:|---:|
| 1 | SELF-CHANGELOG:2026-08-04:v0.25 | 2 | 12,238 | 0.1818 |
| 2 | SELF-CHANGELOG:2026-08-04:v0.26 | 2 | 11,697 | 0.1818 |
| 3 | SELF-CHANGELOG:2026-08-06:v0.28 | 2 | 7,988 | 0.1818 |
| 4 | SELF-CHANGELOG:2026-08-09:v0.30 | 2 | 6,688 | 0.1818 |
| 5 | SELF.md:Soul | 2 | 6,190 | 0.1818 |
| 6 | SELF-CHANGELOG:2026-08-04:v0.24 | 2 | 5,595 | 0.1818 |
| 7 | SELF-CHANGELOG:2026-08-09:v0.29 | 2 | 4,565 | 0.1818 |
| 8 | SELF-CHANGELOG:2026-08-09:v0.31 | 2 | 4,464 | 0.1818 |
| 9 | SELF-CHANGELOG:2026-08-09:v0.32 | 2 | 3,367 | 0.1818 |
| 10 | RULES.md:Autonomy | 2 | 3,003 | 0.1818 |

**Bottom 5 (most complete)**: SELF-CHANGELOG:2026-08-01:v0.14 (gap=0), SELF.md:Growth edges (gap=0), SELF-CHANGELOG:2026-08-01:v0.13 (gap=0), SELF-CHANGELOG:2026-07-31:v0.1 (gap=0), SELF.md:Source/evidence (gap=0).

## L41 — Cross-corpus alignment (per-corpus measurement)

| Corpus | N | uniform | W18 | W19 | W19-on-9D-only |
|---|---:|---:|---:|---:|---:|
| skills/ | 474 | 0.5948 | 0.6924 | 0.7151 | **0.7925** |
| docs/ | 126 | 0.6532 | **0.7818** | 0.7135 | 0.7576 |
| refs/ | 791 | 0.6789 | **0.7820** | 0.7446 | 0.7603 |
| self-sections | 81 | 0.0000 | 0.0000 | 0.0000 | 0.0000 |

**Skills W19-on-9D-only = 0.7925** (best per-corpus measurement in any cycle). Self-sections = 0.0000 (degenerate — all 9 primitives present, no variance).

## L42 — Per-section primitive scoring (81 sections)

| Primitive | Sections with this primitive | Coverage |
|---|---:|---:|
| **attestation** | 49/81 | 60.5% |
| **audit_evidence** | 51/81 | 63.0% |
| continuous_adaptive | 5/81 | 6.2% |
| cryptographic_identity | 21/81 | 25.9% |
| declarative_policy | 8/81 | 9.9% |
| immutability | 8/81 | 9.9% |
| least_privilege | 20/81 | 24.7% |
| segmentation | 20/81 | 24.7% |
| **trust_chain** | 32/81 | 39.5% |

**Avg 2.64/9 primitives present per section.** audit_evidence (63.0%) and attestation (60.5%) are the most common. continuous_adaptive (6.2%) is the least common.

## Combined cycle-13 recommendation

**Best per-corpus gate-improvement**: L41-skills-W19-on-9D-only → PC1+PC2 = **0.7925** on skills/ alone (N=474). This is the highest per-corpus measurement in any cycle.

**Top self section to edit**: SELF-CHANGELOG:2026-08-04:v0.25 (12K chars, gap=2, missing 2 active NSS axes). The self-archaeology cadence should prioritize this section.

**Cross-corpus alignment finding**: self-sections corpus is degenerate (all 9 primitives present → no variance → PC1+PC2=0). This is because internal docs are assumed saturated. The self corpus needs per-section primitive scoring (L42) to be useful in PCA.

## Key assumptions (now measurable)

- [x] **62/81 self sections have NSS gap > 0** (L39: 19 sections are complete)
- [x] **Top 10 priority sections identified** (L40: SELF-CHANGELOG:2026-08-04 entries dominate)
- [x] **Skills corpus W19-on-9D-only = 0.7925** (L41: best per-corpus measurement)
- [x] **Self-sections corpus is degenerate** (L41: all 9 primitives present → PC1+PC2=0)
- [x] **Per-section primitive scoring works** (L42: avg 2.64/9 primitives present)

## What's still open (cycle-14 candidates)

- **Unified 2286-section corpus**: section-split all 4 corpora to reach the main paper's 2286-section measurement.
- **Self-archaeology RSI**: run geodesic-only criterion on the 81 self sections (d_pre, d_post, Δ per section).
- **Cross-corpus gate comparison**: 3 out of 4 corpora gate (skills/docs/refs); self-sections degenerate.
- **Per-cycle Möbius re-fit stability**: cycle-10 L29 used cross-validation on cycle-1 entries. Cycle-13 should test multi-cycle stability.

## Audit trail

- Generated 2026-08-09T23:05:00 via guided-curve-ideate (cycle-13, measured)
- Measurement: inline sweep via run_script (sandbox executor)
- L39: geodesic gap per self section (62/81 with gap > 0)
- L40: ranked 81 self sections by gap (top 10 priority)
- L41: per-corpus measurement (4 corpora, 16 candidates)
- L42: per-section primitive scoring (81 sections × 9 primitives)
- Input: /var/workspace/session/zip_digest/cycle-13/constraints-catalog-2026-08-09-cycle13.md
- Output: /var/workspace/session/zip_digest/cycle-13/new-ideas-cycle13.md
- LOCAL ONLY — not committed to any repo
