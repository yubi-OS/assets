# What's missing from cycle 12 — and how cycle 13 addresses it

## Gaps in cycle 12

1. **No geodesic gap computation per self section.** Cycle-12 measured PC1+PC2 but didn't compute per-section gap (how far each section is from "ideal" coverage).
2. **No ranking of self sections by editing priority.** Without a gap metric, no way to prioritize which sections need self-archaeology editing.
3. **No cross-corpus alignment measurement.** Cycle-12 measured the unified corpus only, not each corpus separately.
4. **No per-section primitive scoring.** Self sections currently assume all 9 primitives are present (internal docs). Per-section primitive scoring would give finer-grained measurement.

## Cycle-13 fix

| Gap | Cycle-13 fix |
|---|---|
| No geodesic gap per self section | **L39** computes geodesic gap (d_pre_proxy) per section. **62/81 sections have gap > 0.** Active NSS axes: audience, recursion. Gap = count of missing active axes. |
| No ranking of self sections by editing priority | **L40** ranks sections by gap. Top 10 priority sections: SELF-CHANGELOG:2026-08-04 entries dominate (12K, 11K, 8K chars). |
| No cross-corpus alignment measurement | **L41** measures each corpus separately. Skills W19-on-9D-only=0.7925 (best), docs W18=0.7818, refs W18=0.782, self-sections=0.0000 (degenerate). |
| No per-section primitive scoring | **L42** scores 9 primitives per self section. Avg 2.64/9 primitives present. audit_evidence 63.0%, attestation 60.5%, trust_chain 39.5%. |

## What cycle-13 still doesn't address (open for cycle 14)

1. **Unified 2286-section corpus.** Section-split all 4 corpora to reach the main paper's 2286-section measurement.
2. **Self-archaeology RSI.** Run geodesic-only criterion on the 81 self sections (d_pre, d_post, Δ per section).
3. **Per-cycle Möbius re-fit stability.** Cycle-10 L29 used cross-validation on cycle-1 entries. Cycle-14 should test multi-cycle stability.
4. **Self-sections corpus needs per-section primitive scoring to be useful in PCA.** Currently degenerate (all 9 primitives present).

## Cycle-14 candidate lenses

- **L43 — Unified corpus**: build unified corpus from section-split self + skills/docs/refs.
- **L44 — Re-measure on unified corpus**: 1472 rows, 4 candidates.
- **L45 — Compare to main paper's 0.2993**: Δ from main paper.
- **L46 — Close the gap to main paper's setup**: characterize the 814-section gap.

These are the cycle-14 lenses if the user wants another iteration.
