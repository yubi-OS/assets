# Constraints Catalog — 2026-08-09 cycle 2

**Source:** `learned-latent-curves-2026-08-06.tex` §3.3 (line 124-125)
**Cycle:** 2 (refined from cycle 1; tests new mechanisms)
**Driver:** apply top 3 from cycle 1 + test uncovered mechanisms

## Cycle 1 → Cycle 2 refinements

Cycle 1 produced 14 candidates across 6 lenses. The top 3 (L1-01, L1-02, L3-03) tied at 46/50 because the rubric didn't differentiate candidates with identical quantitative metrics. Cycle 2 adds:

1. **Axes-difference metric**: count + weight of axes that differ from current. Captures "how many knobs were turned" not just the resulting state.
2. **Mechanism-uniqueness metric**: does the candidate test a mechanism that NO prior candidate tested? Replaces novelty's lens-only signal.
3. **Mechanism tags**: every candidate gets tagged (bootstrap / modulation / Möbius / sampling / freq-sym / lobed / rank-test).
4. **6 NEW candidates** testing uncovered mechanisms:
   - **Negative-m basis** (Y_{ℓ,-m} without positive m)
   - **Single-radix alternatives** (2-fold, 4-fold, 5-fold freq-sym alone — no 3-fold)
   - **Low-D rank hypothesis** (D=32, D=128)
   - **Per-tier Möbius** (different φ_θ per tier)
   - **Structural refutation** (candidate that explicitly removes a current feature)

## Current operational instantiation (UNCHANGED)

| Axis | Value |
|------|-------|
| ℓ | 384 |
| m | 3 |
| sin^n θ polar | n = 384 |
| D | 384 |
| Sampling | Fibonacci (Vogel's golden-angle) |
| Möbius | frozen (refine-once at corpus creation) |
| freq-sym | 3-fold (m_k = 3k, k=1..128) |
| Per-item basis dim | 384 |
| Realized P | 147,840 |

## Cycle 2 axes of variation (extended)

Axes 1–6 unchanged from cycle 1. Axis 7 EXTENDED:

### Axis 7 (NEW): Frequency-domain discretization
- **lobe_convention** (NEW): 3-fold / all-m / 2-fold / 4-fold / 5-fold / 7-fold / mixed-radix / negative-m-only
- **per-tier_Möbius** (NEW): shared / independent

## Cycle 2 calculations

Identical to cycle 1, plus:

- **Mechanism tag** (per candidate): "bootstrap" | "modulation" | "Möbius" | "sampling" | "freq-sym" | "lobed" | "rank-test"
- **Axes different from current** (0–7): count + weighted (ℓ/m weighted 2x, n_sin weighted 1x, D weighted 1x, sampling weighted 2x, Möbius weighted 3x, freq-sym weighted 2x)
- **Lobe set enumeration**: explicit list of m_k values per candidate (for cross-checking)
- **Structural risk** (1–10, 10 minus risk): low-risk if nested or orthogonal to current; high-risk if it overrides a current feature

## Cycle 2 new candidates (6 added)

| ID | Lens | What it tests |
|----|------|---------------|
| L7-01 | Negative-m | Y_{ℓ,-m} without positive m |
| L7-02 | Negative-m | Same with broader envelope |
| L8-01 | 4-fold alone | Drop 3-fold, keep only 4-fold ladder |
| L8-02 | 5-fold alone | Drop 3-fold, keep only 5-fold ladder |
| L9-01 | Low-D | D=32 tests corpus rank |
| L9-02 | Per-tier Möbius | Different φ_θ per basis tier |
