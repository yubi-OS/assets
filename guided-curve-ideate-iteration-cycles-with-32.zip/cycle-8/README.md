# Iteration cycle 8 snapshot — MEASURED, full real 24-D at scale

**Skill:** guided-curve-ideate
**Cycle:** 8 of 8 (final, measured, full real 24-D)
**Catalog:** constraints-catalog-2026-08-09-cycle8.md
**Output:** new-ideas-cycle8.md
**Measurement backend:** inline sweep via `run_script` (sandbox executor) over `empirical_gate.py` (cycle-4 adapter)

## What's new vs cycle 7

Cycle 7's L18 used the **474-row skills/ subset** of `nd-vectors.json`. Cycle 8 extends to the **full 1391-row real 24-D** by building docs/refs 24-D rows via the NSS scoring logic and concatenating with skills.

| Cycle-7 limitation | Cycle-8 fix |
|---|---|
| L18 used 474-row skills/ subset of real 24-D | **L21** builds docs/refs 24-D rows via NSS scoring → **full 1391-row real 24-D**. Re-measures W18/W19/uniform at scale. |
| Per-corpus Pareto combined (cycle-6 L15) was skills-only | **L22** runs L15 per corpus: W18/W19/uniform × 4 D × 3 Möbius × 3 corpora = **54 candidates**. Finds per-corpus Pareto optima. |
| NSS-axis scoring is 0/0.4/0.6/0.8/1.0 by hit count | **L23** tests length-normalized continuous NSS scoring. Re-measures L21. |

## Headline finding

**W19-on-9D-only holds at scale.** Cycle-7 measured 0.7925 on the 474-row skills/ subset. Cycle-8 measures **0.7632 on the full 1391-row corpus** — still +0.4639 above the main paper's 0.2993.

| Lens | Best PC1+PC2 | Δ over main paper (0.2993) |
|---|---:|---:|
| Cycle-7 L18-W19-on-9D-only (skills 474 rows) | 0.7925 | +0.4932 |
| **Cycle-8 L21-W19-on-9D-only (full 1391 rows)** | **0.7632** | **+0.4639** |
| **Cycle-8 L22-docs-W19-D128-frozen (per-corpus Pareto)** | **0.8538** | n/a (9-D corpus) |
| Cycle-8 L21-uniform-24D | 0.7443 | +0.4450 |

**Per-corpus Pareto combined (L22)**: all 3 corpora converge on **D=128 frozen Möbius** as the cost-optimal. Weighting differs (W18 for skills, W19 for docs/refs) but D and Möbius are universal.

## What's in this snapshot

- README.md (this file)
- SKILL.md (skill definition, with cycle-8 lenses L21 + L22 + L23)
- empirical_gate_cycle8.py — cycle-8 driver
- empirical_gate_results_cycle8.json — measured values for all 65 candidates
- constraints-catalog-2026-08-09-cycle8.md (cycle-8 axes)
- new-ideas-cycle8.md (ref doc)
- new-ideas-cycle8.json (machine-readable)
- missing-from-cycle7.md (gap doc from cycle-8 generation)

LOCAL ONLY — no commits, no GitHub pushes, no Linear activity.

## Cycle progression

| Cycle | Frontier | Best measured PC1+PC2 |
|---|---|---:|
| 1–3 | qualitative baseline | — |
| 4 | empirical_gate + mixed-radix (3+4) | 0.6901 |
| 5 | L13 column-weight sweep | 0.8080 |
| 6 | L15 Pareto combined + L16 cross-corpus + L17 synthetic 24-D | 0.8080 |
| 7 | L18 real 24-D (skills 474 rows) + L19 corpus-adaptive + L20 per-corpus Möbius-cost | 0.7925 (real 24-D) / 0.8538 (docs) |
| **8** | **L21 full real 24-D (1391 rows) + L22 per-corpus Pareto combined + L23 finer-grained NSS** | **0.8538 (docs) / 0.7632 (full real 24-D)** |

## What cycle-8 settled

1. **W19-on-9D holds at scale.** Cycle-7's finding extends from the 474-row skills/ subset to the full 1391-row corpus. PC1+PC2 = 0.7632 (drops slightly from 0.7925, still +0.4639 above main paper).
2. **W18-on-9D improves at scale** (+0.0588 from cycle-7 to cycle-8). The docs/refs rows add structure that helps W18.
3. **Uniform 24-D also recovers** at 0.7443 on the full corpus (+0.2689 over cycle-7). The docs/refs rows add more variance-explained structure.
4. **All 3 corpora converge on D=128 frozen Möbius** as cost-optimal (L22).
5. **Coarse and fine-grained NSS scoring produce identical results** (L23). The 0/0.4/0.6/0.8/1.0 scorer is sufficient.

## What's still open

- **Self corpus**: not yet loaded. Would add ~895 rows to reach the full 2286.
- **Per-corpus weight selector**: cycle-8 L22 found W18/W19 per corpus but the selection logic is still external. A held-out PC1+PC2 selector could automate this.
- **Full 2286-section 24-D**: cycle-8 measured 0.7632 on 1391 rows; the main paper's 0.2993 was on 2286. The self corpus would close the gap.

## Audit trail

- Generated 2026-08-09T22:25:00 via guided-curve-ideate (cycle-8, measured)
- Source skill: session/guided-curve-ideate/SKILL.md
- Implementation: inline sweep (cycle-8 driver)
- Real 24-D: skills from nd-vectors.json (474) + docs (126) + refs (791) = 1391 rows
- NSS scoring: replicated from papers/scripts/build-nd-axis-viewer.py
- Input: /var/workspace/session/zip_digest/cycle-8/constraints-catalog-2026-08-09-cycle8.md
- Output: /var/workspace/session/zip_digest/cycle-8/new-ideas-cycle8.md
- LOCAL ONLY — not committed to any repo
