# Constraints Catalog — 2026-08-09 cycle 8

**Cycle:** 8 (extends cycle-7 to full real 24-D at scale)
**Driver:** close cycle-7 limitations — extend L18 to 1391 rows, run L15 per corpus, test finer-grained NSS.

## Cycle-7 limitations addressed

1. **L18 used 474-row skills/ subset** → cycle-8 L21 uses **full 1391-row real 24-D** (skills + docs + refs)
2. **Per-corpus Pareto was skills-only** → cycle-8 L22 runs L15 per corpus (54 candidates)
3. **NSS scoring may be too coarse** → cycle-8 L23 tests length-normalized continuous scoring

## Current operational instantiation (UNCHANGED)

| Axis | Value |
|---|---|
| ℓ | 384 |
| m | 3 |
| sin^n θ polar | n = 384 |
| D | 384 |
| Sampling | Fibonacci (Vogel's golden-angle) |
| Möbius | frozen (refine-once at corpus creation) |
| freq_sym | 3-fold (m_k = 3k, k=1..128) |
| Per-item basis dim | 384 |
| Realized P | 147,840 |

## Cycle-8 axes (NEW)

- **Axis 17 — Full real 24-D corpus**: skills (from nd-vectors.json, 474 rows) + docs (NSS-scored, 126) + refs (NSS-scored, 791) = 1391 rows
- **Axis 18 — Per-corpus Pareto combined**: W18/W19/uniform × D ∈ {128,192,256,384} × Möbius ∈ {frozen,subgroup-2,full-PSL} × 3 corpora = 54 candidates
- **Axis 19 — NSS scoring granularity**: coarse (0/0.4/0.6/0.8/1.0) vs fine (length-normalized continuous)

## Cycle-8 lens coverage

| Lens | Tests | Source |
|---|---|---|
| L21 — Full real 24-D | W18 / W19 / uniform × 6 weight configs on 1391-row corpus | Cycle-7 L18 caveat (474-row subset) |
| L22 — Per-corpus Pareto combined | W18/W19/uniform × D × Möbius × 3 corpora = 54 candidates | Cycle-6 L15 was skills-only |
| L23 — Finer-grained NSS | Length-normalized continuous scoring | Cycle-7 NSS scoring may be coarse |

## Cycle-8 calculations

Identical to cycle-7, plus:
- **Full real 24-D**: skills 474 + docs 126 + refs 791 = 1391 rows
- **Per-corpus Pareto front**: max PC1+PC2, min total_ops for each corpus
- **Fine-grained NSS**: `score = min(1.0, hits / (doc_length/1000) / 4)`

## Audit trail

- Generated 2026-08-09T22:25:00
- Source: cycle-7 limitations (cycle-8 closes them)
- Output: new-ideas-cycle8.md
