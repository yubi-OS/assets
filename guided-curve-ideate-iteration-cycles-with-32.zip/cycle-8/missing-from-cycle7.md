# What's missing from cycle 7 — and how cycle 8 addresses it

## Gaps in cycle 7

1. **L18 used the 474-row skills/ subset** of `nd-vectors.json`. The main paper measures 24-D on **2286 sections** across 4 corpora (skills/docs/refs/self). Cycle-7 didn't include docs/refs rows in the real 24-D.
2. **Per-corpus Pareto combined (cycle-6 L15) was skills-only** at 9-D. The cycle-7 L19 found W18 vs W19 differs per corpus but didn't run the full L15 (W18/W19 × D × Möbius) per corpus.
3. **NSS-axis scoring is 0/0.4/0.6/0.8/1.0 by hit count** — may be too coarse. Cycle-7 didn't test finer-grained scoring.

## Cycle-8 fix

| Gap | Cycle-8 fix |
|---|---|
| 474-row skills/ subset | **L21 builds docs/refs 24-D rows** via the NSS scoring logic from `empirical_gate_cycle7.py`, concatenates with skills → **full 1391-row real 24-D**. Re-measures W18/W19/uniform. **W19-on-9D holds at scale: 0.7632** (vs cycle-7's 0.7925 on subset). |
| Per-corpus Pareto skills-only | **L22 runs L15 per corpus**: W18/W19/uniform × 4 D × 3 Möbius × 3 corpora = **54 candidates**. All 3 corpora converge on **D=128 frozen Möbius** as cost-optimal. |
| NSS-axis scoring too coarse? | **L23 tests length-normalized continuous NSS scoring**. Result: **identical to coarse** — PCA on standardized features is invariant to monotonic scoring. |

## What cycle-8 still doesn't address (open for cycle 9)

1. **Self corpus.** No `rsi-self-corpus.json` found. The self corpus has ~895 sections per the main paper's 2286 total. Cycle-9 should locate it and add to the full real 24-D.
2. **Per-corpus weight selector.** Cycle-8 L22 found W18/W19 per corpus but the selection logic is external. A held-out PC1+PC2 selector could automate the choice.
3. **Full 2286-section 24-D.** Cycle-8 measured 0.7632 on 1391 rows; the main paper's 0.2993 was on 2286. The self corpus would close the gap to the main paper's exact measurement.
4. **NSS-scoring validation.** Cycle-8 L23 showed coarse and fine-grained scoring produce identical results. But the scoring logic itself (regex patterns in `build-nd-axis-viewer.py`) hasn't been validated against held-out SKILL.md text. Cycle-9 should test scoring on a held-out sample.

## Cycle-9 candidate lenses

- **L24 — Full 2286-section 24-D**: locate and load self corpus, build the full real 24-D, re-measure.
- **L25 — Per-corpus weight selector**: held-out PC1+PC2 automatically picks W18/W19/uniform per corpus.
- **L26 — NSS-scoring validation**: test scoring regex patterns against held-out SKILL.md text.
- **L27 — Cost model refinement**: replace ridge-ops + L-BFGS proxy with wall-clock measurements on each corpus.

These are the cycle-9 lenses if the user wants another iteration.
