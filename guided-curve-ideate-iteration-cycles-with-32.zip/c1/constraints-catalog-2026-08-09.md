# Constraints Catalog — 2026-08-09

**Source:** `learned-latent-curves-2026-08-06.tex` §3.3 (line 124-125)
**Driver:** user directive — "current approach was ℓ=384, m=3, sin^384 θ polar; calculate other varied constraints"
**Mode:** seed for `ideate-solo` (next phase); this is the parameter space the brainstormer expands on.

## Current operational instantiation (line 125)

| Axis | Value |
|------|-------|
| ℓ (angular momentum order) | 384 |
| m (azimuthal mode) | 3 |
| sin^n θ polar envelope | n = 384 (extreme equator-peaked) |
| D (output dimension / corpus size) | 384 |
| Sampling pattern | Fibonacci (Vogel's golden-angle) |
| Möbius group | frozen (refine-once at corpus creation) |
| Per-item basis dim (lobes) | 384 = 2^7 · 3 (m_k = 3k for k=1..128, 3-fold symmetry) |

## Axes of variation

### Axis 1: ℓ (angular momentum order)
- Domain: ℓ ∈ {1, 2, 3, 4, 6, 8, 16, 32, 64, 128, 256, 384, 512, 768}
- Effect: number of (2ℓ+1) basis functions at that ℓ; affects Parseval energy spectrum
- Tradeoff: low ℓ → broad coverage, high ℓ → narrow-band

### Axis 2: m (azimuthal mode)
- Domain: m ∈ {0, 1, 2, 3, 4, 5, 6, 8, 12, 16, 24, 32, 64, 128, 256, 384}
- Constraint: m ≤ ℓ (magnetic quantum number bound)
- Effect: rotational symmetry of the basis; low m → equator-peaked, high m → complex lobes
- Test pairs per paper line 124: (ℓ=128, m=256) vs (ℓ=256, m=128)

### Axis 3: sin^n θ polar envelope exponent
- Domain: n ∈ {1, 2, 3, 4, 6, 8, 16, 32, 64, 128, 256, 384, 512}
- Effect: equator-peaked factor in per-item basis
- n=1: uniform (no envelope); n=3: standard spherical harmonic envelope; n→384: extreme equator-peaked
- Tradeoff: low n → broader coverage, high n → high-dimensional pegged at equator

### Axis 4: D (dimensionality / corpus size)
- Domain: D ∈ {64, 96, 128, 192, 256, 384, 512, 768, 1024}
- Effect: per-item basis dim, parameter count, PC1+PC2 fitness gate
- Tradeoff: low D → under-parameterized, high D → over-parameterized

### Axis 5: Sampling pattern
- Options: Fibonacci (Vogel's golden-angle), Lebedev (icosahedral), Uniform, Icosahedral, Equidistant cylindrical
- Effect: pole-clustering, O(1) per point lookup, total sample count
- Reference: Fibonacci avoids pole clustering at θ→0,π (line 116)

### Axis 6: Möbius group
- Options: full PSL(2,ℂ) (6 real DOF), restricted subgroup (2-4 DOF), frozen identity (0 DOF)
- Reference: paper §3.4 — refine-once frozen is default; joint-refine-per-cycle for N<30 or growth>25%

### Axis 7: Frequency-domain constraints
- Discrete vs continuous spectrum
- Number of frequencies per item (current: 384 lobes per item)
- Symmetry: 3-fold rotational (current uses m_k = 3k)

## Calculations needed per candidate

For each (ℓ, m, n, D, sampling, Möbius) candidate:

1. **Parameter count:** $P_{\text{sphere}} = D \cdot n_{\text{basis}} + D + n_{\text{Möbius}}$
   where $n_{\text{basis}} = \sum_{\ell=0}^L (2\ell+1)$ and $n_{\text{Möbius}}$ is the real dimension of the Möbius group.
   - Full PSL(2,ℂ): n_Möbius = 6
   - Restricted: n_Möbius = 2 or 4
   - Frozen: n_Möbius = 0

2. **Per-item basis dim:** depends on (ℓ, m, sin^n θ) — number of unique lobe components.
   - Current (ℓ=384, m=3, sin^384 θ polar, D=384): 384 lobes per item, basis_dim = 384
   - Variant (ℓ=128, m=256, sin^128 θ polar, D=384): 256 lobes per item (m_k = k for k=1..256)
   - Variant (ℓ=3, m=3, sin^3 θ polar, D=384): 7 lobes per item (m=-3..+3)

3. **Parseval energy distribution:** $||z||^2 = a^2 + b^2$ at each (ℓ, m) — total energy across all basis elements.

4. **Regime coverage estimate** (qualitative): given the Set C (n=12) full-deferral finding, which candidates would close that gap?
   - If D covers the "12" primitive, gap closes.
   - If ℓ is too low to express the 12 mode, gap remains.

5. **Möbius feasibility:** can this candidate fit a single PSL(2,ℂ) transformation, or does it require more?

6. **PC1+PC2 fitness gate:** will this candidate clear ≥ 0.40 on a corpus of N items?
   - Depends on whether the basis covers the corpus's principal directions.

## Energy equation fit (per v0.29 analysis)

- `eq:composition` (line 176): Δ_corpus = Σ Δ_f_i — always clean fit for any candidate with corpus-level delta decomposition.
- `eq:flat` (line 53): Parseval energy = a^2 + b^2 — fits candidates with separable sine/cosine coefficients.
- `eq:ridge` (line 72): Tikhonov ridge — fits any candidate whose basis defines a regression problem.
- `eq:stereographic` (line 152): chordal distance — fits candidates on S² (all spherical variants).
- `eq:hyperspherical` (line 87): spherical harmonics — fits candidates with Y^S²_{ℓ,m} basis.
- `eq:design` (line 58): constant ||φ(t)||² — does NOT fit any candidate (constant).

## Set C (n=12) full-deferral gap

The current corpus primitive ladder is `{1/32, 1/16, 1/8, 1/4, 1/2, 1, 2, 3, 4, 6, 8, 16, 24, 32, 48, ...}` — there's a gap at **12**. Set C (all rows with n=12 fixed) is entirely deferred.

**Constraint variation that would close this gap:**
- Lower sin^n θ exponent → broader envelope → may include the 12 mode.
- Different ℓ choice → different frequency coverage → may include 12.
- Higher D → more basis functions → can resolve 12.
- Different sampling → different point distribution → may align with 12.
- Different Möbius → re-parameterizes domain → may map 12 into a covered region.

## What ideate-solo should produce

For each axis combination (10-15 candidates total), output:

```json
{
  "id": "candidate-NN",
  "axes": {"ℓ": ..., "m": ..., "n_sin": ..., "D": ..., "sampling": ..., "Möbius": ...},
  "calculations": {
    "P": ...,
    "n_basis": ...,
    "basis_dim_per_item": ...,
    "Parseval_energy_total": ...,
    "regime_coverage_estimate": "...",
    "closes_set_c_gap": true/false,
    "PC1_PC2_gate_estimate": "..."
  },
  "energy_equation_fit": {
    "eq:composition": "clean|loose|none",
    "eq:flat": "...",
    "eq:ridge": "...",
    "eq:stereographic": "...",
    "eq:hyperspherical": "..."
  },
  "novelty": "what's new vs current (ℓ=384, m=3, sin^384 θ polar)",
  "risk": "what could go wrong"
}
```

## What advisor should produce

After receiving ideate-solo output, evaluate:
- Which 3-5 candidates are most promising for closing the Set C (n=12) gap?
- Which candidate is the safest fallback (closest to current, minimal risk)?
- Which candidate is the highest-leverage (biggest energy/regime payoff)?
- What's the test sequence? (Order to actually run them.)
- What additional information would resolve the remaining uncertainty?

## Mode

All outputs LOCAL ONLY. No GitHub commits. Save outputs to `session/` for the user to inspect.
