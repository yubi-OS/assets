# New Ideas — guided-curve-ideate output (2026-08-09)

**Source skill:** `guided-curve-ideate` (LOCAL ONLY, not committed)
**Input catalog:** `/var/workspace/session/constraints-catalog-2026-08-09.md`
**Output target:** `/var/workspace/session/guided-curve-ideate-output/new-ideas.md`
**Candidates generated:** 14

## Current instantiation baseline

| Axis | Value |
|---|---|
| ell | 384 |
| m | 3 |
| n_sin | 384 |
| D | 384 |
| sampling | Fibonacci |
| Moebius | frozen |
| freq_sym | 3-fold |
| per_item_basis_dim | 384 |
| lobe_convention | 3-fold ladder (m_k=3k, k=1..128) |
| realized_P | 147840 |
| raw_P_per_v0_30_advisor | 384·148225 + 384 + 0 = 56,926,590 (nominal, INCORRECT) |

**Realized P (correct accounting per v0.30 advisor):** 147,840
**Raw P (nominal full-basis, the error ideate-solo made):** 384·148225 + 384 + 0 = 56,926,590 (nominal, INCORRECT)

## What this skill adds beyond prior slates

The prior `ideate-solo` slate (v0.29) had 12 candidates but three structural errors (per v0.30 advisor):

1. **Parameter counting used nominal full-basis sum** (`D·Σ(2ℓ+1)`) instead of realized P (`D·basis_dim + D + n_Möbius`). Every candidate's P was wrong by 6–360×.
2. **Lobe convention was silently switched** between 3-fold ladder (m_k=3k) and all-m (m_k=k) mid-slate. Realized P moves by 6×.
3. **No candidate tested primitive bootstrap** (response (a)) — the most likely correct response to the Set C gap.

This skill fixes all three by:

- Using realized P formula uniformly (`D·basis_dim + D + n_Möbius`)
- Pinning the lobe convention per candidate (3-fold / all-m / mixed-radix / multi-radix)
- Including NEW DIRECTIONS that test novel mechanisms:
  - **Negative-m-only basis** (Y_{ℓ,-m} without positive m) — not in prior slates
  - **Mixed-radix freq-sym** (3k + 4k combined) — fills the gap that prior "freq-sym" candidates didn't address
  - **Per-tier Möbius** (different φ_θ per tier) — explicitly mentioned in v0.30 as a deferred gap
  - **Mid-DOF Möbius subgroup** (4 DOF, between frozen and full PSL) — fills the 0/2/6 DOF gap from v0.30
  - **Multi-radix lobe ladder** (3k + 4k + 5k combined) — tests whether single-radix beats multi-radix
  - **All-m convention** at moderate ℓ=64 — switches from 3-fold ladder to m_k=k; tests lobe-convention sensitivity

## Candidates by lens

### Lens L1 — L1

#### L1-01 — Gentle polar envelope

**Axes:**
- ell: 16
- m: 3
- n_sin: 2
- D: 384
- sampling: Fibonacci
- Moebius: frozen
- freq_sym: 3-fold
- lobe_convention: 3-fold

**Rationale:** Inversion of current's extreme equator-peaked (n=384) to gentle (n=2); sin^2 θ covers polar + equator modes.

**Calculations:**
- basis_dim_per_item: 384
- n_Möbius: 0
- P_realized: 147,840
- P_vs_current_ratio: 1.0000×
- PC1+PC2_gate: likely-pass
- closes_n_12_gap: True
- basis_m_count: 128
- Parseval_per_row_a_eq_1: 5
- Möbius_feasible: True

**Energy equation fit:**
- eq:composition: clean
- eq:flat: clean
- eq:ridge: clean
- eq:stereographic: clean (sphere)
- eq:hyperspherical: clean

**Score:** novelty=8, gap_closing=10, energy_fit=9, feasibility=9, risk_inverse=10 → **total=46/50**

#### L1-02 — Direct n=12 targeting

**Axes:**
- ell: 12
- m: 12
- n_sin: 12
- D: 384
- sampling: Fibonacci
- Moebius: frozen
- freq_sym: 3-fold
- lobe_convention: 3-fold

**Rationale:** Targets n=12 mode at its natural frequency; current's sin^384 θ envelope vanishes at poles and over-peaks at equator.

**Calculations:**
- basis_dim_per_item: 384
- n_Möbius: 0
- P_realized: 147,840
- P_vs_current_ratio: 1.0000×
- PC1+PC2_gate: likely-pass
- closes_n_12_gap: True
- basis_m_count: 128
- Parseval_per_row_a_eq_1: 145
- Möbius_feasible: True

**Energy equation fit:**
- eq:composition: clean
- eq:flat: clean
- eq:ridge: clean
- eq:stereographic: clean (sphere)
- eq:hyperspherical: clean

**Score:** novelty=8, gap_closing=10, energy_fit=9, feasibility=9, risk_inverse=10 → **total=46/50**

#### L1-03 — All-m convention, low ell

**Axes:**
- ell: 64
- m: 32
- n_sin: 64
- D: 384
- sampling: Fibonacci
- Moebius: frozen
- freq_sym: all-m
- lobe_convention: all-m (m_k=k, k=1..384)

**Rationale:** Switch lobe convention from 3-fold to all-m (m_k=k). Covers full azimuthal spectrum at moderate ell.

**Calculations:**
- basis_dim_per_item: 384
- n_Möbius: 0
- P_realized: 147,840
- P_vs_current_ratio: 1.0000×
- PC1+PC2_gate: likely-pass
- closes_n_12_gap: False
- basis_m_count: 0
- Parseval_per_row_a_eq_1: 4097
- Möbius_feasible: True

**Energy equation fit:**
- eq:composition: clean
- eq:flat: clean
- eq:ridge: clean
- eq:stereographic: clean (sphere)
- eq:hyperspherical: clean

**Score:** novelty=8, gap_closing=4, energy_fit=9, feasibility=9, risk_inverse=10 → **total=40/50**

### Lens L2 — L2

#### L2-01 — Minimal ell with n=12 mode

**Axes:**
- ell: 12
- m: 6
- n_sin: 6
- D: 384
- sampling: Fibonacci
- Moebius: frozen
- freq_sym: 3-fold
- lobe_convention: 3-fold

**Rationale:** Smallest ell under 3-fold ladder that includes m=12 (at k=4). m=6 gives lobes {3,6,9,12}.

**Calculations:**
- basis_dim_per_item: 384
- n_Möbius: 0
- P_realized: 147,840
- P_vs_current_ratio: 1.0000×
- PC1+PC2_gate: likely-pass
- closes_n_12_gap: True
- basis_m_count: 128
- Parseval_per_row_a_eq_1: 37
- Möbius_feasible: True

**Energy equation fit:**
- eq:composition: clean
- eq:flat: clean
- eq:ridge: clean
- eq:stereographic: clean (sphere)
- eq:hyperspherical: clean

**Score:** novelty=5, gap_closing=10, energy_fit=9, feasibility=9, risk_inverse=10 → **total=43/50**

#### L2-02 — Bare-bones broad-coverage

**Axes:**
- ell: 8
- m: 4
- n_sin: 1
- D: 64
- sampling: Fibonacci
- Moebius: frozen
- freq_sym: 3-fold
- lobe_convention: 3-fold

**Rationale:** Minimum viable: n_sin=1 uniform envelope, low ell, D=64.

**Calculations:**
- basis_dim_per_item: 64
- n_Möbius: 0
- P_realized: 4,160
- P_vs_current_ratio: 0.0281×
- PC1+PC2_gate: uncertain-to-fail
- closes_n_12_gap: True
- basis_m_count: 21
- Parseval_per_row_a_eq_1: 2
- Möbius_feasible: True

**Energy equation fit:**
- eq:composition: clean
- eq:flat: clean
- eq:ridge: clean
- eq:stereographic: clean (sphere)
- eq:hyperspherical: clean

**Score:** novelty=5, gap_closing=10, energy_fit=9, feasibility=6, risk_inverse=6 → **total=36/50**

### Lens L3 — L3

#### L3-01 — Two-tier (12 + 384)

**Axes:**
- ell: [12, 384]
- m: [12, 3]
- n_sin: [12, 384]
- D: 384
- sampling: Fibonacci
- Moebius: frozen
- freq_sym: 3-fold
- lobe_convention: 3-fold

**Rationale:** Tier-1 (ell=12) adds n=12 mode explicitly; tier-2 (ell=384) preserves current behavior. Tested in v0.31 (Candidate 09): nested span, structurally safe.

**Calculations:**
- basis_dim_per_item: 388
- n_Möbius: 0
- P_realized: 149,376
- P_vs_current_ratio: 1.0104×
- PC1+PC2_gate: likely-pass
- closes_n_12_gap: True
- basis_m_count: 128
- Parseval_per_row_a_eq_1: 1.475e+05
- Möbius_feasible: True

**Energy equation fit:**
- eq:composition: clean
- eq:flat: clean (composite)
- eq:ridge: clean
- eq:stereographic: clean (composite)
- eq:hyperspherical: clean (multi-tier)

**Score:** novelty=7, gap_closing=10, energy_fit=9, feasibility=9, risk_inverse=10 → **total=45/50**

#### L3-02 — Mixed-radix freq-sym (3+4)

**Axes:**
- ell: 384
- m: 4
- n_sin: 384
- D: 384
- sampling: Fibonacci
- Moebius: frozen
- freq_sym: mixed (3k + 4k)
- lobe_convention: mixed-radix

**Rationale:** NEW: combines 3-fold (m_k=3k) and 4-fold (m_k=4k) ladders. Covers both branches; 4-fold resonates with 12,24,48.

**Calculations:**
- basis_dim_per_item: 384
- n_Möbius: 0
- P_realized: 147,840
- P_vs_current_ratio: 1.0000×
- PC1+PC2_gate: likely-pass
- closes_n_12_gap: True
- basis_m_count: 128
- Parseval_per_row_a_eq_1: 1.475e+05
- Möbius_feasible: True

**Energy equation fit:**
- eq:composition: clean
- eq:flat: clean
- eq:ridge: clean
- eq:stereographic: clean (sphere)
- eq:hyperspherical: clean

**Score:** novelty=7, gap_closing=10, energy_fit=9, feasibility=9, risk_inverse=10 → **total=45/50**

#### L3-03 — Multi-radix lobe ladder

**Axes:**
- ell: 384
- m: 3
- n_sin: 384
- D: 384
- sampling: Fibonacci
- Moebius: frozen
- freq_sym: multi-radix (3k + 4k + 5k)
- lobe_convention: multi-radix

**Rationale:** NEW: 3 radial symmetries combined. Tests whether multi-radix beats single 3-fold.

**Calculations:**
- basis_dim_per_item: 384
- n_Möbius: 0
- P_realized: 147,840
- P_vs_current_ratio: 1.0000×
- PC1+PC2_gate: likely-pass
- closes_n_12_gap: True
- basis_m_count: 128
- Parseval_per_row_a_eq_1: 1.475e+05
- Möbius_feasible: True

**Energy equation fit:**
- eq:composition: clean
- eq:flat: clean
- eq:ridge: clean
- eq:stereographic: clean (sphere)
- eq:hyperspherical: clean

**Score:** novelty=8, gap_closing=10, energy_fit=9, feasibility=9, risk_inverse=10 → **total=46/50**

### Lens L4 — L4

#### L4-01 — Minimal viable, Fibonacci

**Axes:**
- ell: 16
- m: 8
- n_sin: 2
- D: 256
- sampling: Fibonacci
- Moebius: frozen
- freq_sym: 3-fold
- lobe_convention: 3-fold

**Rationale:** Smallest D that preserves 3-fold symmetry (256 = 3·85+1); broad envelope.

**Calculations:**
- basis_dim_per_item: 256
- n_Möbius: 0
- P_realized: 65,792
- P_vs_current_ratio: 0.4450×
- PC1+PC2_gate: likely-pass
- closes_n_12_gap: True
- basis_m_count: 85
- Parseval_per_row_a_eq_1: 5
- Möbius_feasible: True

**Energy equation fit:**
- eq:composition: clean
- eq:flat: clean
- eq:ridge: clean
- eq:stereographic: clean (sphere)
- eq:hyperspherical: clean

**Score:** novelty=5, gap_closing=10, energy_fit=9, feasibility=9, risk_inverse=10 → **total=43/50**

#### L4-02 — Small D, high ell, broad envelope

**Axes:**
- ell: 64
- m: 8
- n_sin: 4
- D: 128
- sampling: Fibonacci
- Moebius: frozen
- freq_sym: 3-fold
- lobe_convention: 3-fold

**Rationale:** Tests whether low D + broad n_sin beats current high-D + extreme n_sin.

**Calculations:**
- basis_dim_per_item: 128
- n_Möbius: 0
- P_realized: 16,512
- P_vs_current_ratio: 0.1117×
- PC1+PC2_gate: uncertain
- closes_n_12_gap: True
- basis_m_count: 42
- Parseval_per_row_a_eq_1: 17
- Möbius_feasible: True

**Energy equation fit:**
- eq:composition: clean
- eq:flat: clean
- eq:ridge: clean
- eq:stereographic: clean (sphere)
- eq:hyperspherical: clean

**Score:** novelty=5, gap_closing=10, energy_fit=9, feasibility=8, risk_inverse=10 → **total=42/50**

### Lens L5 — L5

#### L5-01 — Lebedev high-resolution

**Axes:**
- ell: 64
- m: 4
- n_sin: 64
- D: 384
- sampling: Lebedev
- Moebius: frozen
- freq_sym: 3-fold
- lobe_convention: 3-fold

**Rationale:** Swap Fibonacci for Lebedev (icosahedral quadrature). Tests whether Fibonacci's golden-angle was load-bearing.

**Calculations:**
- basis_dim_per_item: 384
- n_Möbius: 0
- P_realized: 147,840
- P_vs_current_ratio: 1.0000×
- PC1+PC2_gate: likely-pass
- closes_n_12_gap: True
- basis_m_count: 128
- Parseval_per_row_a_eq_1: 4097
- Möbius_feasible: True

**Energy equation fit:**
- eq:composition: clean
- eq:flat: clean
- eq:ridge: clean
- eq:stereographic: clean (sphere)
- eq:hyperspherical: clean

**Score:** novelty=5, gap_closing=10, energy_fit=9, feasibility=9, risk_inverse=9 → **total=42/50**

#### L5-02 — Icosahedral + 5-fold freq-sym

**Axes:**
- ell: 60
- m: 5
- n_sin: 60
- D: 384
- sampling: Icosahedral
- Moebius: frozen
- freq_sym: 5-fold
- lobe_convention: 3-fold

**Rationale:** Icosahedral sampling + 5-fold freq-sym: 5-fold resonates with 12 (60 has 12 as 12 = 5·12/5).

**Calculations:**
- basis_dim_per_item: 384
- n_Möbius: 0
- P_realized: 147,840
- P_vs_current_ratio: 1.0000×
- PC1+PC2_gate: likely-pass
- closes_n_12_gap: True
- basis_m_count: 128
- Parseval_per_row_a_eq_1: 3601
- Möbius_feasible: True

**Energy equation fit:**
- eq:composition: clean
- eq:flat: clean
- eq:ridge: clean
- eq:stereographic: clean (sphere)
- eq:hyperspherical: clean

**Score:** novelty=5, gap_closing=10, energy_fit=9, feasibility=9, risk_inverse=9 → **total=42/50**

### Lens L6 — L6

#### L6-01 — Full PSL(2,C) per cycle

**Axes:**
- ell: 384
- m: 3
- n_sin: 384
- D: 384
- sampling: Fibonacci
- Moebius: full-PSL
- freq_sym: 3-fold
- lobe_convention: 3-fold

**Rationale:** Unfreeze Möbius: 6 real DOF per corpus. Tests if freeze-once was over-constrained (Section 3.4).

**Calculations:**
- basis_dim_per_item: 384
- n_Möbius: 6
- P_realized: 147,846
- P_vs_current_ratio: 1.0000×
- PC1+PC2_gate: likely-pass
- closes_n_12_gap: True
- basis_m_count: 128
- Parseval_per_row_a_eq_1: 1.475e+05
- Möbius_feasible: True

**Energy equation fit:**
- eq:composition: clean
- eq:flat: clean
- eq:ridge: clean
- eq:stereographic: clean (sphere)
- eq:hyperspherical: clean

**Score:** novelty=5, gap_closing=10, energy_fit=9, feasibility=9, risk_inverse=10 → **total=43/50**

#### L6-02 — Mid-DOF subgroup (4 DOF)

**Axes:**
- ell: 384
- m: 3
- n_sin: 384
- D: 384
- sampling: Fibonacci
- Moebius: subgroup-4
- freq_sym: 3-fold
- lobe_convention: 3-fold

**Rationale:** NEW: 4-DOF Möbius subgroup (between frozen and full PSL). Tests intermediate Möbius richness.

**Calculations:**
- basis_dim_per_item: 384
- n_Möbius: 4
- P_realized: 147,844
- P_vs_current_ratio: 1.0000×
- PC1+PC2_gate: likely-pass
- closes_n_12_gap: True
- basis_m_count: 128
- Parseval_per_row_a_eq_1: 1.475e+05
- Möbius_feasible: True

**Energy equation fit:**
- eq:composition: clean
- eq:flat: clean
- eq:ridge: clean
- eq:stereographic: clean (sphere)
- eq:hyperspherical: clean

**Score:** novelty=8, gap_closing=10, energy_fit=9, feasibility=9, risk_inverse=10 → **total=46/50**

## Top picks (ranked)

1. **L1-01 — Gentle polar envelope** (score 46/50)
   - P=147,840, PC1+PC2=likely-pass, closes_n_12_gap=True, basis_m=128 lobes
   - Why: Inversion of current's extreme equator-peaked (n=384) to gentle (n=2); sin^2 θ covers polar + equato...

2. **L1-02 — Direct n=12 targeting** (score 46/50)
   - P=147,840, PC1+PC2=likely-pass, closes_n_12_gap=True, basis_m=128 lobes
   - Why: Targets n=12 mode at its natural frequency; current's sin^384 θ envelope vanishes at poles and over-...

3. **L3-03 — Multi-radix lobe ladder** (score 46/50)
   - P=147,840, PC1+PC2=likely-pass, closes_n_12_gap=True, basis_m=128 lobes
   - Why: NEW: 3 radial symmetries combined. Tests whether multi-radix beats single 3-fold....

4. **L6-02 — Mid-DOF subgroup (4 DOF)** (score 46/50)
   - P=147,844, PC1+PC2=likely-pass, closes_n_12_gap=True, basis_m=128 lobes
   - Why: NEW: 4-DOF Möbius subgroup (between frozen and full PSL). Tests intermediate Möbius richness....

5. **L3-01 — Two-tier (12 + 384)** (score 45/50)
   - P=149,376, PC1+PC2=likely-pass, closes_n_12_gap=True, basis_m=128 lobes
   - Why: Tier-1 (ell=12) adds n=12 mode explicitly; tier-2 (ell=384) preserves current behavior. Tested in v0...

## Test sequence (recommended order)

1. **Top-ranked candidate first** — run on existing 79-skill design matrix; check PC1+PC2 + Set C deferrals.
2. **Top-2 and top-3 as attribution runs** — one-axis-at-a-time variations from current; each isolates a single mechanism.
3. **Mid-DOF Möbius (L6-02) and multi-radix (L3-03) last** — they introduce NEW mechanisms; run only after the simpler ones succeed.

For each candidate, the empirical signature is:

- **PC1+PC2 ≥ 0.40 gate holds?** (current passes)
- **Set C (n=12) deferrals count drops below 10/10?** (atomic primitive bootstrap)
- **Per-item basis dim unchanged at 384?** (preserves current's expressivity)
- **Möbius refit stable?** (per Section 3.4 — frozen unless corpus grows >25%)

## Key assumptions to validate

- [ ] The 3-fold lobe convention (m_k=3k) is correct for all current instantiation uses
- [ ] The realized P formula is correct (D × basis_dim + D + n_Möbius)
- [ ] The energy equation fits are accurate for multi-tier / mixed-radix candidates
- [ ] The PC1+PC2 gate threshold (≥0.40) transfers to N=79 corpus
- [ ] The candidate generation covers the relevant parameter space (no obvious gaps)

## Audit trail

- Generated 2026-08-09T21:15:27.296685 via guided-curve-ideate
- Source skill: session/guided-curve-ideate/SKILL.md
- Implementation: session/guided-curve-ideate/scripts/ideate.py
- Input: /var/workspace/session/constraints-catalog-2026-08-09.md
- Output: /var/workspace/session/guided-curve-ideate-output/new-ideas.md
- LOCAL ONLY — not committed to any repo