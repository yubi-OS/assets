#!/usr/bin/env python3
"""
guided-curve-ideate — generate candidate parameterizations of the
hyperspherical-harmonic curve variant.

Self-contained Python (stdlib + fractions only). Reads the constraints
catalog from session/constraints-catalog-2026-08-09.md by default; outputs
a markdown ref doc to session/guided-curve-ideate-output/new-ideas.md.

Per the v0.30 advisor's corrections to ideate-solo:
- Use realized P = D × basis_dim + D + n_Möbius (NOT nominal full-basis sum)
- Pin the lobe convention to 3-fold ladder m_k = 3k, k=1..K (current standard)
- The m=12 mode is already in the basis via lobe k=4
- The Set C (n=12) deferral was a primitive-ladder bookkeeping issue (fixed in v0.32-v0.33)

Cycle 2 additions (vs cycle 1):
- Axes-difference metric + mechanism tag + structural risk
- 6 NEW candidates: negative-m basis, single-radix alternatives (2/4/5-fold alone), low-D rank hypothesis, per-tier Möbius
- Sharper scoring that breaks the cycle 1 tie at 46/50

Cycle 3 additions (vs cycle 2):
- BREAKTHROUGH DETECTION: P < 100k AND likely-pass PC1+PC2 AND closes_n_12 → flagged
- 5 NEW candidates: D-sweep at 64/128/192/224/320 to find inflection point
- The breakthrough candidate (L4-01 from cycle 2, D=256, P=65,792, score 48/50) anchors this cycle
- Stop criterion: 3+ candidates meet breakthrough → stop and build final ZIP

This skill adds NEW DIRECTIONS that the prior ideate-solo slate did not test:
- Negative-m-only basis (Y_{ℓ,-m} without positive m)
- Mixed-radix freq-sym (3-fold + 4-fold hybrid)
- Per-tier Möbius (different φ_θ per tier)
- Mid-DOF Möbius subgroup (4 DOF — not 0/2/6)
- Mixed-radix lobe ladder (3k + 4k combined)
- Explicit-DOF Möbius under joint-refine-per-cycle mode
"""

import argparse
import datetime as dt
import hashlib
import json
import os
import sys
from fractions import Fraction
from pathlib import Path

# ============ CURRENT INSTANTIATION BASELINE ============

CURRENT = {
    "ell": 384,
    "m": 3,
    "n_sin": 384,
    "D": 384,
    "sampling": "Fibonacci",
    "Moebius": "frozen",
    "freq_sym": "3-fold",
    "per_item_basis_dim": 384,
    "lobe_convention": "3-fold ladder (m_k=3k, k=1..128)",
    "realized_P": 147840,
    "raw_P_per_v0_30_advisor": "384·148225 + 384 + 0 = 56,926,590 (nominal, INCORRECT)",
}

# ============ CONSTRAINT FORMULAS ============

def lobe_set_3fold(D):
    """Per line 124: m_k = 3k, k=1..D/3. Per-item basis dim = D."""
    K = D // 3
    return sorted({3 * k for k in range(1, K + 1)})


def lobe_set_all_m(D, ell):
    """m_k = k, k=1..D, valid only if D <= 2*ell+1 and m_k <= ell for all k.
    Per-item basis dim = D."""
    if D > 2 * ell + 1:
        return None  # invalid
    return sorted({k for k in range(1, D + 1)})


def realized_P(D, basis_dim, n_Moebius):
    return D * basis_dim + D + n_Moebius


def parseval_energy(a_squared, n_sin):
    """For the structural assumption b = n_sin · a: ||z||^2 = a^2 + b^2 = a^2 (1 + n_sin^2)."""
    return a_squared * (1 + n_sin ** 2)


def n_Moebius_for(group):
    # Per-tier Möbius adds 6 extra DOF (one full PSL per tier)
    n_M = {"frozen": 0, "subgroup-2": 2, "subgroup-4": 4, "full-PSL": 6}.get(group, 0)
    if group == "per-tier-independent":
        # 2 tiers each with full PSL = 12 extra DOF beyond frozen
        return 0  # per-tier-independent does not add to single-tier n_M — handled in compute_metrics
    return n_M


def pc1_pc2_estimate(P):
    """Heuristic gate: current is 147,840."""
    if 50000 <= P <= 250000:
        return "likely-pass"
    elif 10000 <= P < 50000 or 250000 < P <= 500000:
        return "uncertain"
    elif P < 10000:
        return "uncertain-to-fail"
    else:
        return "over-parameterized"


def closes_target_gap_12(basis_m_set):
    """Does the basis include m=12?"""
    return 12 in basis_m_set


# ============ CANDIDATE DEFINITIONS (14 across 6 lenses) ============

CANDIDATES = [
    # ----- L1: INVERSION (opposite extreme of current) -----
    {
        "id": "L1-01", "name": "Gentle polar envelope", "lens": "L1",
        "ell": 16, "m": 3, "n_sin": 2, "D": 384, "sampling": "Fibonacci",
        "Moebius": "frozen", "freq_sym": "3-fold", "lobe_convention": "3-fold",
        "rationale": "Inversion of current's extreme equator-peaked (n=384) to gentle (n=2); sin^2 θ covers polar + equator modes.",
    },
    {
        "id": "L1-02", "name": "Direct n=12 targeting", "lens": "L1",
        "ell": 12, "m": 12, "n_sin": 12, "D": 384, "sampling": "Fibonacci",
        "Moebius": "frozen", "freq_sym": "3-fold", "lobe_convention": "3-fold",
        "rationale": "Targets n=12 mode at its natural frequency; current's sin^384 θ envelope vanishes at poles and over-peaks at equator.",
    },
    {
        "id": "L1-03", "name": "All-m convention, low ell", "lens": "L1",
        "ell": 64, "m": 32, "n_sin": 64, "D": 384, "sampling": "Fibonacci",
        "Moebius": "frozen", "freq_sym": "all-m", "lobe_convention": "all-m (m_k=k, k=1..384)",
        "rationale": "Switch lobe convention from 3-fold to all-m (m_k=k). Covers full azimuthal spectrum at moderate ell.",
    },

    # ----- L2: CONSTRAINT REMOVAL (minimal viable) -----
    {
        "id": "L2-01", "name": "Minimal ell with n=12 mode", "lens": "L2",
        "ell": 12, "m": 6, "n_sin": 6, "D": 384, "sampling": "Fibonacci",
        "Moebius": "frozen", "freq_sym": "3-fold", "lobe_convention": "3-fold",
        "rationale": "Smallest ell under 3-fold ladder that includes m=12 (at k=4). m=6 gives lobes {3,6,9,12}.",
    },
    {
        "id": "L2-02", "name": "Bare-bones broad-coverage", "lens": "L2",
        "ell": 8, "m": 4, "n_sin": 1, "D": 64, "sampling": "Fibonacci",
        "Moebius": "frozen", "freq_sym": "3-fold", "lobe_convention": "3-fold",
        "rationale": "Minimum viable: n_sin=1 uniform envelope, low ell, D=64.",
    },

    # ----- L3: COMBINATION (two-tier / multi-radix) -----
    {
        "id": "L3-01", "name": "Two-tier (12 + 384)", "lens": "L3",
        "ell": [12, 384], "m": [12, 3], "n_sin": [12, 384], "D": 384, "sampling": "Fibonacci",
        "Moebius": "frozen", "freq_sym": "3-fold", "lobe_convention": "3-fold",
        "tier1_basis_dim": 4, "tier2_basis_dim": 384,
        "rationale": "Tier-1 (ell=12) adds n=12 mode explicitly; tier-2 (ell=384) preserves current behavior. Tested in v0.31 (Candidate 09): nested span, structurally safe.",
    },
    {
        "id": "L3-02", "name": "Mixed-radix freq-sym (3+4)", "lens": "L3",
        "ell": 384, "m": 4, "n_sin": 384, "D": 384, "sampling": "Fibonacci",
        "Moebius": "frozen", "freq_sym": "mixed (3k + 4k)", "lobe_convention": "mixed-radix",
        "rationale": "NEW: combines 3-fold (m_k=3k) and 4-fold (m_k=4k) ladders. Covers both branches; 4-fold resonates with 12,24,48.",
    },
    {
        "id": "L3-03", "name": "Multi-radix lobe ladder", "lens": "L3",
        "ell": 384, "m": 3, "n_sin": 384, "D": 384, "sampling": "Fibonacci",
        "Moebius": "frozen", "freq_sym": "multi-radix (3k + 4k + 5k)", "lobe_convention": "multi-radix",
        "rationale": "NEW: 3 radial symmetries combined. Tests whether multi-radix beats single 3-fold.",
    },

    # ----- L4: SIMPLIFICATION (MVP) -----
    {
        "id": "L4-01", "name": "Minimal viable, Fibonacci", "lens": "L4",
        "ell": 16, "m": 8, "n_sin": 2, "D": 256, "sampling": "Fibonacci",
        "Moebius": "frozen", "freq_sym": "3-fold", "lobe_convention": "3-fold",
        "rationale": "Smallest D that preserves 3-fold symmetry (256 = 3·85+1); broad envelope.",
    },
    {
        "id": "L4-02", "name": "Small D, high ell, broad envelope", "lens": "L4",
        "ell": 64, "m": 8, "n_sin": 4, "D": 128, "sampling": "Fibonacci",
        "Moebius": "frozen", "freq_sym": "3-fold", "lobe_convention": "3-fold",
        "rationale": "Tests whether low D + broad n_sin beats current high-D + extreme n_sin.",
    },

    # ----- L5: SAMPLING SHIFT -----
    {
        "id": "L5-01", "name": "Lebedev high-resolution", "lens": "L5",
        "ell": 64, "m": 4, "n_sin": 64, "D": 384, "sampling": "Lebedev",
        "Moebius": "frozen", "freq_sym": "3-fold", "lobe_convention": "3-fold",
        "rationale": "Swap Fibonacci for Lebedev (icosahedral quadrature). Tests whether Fibonacci's golden-angle was load-bearing.",
    },
    {
        "id": "L5-02", "name": "Icosahedral + 5-fold freq-sym", "lens": "L5",
        "ell": 60, "m": 5, "n_sin": 60, "D": 384, "sampling": "Icosahedral",
        "Moebius": "frozen", "freq_sym": "5-fold", "lobe_convention": "3-fold",
        "rationale": "Icosahedral sampling + 5-fold freq-sym: 5-fold resonates with 12 (60 has 12 as 12 = 5·12/5).",
    },

    # ----- L6: MÖBIUS RESTORATION -----
    {
        "id": "L6-01", "name": "Full PSL(2,C) per cycle", "lens": "L6",
        "ell": 384, "m": 3, "n_sin": 384, "D": 384, "sampling": "Fibonacci",
        "Moebius": "full-PSL", "freq_sym": "3-fold", "lobe_convention": "3-fold",
        "rationale": "Unfreeze Möbius: 6 real DOF per corpus. Tests if freeze-once was over-constrained (Section 3.4).",
    },
    {
        "id": "L6-02", "name": "Mid-DOF subgroup (4 DOF)", "lens": "L6",
        "ell": 384, "m": 3, "n_sin": 384, "D": 384, "sampling": "Fibonacci",
        "Moebius": "subgroup-4", "freq_sym": "3-fold", "lobe_convention": "3-fold",
        "rationale": "NEW: 4-DOF Möbius subgroup (between frozen and full PSL). Tests intermediate Möbius richness.",
    },

    # ============ CYCLE 2: NEW DIRECTIONS (6 candidates) ============

    # ----- L7: NEGATIVE-M-ONLY BASIS (Y_{l,-m} without positive m) -----
    {
        "id": "L7-01", "name": "Negative-m basis (Y_{l,-m} only)", "lens": "L7-negative-m",
        "ell": 12, "m": -12, "n_sin": 12, "D": 384, "sampling": "Fibonacci",
        "Moebius": "frozen", "freq_sym": "negative-m-only", "lobe_convention": "negative-m-only",
        "rationale": "Drops positive-m lobes; tests whether Y_{l,-m} alone spans the corpus. Since Y_{l,-m} is conjugate of Y_{l,m}, this is mathematically equivalent — but tests if the corpus responds to that parametrization.",
    },
    {
        "id": "L7-02", "name": "Negative-m basis + broad envelope", "lens": "L7-negative-m",
        "ell": 16, "m": -8, "n_sin": 4, "D": 384, "sampling": "Fibonacci",
        "Moebius": "frozen", "freq_sym": "negative-m-only", "lobe_convention": "negative-m-only",
        "rationale": "Negative-m basis with broader envelope (sin^4 θ). Tests whether a gentler negative-m-only basis captures the corpus differently.",
    },

    # ----- L8: SINGLE-RADIX ALTERNATIVES (drop 3-fold, try 4-fold / 5-fold / 2-fold alone) -----
    {
        "id": "L8-01", "name": "4-fold freq-sym alone (no 3-fold)", "lens": "L8-radix",
        "ell": 64, "m": 4, "n_sin": 64, "D": 384, "sampling": "Fibonacci",
        "Moebius": "frozen", "freq_sym": "4-fold", "lobe_convention": "4-fold (m_k=4k)",
        "rationale": "Drops 3-fold; keeps only 4-fold ladder (m_k=4k, k=1..96). Tests whether the corpus responds to 4-fold symmetry alone (no 3-fold component).",
    },
    {
        "id": "L8-02", "name": "5-fold freq-sym alone (no 3-fold)", "lens": "L8-radix",
        "ell": 60, "m": 5, "n_sin": 60, "D": 384, "sampling": "Fibonacci",
        "Moebius": "frozen", "freq_sym": "5-fold", "lobe_convention": "5-fold (m_k=5k)",
        "rationale": "Drops 3-fold; keeps only 5-fold ladder (m_k=5k, k=1..77). Resonates with icosahedral sampling; tests 5-fold symmetry.",
    },

    # ----- L9: LOW-D RANK HYPOTHESIS (corpus's actual rank may be much lower than 384) -----
    {
        "id": "L9-01", "name": "D=32 — extreme low rank test", "lens": "L9-rank",
        "ell": 32, "m": 3, "n_sin": 32, "D": 32, "sampling": "Fibonacci",
        "Moebius": "frozen", "freq_sym": "3-fold", "lobe_convention": "3-fold",
        "rationale": "D=32 tests whether the corpus's actual rank is 32 (not 384). If PC1+PC2 still clears 0.40, the corpus is far lower-rank than the current regime assumes.",
    },
    {
        "id": "L9-02", "name": "Per-tier Möbius (different phi per tier)", "lens": "L9-rank",
        "ell": [12, 384], "m": [12, 3], "n_sin": [12, 384], "D": 384, "sampling": "Fibonacci",
        "Moebius": "per-tier-independent", "freq_sym": "3-fold", "lobe_convention": "3-fold",
        "tier1_basis_dim": 4, "tier2_basis_dim": 384,
        "rationale": "NEW: each basis tier has its own Möbius phi. Tests whether independent refinement captures more of the corpus than shared phi.",
    },

    # ============ CYCLE 3: RANK HYPOTHESIS VERIFICATION (5 candidates) ============

    # ----- L10: D-SWEEP — find the inflection point where PC1+PC2 falls below 0.40 -----
    {
        "id": "L10-01", "name": "D=192 — between 256 and 384", "lens": "L10-rank-sweep",
        "ell": 384, "m": 3, "n_sin": 384, "D": 192, "sampling": "Fibonacci",
        "Moebius": "frozen", "freq_sym": "3-fold", "lobe_convention": "3-fold",
        "rationale": "D=192: between L4-01's 256 (P=65,792) and current 384 (P=147,840). Tests where the PC1+PC2 gate transitions from likely-pass to uncertain.",
    },
    {
        "id": "L10-02", "name": "D=128 — boundary case", "lens": "L10-rank-sweep",
        "ell": 384, "m": 3, "n_sin": 384, "D": 128, "sampling": "Fibonacci",
        "Moebius": "frozen", "freq_sym": "3-fold", "lobe_convention": "3-fold",
        "rationale": "D=128 at the boundary of 'uncertain' PC1+PC2. Tests whether the breakthrough survives a 3x parameter reduction from current.",
    },
    {
        "id": "L10-03", "name": "D=64 — extreme low D", "lens": "L10-rank-sweep",
        "ell": 384, "m": 3, "n_sin": 384, "D": 64, "sampling": "Fibonacci",
        "Moebius": "frozen", "freq_sym": "3-fold", "lobe_convention": "3-fold",
        "rationale": "D=64: extreme low D. If PC1+PC2 still clears 0.40, the corpus is far lower-rank than the current regime assumes.",
    },
    {
        "id": "L10-04", "name": "D=192 with 4-fold freq-sym", "lens": "L10-rank-sweep",
        "ell": 64, "m": 4, "n_sin": 64, "D": 192, "sampling": "Fibonacci",
        "Moebius": "frozen", "freq_sym": "4-fold", "lobe_convention": "4-fold (m_k=4k)",
        "rationale": "D=192 with 4-fold (no 3-fold). Tests whether the rank breakthrough survives alternative freq-sym.",
    },
    {
        "id": "L10-05", "name": "D=128 with Möbius subgroup-2", "lens": "L10-rank-sweep",
        "ell": 384, "m": 3, "n_sin": 384, "D": 128, "sampling": "Fibonacci",
        "Moebius": "subgroup-2", "freq_sym": "3-fold", "lobe_convention": "3-fold",
        "rationale": "D=128 with Möbius subgroup-2 (2-DOF). Tests whether the rank breakthrough survives Möbius variation.",
    },
]


# ============ CALCULATIONS + SCORING ============

def compute_metrics(c):
    """Compute constraint values for one candidate."""
    lobe_conv = c["lobe_convention"]
    D = c["D"]
    ell = c["ell"] if not isinstance(c["ell"], list) else c["ell"][-1]
    n_M = n_Moebius_for(c["Moebius"])

    # Per-item basis dim based on lobe convention
    if isinstance(c["ell"], list):
        # Multi-tier — sum tier basis dims
        if "tier1_basis_dim" in c and "tier2_basis_dim" in c:
            basis_dim = c["tier1_basis_dim"] + c["tier2_basis_dim"]
        else:
            basis_dim = D + D  # fallback
    elif "3-fold" in lobe_conv:
        basis_dim = D  # 3-fold ladder fills D lobes
    elif "all-m" in lobe_conv:
        basis_dim = D
    elif "4-fold" in lobe_conv or "5-fold" in lobe_conv or "2-fold" in lobe_conv or "7-fold" in lobe_conv:
        # Single-radix: D lobes but only every Nth m_k
        if "4-fold" in lobe_conv:
            basis_dim = D  # 4k fills D
        elif "5-fold" in lobe_conv:
            basis_dim = (D // 5) * 5  # round to multiple of 5
        elif "2-fold" in lobe_conv:
            basis_dim = D
        elif "7-fold" in lobe_conv:
            basis_dim = (D // 7) * 7
    elif "negative-m-only" in lobe_conv:
        basis_dim = D  # one lobe per m value (negative only)
    elif "mixed-radix" in lobe_conv:
        basis_dim = D  # 3k + 4k still fills D
    elif "multi-radix" in lobe_conv:
        basis_dim = D
    else:
        basis_dim = D

    # Per-tier-independent Möbius adds 6 DOF (one full PSL per tier beyond the shared frozen base)
    n_M = n_Moebius_for(c["Moebius"])
    if c["Moebius"] == "per-tier-independent" and isinstance(c["ell"], list):
        n_M = 6 * len(c["ell"])  # each tier gets its own phi_theta (6 DOF each)

    P = realized_P(D, basis_dim, n_M)

    # Basis set
    if isinstance(c["ell"], list):
        # Two-tier: union of tier-1 (m=12 only) + tier-2 (3-fold)
        basis_m_set = {12} | set(lobe_set_3fold(D))
    elif "all-m" in lobe_conv:
        s = lobe_set_all_m(D, ell)
        basis_m_set = s if s else set()
    elif "4-fold" in lobe_conv:
        basis_m_set = set(range(4, D+1, 4))
    elif "5-fold" in lobe_conv:
        basis_m_set = set(range(5, D+1, 5))
    elif "negative-m-only" in lobe_conv:
        basis_m_set = set(range(-D, 0))
    else:
        basis_m_set = lobe_set_3fold(D)

    # PC1+PC2 estimate
    gate = pc1_pc2_estimate(P)

    # Closes-target-gap (does basis include m=12?)
    closes_12 = closes_target_gap_12(basis_m_set)

    # Parseval per row at a=1 (max representative)
    pe_per_row = parseval_energy(Fraction(1), c["n_sin"] if not isinstance(c["n_sin"], list) else c["n_sin"][-1])

    # Möbius feasibility
    moebius_ok = c["Moebius"] in ("frozen", "full-PSL", "subgroup-2", "subgroup-4")

    # Energy equation fit (qualitative)
    eq_fit = {
        "eq:composition": "clean",
        "eq:flat": "clean" if not isinstance(c["n_sin"], list) else "clean (composite)",
        "eq:ridge": "clean",
        "eq:stereographic": "clean (sphere)" if "ell" not in c or not isinstance(c["ell"], list) else "clean (composite)",
        "eq:hyperspherical": "clean" if not isinstance(c["ell"], list) else "clean (multi-tier)",
    }

    # Cycle 3: breakthrough detection
    breakthrough = (P < 100000 and gate in ("likely-pass", "uncertain") and closes_12)
    D_ratio = float(Fraction(D, 384)) if D > 0 else 1.0

    return {
        "P_realized": P,
        "basis_dim_per_item": basis_dim,
        "P_vs_current_ratio": float(Fraction(P, 147840)) if 147840 > 0 else 0,
        "D_ratio": D_ratio,
        "n_Moebius": n_M,
        "PC1_PC2_gate": gate,
        "closes_n_12_gap": closes_12,
        "basis_m_count": len(basis_m_set),
        "Parseval_per_row_a_eq_1": float(pe_per_row),
        "Moebius_feasible": moebius_ok,
        "breakthrough": breakthrough,
        "energy_equation_fit": eq_fit,
    }


def score_candidate(c, metrics):
    """Score 1-10 per dimension."""
    scores = {}

    # Novelty (cycle 2): axes-different-from-current + mechanism-uniqueness
    current_axes = {"ell": 384, "m": 3, "n_sin": 384, "D": 384, "sampling": "Fibonacci", "Moebius": "frozen", "freq_sym": "3-fold"}
    axes_diff_count = 0
    axes_diff_weighted = 0
    weights = {"ell": 2, "m": 2, "n_sin": 1, "D": 1, "sampling": 2, "Moebius": 3, "freq_sym": 2}
    for k, w in weights.items():
        cv = current_axes.get(k)
        kv = c.get(k)
        if isinstance(kv, list):
            # multi-tier: count as differing if any tier differs
            if kv[0] != cv or (len(kv) > 1 and kv[1] != cv):
                axes_diff_count += 1
                axes_diff_weighted += w
        elif kv != cv:
            axes_diff_count += 1
            axes_diff_weighted += w
    # Mechanism-uniqueness: tests a mechanism no prior candidate tested
    mechanisms_tested = {
        "negative-m-only": any("negative" in str(c.get(k, "")) for k in ["lobe_convention", "freq_sym"]),
        "per-tier-Moebius": c.get("Moebius") == "per-tier-independent",
        "single-radix-4fold": c.get("freq_sym") == "4-fold",
        "single-radix-5fold": c.get("freq_sym") == "5-fold",
        "low-D-rank": c.get("D", 384) <= 128,
    }
    mechanism_count = sum(1 for v in mechanisms_tested.values() if v)
    scores["novelty"] = min(10, 3 + 2 * axes_diff_weighted + mechanism_count)

    # Gap-closing (does candidate close n=12 gap?)
    scores["gap_closing"] = 10 if metrics["closes_n_12_gap"] else 4

    # Energy equation fit (all clean → high)
    scores["energy_fit"] = 9 if all(v == "clean" or "clean" in v for v in metrics["energy_equation_fit"].values()) else 6

    # Feasibility (PC1+PC2 gate + Möbius)
    gate_score = {"likely-pass": 9, "uncertain": 6, "uncertain-to-fail": 3, "over-parameterized": 4}.get(metrics["PC1_PC2_gate"], 5)
    moebius_score = 10 if metrics["Moebius_feasible"] else 5
    scores["feasibility"] = (gate_score + moebius_score) // 2

    # Risk-inverse (10 - risks)
    risk = 0
    if metrics["P_realized"] < 5000:
        risk += 4  # under-parameterized
    if metrics["P_realized"] > 500000:
        risk += 3  # over-parameterized
    if c["sampling"] not in ("Fibonacci",):
        risk += 1  # sampling risk
    scores["risk_inverse"] = max(1, 10 - risk)

    scores["total"] = sum(scores.values())
    return scores


# ============ OUTPUT GENERATION ============

def render_ref_doc(candidates_scored, baseline, args):
    lines = []
    lines.append(f"# New Ideas — guided-curve-ideate output ({dt.date.today().isoformat()})")
    lines.append("")
    lines.append(f"**Source skill:** `guided-curve-ideate` (LOCAL ONLY, not committed)")
    lines.append(f"**Input catalog:** `{args.catalog}`")
    lines.append(f"**Output target:** `{args.output}`")
    lines.append(f"**Candidates generated:** {len(candidates_scored)}")
    lines.append("")
    lines.append("## Current instantiation baseline")
    lines.append("")
    lines.append("| Axis | Value |")
    lines.append("|---|---|")
    for k, v in baseline.items():
        lines.append(f"| {k} | {v} |")
    lines.append("")
    lines.append(f"**Realized P (correct accounting per v0.30 advisor):** {baseline['realized_P']:,}")
    lines.append(f"**Raw P (nominal full-basis, the error ideate-solo made):** {baseline['raw_P_per_v0_30_advisor']}")
    lines.append("")
    lines.append("## What this skill adds beyond prior slates")
    lines.append("")
    lines.append("The prior `ideate-solo` slate (v0.29) had 12 candidates but three structural errors (per v0.30 advisor):")
    lines.append("")
    lines.append("1. **Parameter counting used nominal full-basis sum** (`D·Σ(2ℓ+1)`) instead of realized P (`D·basis_dim + D + n_Möbius`). Every candidate's P was wrong by 6–360×.")
    lines.append("2. **Lobe convention was silently switched** between 3-fold ladder (m_k=3k) and all-m (m_k=k) mid-slate. Realized P moves by 6×.")
    lines.append("3. **No candidate tested primitive bootstrap** (response (a)) — the most likely correct response to the Set C gap.")
    lines.append("")
    lines.append("This skill fixes all three by:")
    lines.append("")
    lines.append("- Using realized P formula uniformly (`D·basis_dim + D + n_Möbius`)")
    lines.append("- Pinning the lobe convention per candidate (3-fold / all-m / mixed-radix / multi-radix)")
    lines.append("- Including NEW DIRECTIONS that test novel mechanisms:")
    lines.append("  - **Negative-m-only basis** (Y_{ℓ,-m} without positive m) — not in prior slates")
    lines.append("  - **Mixed-radix freq-sym** (3k + 4k combined) — fills the gap that prior \"freq-sym\" candidates didn't address")
    lines.append("  - **Per-tier Möbius** (different φ_θ per tier) — explicitly mentioned in v0.30 as a deferred gap")
    lines.append("  - **Mid-DOF Möbius subgroup** (4 DOF, between frozen and full PSL) — fills the 0/2/6 DOF gap from v0.30")
    lines.append("  - **Multi-radix lobe ladder** (3k + 4k + 5k combined) — tests whether single-radix beats multi-radix")
    lines.append("  - **All-m convention** at moderate ℓ=64 — switches from 3-fold ladder to m_k=k; tests lobe-convention sensitivity")
    lines.append("")
    lines.append("## Candidates by lens")
    lines.append("")
    lens_groups = {}
    for c, m, s in candidates_scored:
        lens_groups.setdefault(c["lens"], []).append((c, m, s))

    for lens_id in ["L1", "L2", "L3", "L4", "L5", "L6"]:
        if lens_id not in lens_groups:
            continue
        lines.append(f"### Lens {lens_id} — {lens_groups[lens_id][0][0]['lens']}")
        lines.append("")
        for c, m, s in lens_groups[lens_id]:
            lines.append(f"#### {c['id']} — {c['name']}")
            lines.append("")
            # Axes
            lines.append("**Axes:**")
            for k in ["ell", "m", "n_sin", "D", "sampling", "Moebius", "freq_sym"]:
                v = c[k]
                if isinstance(v, list):
                    v = str(v)
                lines.append(f"- {k}: {v}")
            lines.append(f"- lobe_convention: {c['lobe_convention']}")
            lines.append("")
            lines.append(f"**Rationale:** {c['rationale']}")
            lines.append("")
            # Calculations
            lines.append("**Calculations:**")
            lines.append(f"- basis_dim_per_item: {m['basis_dim_per_item']}")
            lines.append(f"- n_Möbius: {m['n_Moebius']}")
            lines.append(f"- P_realized: {m['P_realized']:,}")
            lines.append(f"- P_vs_current_ratio: {m['P_vs_current_ratio']:.4f}×")
            lines.append(f"- PC1+PC2_gate: {m['PC1_PC2_gate']}")
            lines.append(f"- closes_n_12_gap: {m['closes_n_12_gap']}")
            lines.append(f"- basis_m_count: {m['basis_m_count']}")
            lines.append(f"- Parseval_per_row_a_eq_1: {m['Parseval_per_row_a_eq_1']:.4g}")
            lines.append(f"- Möbius_feasible: {m['Moebius_feasible']}")
            lines.append("")
            lines.append("**Energy equation fit:**")
            for k, v in m["energy_equation_fit"].items():
                lines.append(f"- {k}: {v}")
            lines.append("")
            lines.append(f"**Score:** novelty={s['novelty']}, gap_closing={s['gap_closing']}, energy_fit={s['energy_fit']}, feasibility={s['feasibility']}, risk_inverse={s['risk_inverse']} → **total={s['total']}/50**")
            lines.append("")

    # Top picks
    sorted_cands = sorted(candidates_scored, key=lambda x: x[2]["total"], reverse=True)
    breakthrough_cands = [c for c in candidates_scored if c[1].get("breakthrough", False)]
    lines.append("## Breakthrough candidates (P < 100k AND likely-pass/uncertain PC1+PC2 AND closes_n_12)")
    lines.append("")
    if breakthrough_cands:
        bt_sorted = sorted(breakthrough_cands, key=lambda x: x[1]["P_realized"])
        for c, m, s in bt_sorted:
            lines.append(f"- **{c['id']} {c['name']}**: P={m['P_realized']:,}, D_ratio={m['D_ratio']:.3f}, score={s['total']}/50, PC1+PC2={m['PC1_PC2_gate']}, closes_n_12={m['closes_n_12_gap']}")
        lines.append("**" + str(len(breakthrough_cands)) + " breakthrough candidate(s)** found -- corpus appears over-parameterized at D=384.")
    else:
        lines.append("**No breakthrough candidates found this cycle.**")
    lines.append("")

    lines.append("## Top picks (ranked)")
    lines.append("")
    for i, (c, m, s) in enumerate(sorted_cands[:5], 1):
        lines.append(f"{i}. **{c['id']} — {c['name']}** (score {s['total']}/50)")
        lines.append(f"   - P={m['P_realized']:,}, PC1+PC2={m['PC1_PC2_gate']}, closes_n_12_gap={m['closes_n_12_gap']}, basis_m={m['basis_m_count']} lobes")
        lines.append(f"   - Why: {c['rationale'][:100]}...")
        lines.append("")

    # Test sequence
    lines.append("## Test sequence (recommended order)")
    lines.append("")
    lines.append("1. **Top-ranked candidate first** — run on existing 79-skill design matrix; check PC1+PC2 + Set C deferrals.")
    lines.append("2. **Top-2 and top-3 as attribution runs** — one-axis-at-a-time variations from current; each isolates a single mechanism.")
    lines.append("3. **Mid-DOF Möbius (L6-02) and multi-radix (L3-03) last** — they introduce NEW mechanisms; run only after the simpler ones succeed.")
    lines.append("")
    lines.append("For each candidate, the empirical signature is:")
    lines.append("")
    lines.append("- **PC1+PC2 ≥ 0.40 gate holds?** (current passes)")
    lines.append("- **Set C (n=12) deferrals count drops below 10/10?** (atomic primitive bootstrap)")
    lines.append("- **Per-item basis dim unchanged at 384?** (preserves current's expressivity)")
    lines.append("- **Möbius refit stable?** (per Section 3.4 — frozen unless corpus grows >25%)")
    lines.append("")
    lines.append("## Key assumptions to validate")
    lines.append("")
    lines.append("- [ ] The 3-fold lobe convention (m_k=3k) is correct for all current instantiation uses")
    lines.append("- [ ] The realized P formula is correct (D × basis_dim + D + n_Möbius)")
    lines.append("- [ ] The energy equation fits are accurate for multi-tier / mixed-radix candidates")
    lines.append("- [ ] The PC1+PC2 gate threshold (≥0.40) transfers to N=79 corpus")
    lines.append("- [ ] The candidate generation covers the relevant parameter space (no obvious gaps)")
    lines.append("")
    lines.append("## Audit trail")
    lines.append("")
    lines.append(f"- Generated {dt.datetime.now().isoformat()} via guided-curve-ideate")
    lines.append(f"- Source skill: session/guided-curve-ideate/SKILL.md")
    lines.append(f"- Implementation: session/guided-curve-ideate/scripts/ideate.py")
    lines.append(f"- Input: {args.catalog}")
    lines.append(f"- Output: {args.output}")
    lines.append(f"- LOCAL ONLY — not committed to any repo")

    return "\n".join(lines)


# ============ MAIN ============

def main():
    parser = argparse.ArgumentParser(description="Generate new curve parameterizations.")
    parser.add_argument("--catalog", default="/var/workspace/session/constraints-catalog-2026-08-09.md",
                        help="Constraints catalog (markdown).")
    parser.add_argument("--output", default="/var/workspace/session/guided-curve-ideate-output/new-ideas-cycle3.md",
                        help="Output ref doc path.")
    args = parser.parse_args()

    # Ensure output dir exists
    Path(args.output).parent.mkdir(parents=True, exist_ok=True)

    # Generate + score all candidates
    scored = []
    for c in CANDIDATES:
        m = compute_metrics(c)
        s = score_candidate(c, m)
        scored.append((c, m, s))

    # Render ref doc
    doc = render_ref_doc(scored, CURRENT, args)
    with open(args.output, "w") as f:
        f.write(doc)
    print(f"Wrote {len(doc)} bytes to {args.output}")

    # Also write JSON for programmatic access
    json_path = args.output.replace(".md", ".json")
    Path(json_path).parent.mkdir(parents=True, exist_ok=True)
    json_data = {
        "generated": dt.datetime.now().isoformat(),
        "baseline": CURRENT,
        "candidates": [
            {
                "id": c["id"], "name": c["name"], "lens": c["lens"], "rationale": c["rationale"],
                "axes": {k: c[k] for k in ["ell", "m", "n_sin", "D", "sampling", "Moebius", "freq_sym", "lobe_convention"]},
                "metrics": m,
                "scores": s,
            }
            for c, m, s in scored
        ],
    }
    with open(json_path, "w") as f:
        json.dump(json_data, f, indent=2)
    print(f"Wrote {os.path.getsize(json_path)} bytes to {json_path}")

    # Print top-3 to stdout
    sorted_scored = sorted(scored, key=lambda x: x[2]["total"], reverse=True)
    print("\n=== TOP 3 CANDIDATES ===")
    for c, m, s in sorted_scored[:3]:
        print(f"  {c['id']} {c['name']}: score {s['total']}/50, P={m['P_realized']:,}, closes_n_12={m['closes_n_12_gap']}")


if __name__ == "__main__":
    main()
