# Iteration cycle 1 snapshot

**Skill:** guided-curve-ideate
**Cycle:** 1 of 3 (final)
**Catalog:** constraints-catalog-2026-08-09.md
**Output:** new-ideas.md

## What's in this snapshot

- README.md (this file)
- SKILL.md (skill definition, latest)
- ideate.py (implementation, latest)
- constraints-catalog.md (catalog used)
- new-ideas.md (ref doc output)
- new-ideas.json (machine-readable)

LOCAL ONLY — no commits, no GitHub pushes, no Linear activity.
