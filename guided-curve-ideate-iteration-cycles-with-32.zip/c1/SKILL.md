# guided-curve-ideate

Generate new candidate parameterizations of the curve-2 (hyperspherical-harmonic) variant of the learned-latent-curve framework. Each candidate is a tuple `(ℓ, m, n_sin, D, sampling, Möbius, freq-sym)` with computed constraint values and a 5-lens score.

When to use: when the existing instantiation is known and you want to enumerate alternative parameterizations, especially when there's a known empirical finding (a gap, a residual, a deferred regime) to be addressed.

When NOT to use: when the gap is already known to be addressed by primitive bootstrap (response (a)) — just add the missing entry to the standard primitive ladder and re-run the classifier. When the gap is already addressed by Möbius refinement (response (c)) — re-fit φ_θ per Section 3.4.

## Inputs

A constraints catalog (markdown) defining:
- Current instantiation
- Axes of variation (7 axes)
- Calculation formulas (P, basis_dim, Parseval, regime coverage)

The skill reads `session/constraints-catalog-2026-08-09.md` by default. Override with `--catalog <path>`.

## Outputs

A markdown ref doc with:
1. Current instantiation baseline
2. **New directions** not in prior slates (the skill's contribution)
3. **Lens-by-lens candidates** with full constraint calculations
4. **Top picks** ranked by composite score
5. **Test sequence** for the picks
6. **Key assumptions to validate**

The ref doc lands at `session/guided-curve-ideate-output/new-ideas.md` by default.

## Algorithm — 6 lenses

The skill generates 12-18 candidates across 6 lenses. Each lens maps to a different strategy for varying the constraint set:

### L1 — Inversion
The opposite extreme of the current. Current uses `n_sin=384` (extreme equator-peaked); invert to `n_sin ∈ {1, 2, 3}` (uniform / gentle / standard) AND/OR swap `(ℓ, m)` orderings per line 124.

### L2 — Constraint removal
Minimal ℓ that includes the target mode. If the gap is at n=12, the smallest ℓ that includes m=12 is `ℓ=12` (with m ∈ {0..12}, so 25 lobes under the all-m convention, or 4 lobes under the 3-fold convention).

### L3 — Combination
Two-tier or multi-radix combinations. E.g., `(ℓ=12 + ℓ=384)` dual basis, or `m_k = mixed (3k + 4k)` to cover both branches.

### L4 — Simplification
Minimum viable parameterization. D=64, broad envelope, low ℓ, Fibonacci sampling. Tests whether the corpus's structure is captured by a small basis.

### L5 — Sampling shift
Non-Fibonacci sampling patterns. Lebedev (uniform-area), Icosahedral (5-fold), Equidistant cylindrical (pole-clustering), or mixed. Tests whether Fibonacci's golden-angle was load-bearing.

### L6 — Möbius restoration
Full PSL(2,ℂ) (6 DOF) or restricted subgroup (2-4 DOF) instead of frozen. Tests whether freeze-once was over-constrained.

## Constraint calculations per candidate

For each (ℓ, m, n_sin, D, sampling, Möbius, freq-sym) candidate:

1. **Lobe set**: the set of m_k values in the per-item basis. Two conventions:
   - **3-fold ladder** (paper line 124 default): `m_k = 3k, k=1..K` where `K = D/3` → per-item basis dim = D
   - **All-m convention** (`m_k = k, k=1..D`) → per-item basis dim = D, but only valid if `D ≤ 2ℓ+1` AND `m_k ≤ ℓ`
2. **Realized parameter count**: `P = D · basis_dim + D + n_Möbius`
   - Full PSL(2,ℂ): `n_Möbius = 6`
   - Restricted subgroup: `n_Möbius ∈ {2, 4}`
   - Frozen: `n_Möbius = 0`
3. **PC1+PC2 gate estimate** (qualitative): pass if `P ≈ 148k` (current); likely-pass if `50k < P < 200k`; uncertain if `P < 10k`; fail if `P < 1k`.
4. **Parseval energy estimate** at one row: `‖z‖² = a² + b² = a²(1+n²)` if `b = n·a` (current's structural assumption).
5. **Closes-target-gap**: yes / partial / no, based on whether the candidate's basis covers the target m (e.g., n=12).
6. **Möbius feasibility**: yes / no, depending on whether the candidate needs re-fit per cycle (N<30 or growth>25%) or stays frozen.
7. **Energy equation fit** (eq:composition, eq:flat, eq:ridge, eq:stereographic, eq:hyperspherical): clean / loose / none per candidate.

## Scoring rubric (1-10 each)

- **Novelty**: how different from current and from prior slates
- **Gap-closing**: how directly the candidate addresses the known gap (or analogous gap)
- **Energy-fit**: how cleanly the energy equations fit
- **Feasibility**: PC1+PC2 gate estimate + Möbius feasibility + computational cost
- **Risk-inverse**: 10 minus (over-parameterization risk + under-parameterization risk + sample-clustering risk)

Composite score = sum, max 50.

## Output format

The ref doc is structured as:

```markdown
# New Ideas — guided-curve-ideate output (date)

## Current instantiation baseline
(table)

## Lens-by-lens candidates (12-18)
### L1 candidate 01: <name>
- axes, calculations, scoring
### L2 candidate 02: ...
...
### L6 candidate N: ...

## Top picks (3-5, ranked)

## Test sequence (ordered)

## Key assumptions to validate

## What this skill adds beyond prior slates
```

## Self-containment

This skill reads only:
- The constraints catalog at `session/constraints-catalog-2026-08-09.md` (or override)
- Python stdlib (no external deps beyond `fractions`, `argparse`, `hashlib`, `pathlib`)

It does NOT depend on:
- External skill files (no `## Pair with` references)
- Skill registry / auto-registration
- GitHub API / Linear API
- The prior `ideate-solo` output

## Constraints

- LOCAL ONLY by default. The skill writes to `session/guided-curve-ideate-output/`.
- No GitHub commits. No Linear activity. No external calls.
- The Python script uses only stdlib + `fractions` for exact arithmetic.

## Maintainer

Built 2026-08-09 per Jenny's directive ("first lets test it to make a new self contained skill locally called guided-curve-ideate"). Local-only — not shipped to GitHub.
