# Iteration cycle 3 snapshot

**Skill:** guided-curve-ideate
**Cycle:** 3 of 3 (final)
**Catalog:** constraints-catalog-2026-08-09-cycle3.md
**Output:** new-ideas-cycle3.md

## What's in this snapshot

- README.md (this file)
- SKILL.md (skill definition, latest)
- ideate.py (implementation, latest)
- constraints-catalog-cycle3.md (catalog used)
- new-ideas-cycle3.md (ref doc output)
- new-ideas-cycle3.json (machine-readable)

LOCAL ONLY — no commits, no GitHub pushes, no Linear activity.
