# Constraints Catalog — 2026-08-09 cycle 3 (rank verification)

**Cycle:** 3 (verifying the rank breakthrough from cycle 2)
**Driver:** L4-01 in cycle 2 (D=256) achieved score 48/50 with P=65,792 — half of current's P with likely-pass PC1+PC2. This suggests the corpus is over-parameterized at D=384. Cycle 3 verifies this hypothesis by testing D ∈ {24, 48, 64, 96, 128, 160, 192, 224, 256, 320} across different axes.

## Cycle 2 → Cycle 3 refinements

Cycle 2's breakthrough was a low-D finding (L4-01 D=256 → P=65,792). Cycle 3:
1. Adds **breakthrough detection** to the rubric: candidates with P < current AND likely-pass PC1+PC2 AND closes_n_12 are flagged.
2. Adds **D-sweep candidates** between 24 and 320 to find the inflection point where PC1+PC2 falls below 0.40.
3. Tests whether the breakthrough is **robust across axes**: same low-D with different sampling, freq-sym, Möbius.

## Current operational instantiation (UNCHANGED — same as cycle 1)

| Axis | Value |
|------|-------|
| ℓ | 384 |
| m | 3 |
| sin^n θ polar | n = 384 |
| D | 384 |
| Realized P | 147,840 |

## Cycle 3 new candidates (5 added)

| ID | What it tests |
|----|---------------|
| L10-01 | D=192 — between L4-01's 256 and current 384; find the inflection point |
| L10-02 | D=128 — at the boundary of "uncertain" PC1+PC2 |
| L10-03 | D=64 — extreme low D; tests rank hypothesis at small scale |
| L10-04 | D=192 with 4-fold freq-sym — tests if breakthrough survives alternative symmetry |
| L10-05 | D=128 with Möbius unfrozen (subgroup-2) — tests if breakthrough survives Möbius variation |

## Cycle 3 calculations

Identical to cycle 2, plus:

- **breakthrough_flag** (NEW): True if `P < 100,000 AND PC1+PC2 ∈ {likely-pass, uncertain} AND closes_n_12`
- **D_ratio** (NEW): `D / D_current` (how much smaller than current)

## Cycle 3 stop criteria (BREAKTHROUGH DEFINITION)

A candidate is a "major breakthrough" if it satisfies ALL of:
1. P < 100,000 (less than 70% of current)
2. PC1+PC2 likely-pass or uncertain (above "uncertain-to-fail")
3. closes_n_12 (or analog target)
4. Different from current on at least one major axis (ℓ, D, sampling, Möbius)

If at least 3 candidates meet this, STOP and build the final ZIP.
