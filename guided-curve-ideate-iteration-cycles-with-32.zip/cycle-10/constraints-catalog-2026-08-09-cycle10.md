# Constraints Catalog — 2026-08-09 cycle 10

**Cycle:** 10 (applies top 3 new ideas from cycle 9)
**Driver:** close cycle-9 limitations — NSS calibration, cross-validation, systematic sweep.

## Cycle-9 limitations addressed

1. **NSS calibration identified but not applied** → cycle-10 L28 drops 10 inactive NSS axes
2. **Single-split selector** → cycle-10 L29 uses k-fold CV (k=5)
3. **Curated hybrid set** → cycle-10 L30 uses systematic 512-pattern sweep

## Current operational instantiation (UNCHANGED)

| Axis | Value |
|---|---|
| ℓ | 384 |
| m | 3 |
| sin^n θ polar | n = 384 |
| D | 384 |
| Sampling | Fibonacci (Vogel's golden-angle) |
| Möbius | frozen (refine-once at corpus creation) |
| freq_sym | 3-fold (m_k = 3k, k=1..128) |
| Per-item basis dim | 384 |
| Realized P | 147,840 |

## Cycle-10 axes (NEW)

- **Axis 24 — NSS calibration**: drop 10 inactive NSS axes (mode, assumption_set, adjacent_problems, failure_modes, lifecycle, composition, knowledge_sources, calibration, inputs, outputs), keep only 2 active (audience, recursion). Calibrated 11-D (9 prim + 2 NSS) and 14-D (9 prim + 2 NSS + 3 meta).
- **Axis 25 — k-fold CV**: k=5 cross-validation instead of single 80/20 split.
- **Axis 26 — Systematic 512-pattern sweep**: all 2⁹ binary weight patterns.

## Cycle-10 lens coverage

| Lens | Tests | Source |
|---|---|---|
| L28 — NSS calibration | 6 candidates on calibrated 11-D and 14-D | Cycle-9 L26 found 8 of 12 axes at 0% coverage |
| L29 — Cross-validation (k=5) | 15 folds (3 corpora × 5 folds) | Cycle-9 L24 used single split |
| L30 — Systematic 512-pattern sweep | 1503 candidates (501 non-degenerate × 3 corpora) | Cycle-9 L25 used 12 hand-picked hybrids |

## Cycle-10 calculations

Identical to cycle-9, plus:
- **Calibrated 11-D**: 9 primitives + 2 active NSS (audience, recursion)
- **Calibrated 14-D**: 9 primitives + 2 active NSS + 3 run-metadata (cycle, delta, FIRES)
- **k-fold CV**: k=5 folds, seed=42, per-fold selector accuracy
- **Systematic 512 sweep**: all 2⁹ binary weight patterns, excluding degenerate (1-primitive) and uniform (9-primitive)

## Audit trail

- Generated 2026-08-09T22:50:00
- Source: cycle-9 limitations (cycle-10 closes them)
- Output: new-ideas-cycle10.md
