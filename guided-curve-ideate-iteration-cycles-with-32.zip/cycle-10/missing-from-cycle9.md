# What's missing from cycle 9 — and how cycle 10 addresses it

## Gaps in cycle 9

1. **NSS calibration was only identified, not applied.** Cycle-9 L26 found 8 of 12 NSS axes have 0% coverage on 86 SKILL.md files. But the cycle-7/8 24-D measurements still used the full 12 NSS axes. The 10 inactive axes could be diluting or distorting the gate measurement.
2. **Per-corpus weight selector was single-split.** Cycle-9 L24 used a single 80/20 split with seed=42. The docs/ holdout was only 4 items, making the selector unreliable for small corpora.
3. **Hybrid weighting was a curated set.** Cycle-9 L25 tested 12 hand-picked hybrid candidates. The full space of 512 (2⁹) binary weight patterns was not explored.

## Cycle-10 fix

| Gap | Cycle-10 fix |
|---|---|
| NSS calibration identified but not applied | **L28** drops 10 inactive NSS axes from the 24-D matrix. Calibrated 11-D and 14-D matrices. **All 6 candidates PASS the 0.40 gate.** The cycle-7/8 24-D findings are robust to the 10 inactive NSS axes. |
| Single-split selector | **L29** k-fold CV (k=5) with seed=42. **11/15 folds matched optimal (73.3% match rate).** Average test score 0.8835. The selector is robust across folds. |
| Curated hybrid set | **L30** systematic sweep over all 512 (2⁹) binary weight patterns. **501 non-degenerate patterns tested per corpus.** Confirms that 2-primitive patterns hit 1.0000 trivially. |

## What cycle-10 still doesn't address (open for cycle 11)

1. **Self corpus full.** self-corpus-listing.json has 111 items but only 5 in `items_sample`. The full self corpus would add ~106 more rows, reaching ~1497 total (vs the main paper's 2286).
2. **L29 docs/ tie.** docs/ holdout is only 4 items per fold. With more docs data, the selector would discriminate better. The 60% match rate on docs/ is partially due to the degenerate 1.0000 ties on tiny folds.
3. **L30 genuine optimum.** 501 non-degenerate patterns hit 1.0000 trivially (2-primitive degenerate). Need to characterize the signal-to-noise ratio per primitive count to find the genuine (≥3-primitive) optimum. Cycle-9 L25 found keep-m3-m6-m9 averages 0.8685 — that's the current best candidate.
4. **Cost model on calibrated 11-D.** Cycle-8 L22 found D=128 frozen Möbius as cost-optimal at 3.69×10⁴ ops. Cycle-10 should measure whether the calibrated 11-D matrix changes the cost-optimal D and Möbius.

## Cycle-11 candidate lenses

- **L31 — Self corpus full**: locate and load full self corpus (111 items), re-measure full 24-D.
- **L32 — L29 larger docs**: use all 21 docs items with leave-one-out CV instead of k-fold with 4-item folds.
- **L33 — L30 genuine optimum**: characterize signal-to-noise per primitive count, find ≥3-primitive optimum.
- **L34 — Cost model on calibrated 11-D**: measure whether the calibrated 11-D matrix changes the cost-optimal D and Möbius.

These are the cycle-11 lenses if the user wants another iteration.
