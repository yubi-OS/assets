# Iteration cycle 10 snapshot — MEASURED, top new ideas applied

**Skill:** guided-curve-ideate
**Cycle:** 10 of 10 (final, measured)
**Catalog:** constraints-catalog-2026-08-09-cycle10.md
**Output:** new-ideas-cycle10.md
**Measurement backend:** inline sweep via `run_script` (sandbox executor) over `empirical_gate.py` (cycle-4 adapter)

## What's new vs cycle 9

Cycle 10 applies the top 3 new ideas from cycle 9:

| Cycle-9 top pick | Cycle-10 application |
|---|---|
| L26: 8 of 12 NSS axes have 0% coverage | **L28** drop 10 inactive NSS axes, re-measure cycle-7/8 24-D with only 2 active NSS axes (audience, recursion) |
| L24: 2/3 matched optimal on single 80/20 split | **L29** k-fold CV (k=5) instead of single 80/20 split |
| L25: 12 hybrid candidates, single-primitive hits 1.0000 (degenerate) | **L30** systematic sweep over all 512 (2⁹) weight patterns |

## Headline findings

1. **L28 — NSS calibration preserves the gate**: 6/6 PASS on calibrated 11-D and 14-D matrices. **The cycle-7/8 24-D findings are robust to the 10 inactive NSS axes.** W19-on-9D-only achieves PC1+PC2 = 0.6892 on calibrated 11-D (still PASS).

2. **L29 — Cross-validation (k=5)**: **11/15 folds matched optimal** (73.3% match rate). Average test score **0.8835** across all 15 folds. The per-corpus weight selector is robust across folds.

3. **L30 — Systematic 512-pattern sweep**: 501 non-degenerate patterns tested per corpus. **Many 2-primitive patterns hit 1.0000 on all 3 corpora** (degenerate — PCA concentrates perfectly with rank ≤ 2 input). **Genuine gate improvements require ≥3 active primitives.**

## What's in this snapshot

- README.md (this file)
- SKILL.md (skill definition, with cycle-10 lenses L28 + L29 + L30)
- empirical_gate_results_cycle10.json — measured values for 1524 candidates
- constraints-catalog-2026-08-09-cycle10.md (cycle-10 axes)
- new-ideas-cycle10.md (ref doc)
- new-ideas-cycle10.json (machine-readable)
- missing-from-cycle9.md (gap doc from cycle-10 generation)

LOCAL ONLY — no commits, no GitHub pushes, no Linear activity.

## Cycle progression

| Cycle | Frontier | Best measured PC1+PC2 |
|---|---|---:|
| 1–3 | qualitative baseline | — |
| 4 | empirical_gate + mixed-radix (3+4) | 0.6901 |
| 5 | L13 column-weight sweep | 0.8080 |
| 6 | L15 Pareto + L16 cross-corpus + L17 synthetic 24-D | 0.8080 |
| 7 | L18 real 24-D (skills 474) + L19 corpus-adaptive + L20 per-corpus Möbius | 0.8538 (docs) / 0.7925 (real 24-D) |
| 8 | L21 full real 24-D (1391) + L22 per-corpus Pareto + L23 finer-grained NSS | 0.8538 (docs) / 0.7632 (full real 24-D) |
| 9 | L24 selector + L25 hybrid + L26 NSS validation + L27 SELF.md | 0.8857 (L24 avg) / 0.8685 (L25 keep-m3-m6-m9) |
| **10** | **L28 NSS calibration + L29 cross-validation + L30 systematic 512-pattern sweep** | **1.0000 (L30 2-primitive)** / **0.9802 (L29 docs W19)** |

## What cycle-10 settled

1. **The gate is robust to the 10 inactive NSS axes.** Cycle-7/8 24-D findings hold with only 2 active NSS axes (audience, recursion).
2. **The per-corpus weight selector is robust across folds.** 73.3% match rate across 15 folds, average test score 0.8835.
3. **2-primitive patterns hit 1.0000 trivially.** Genuine gate improvements require ≥3 active primitives.

## What's still open

- **Self corpus full**: 111 items in self-corpus-listing.json but only 5 in items_sample. Need full 111 to reach main paper's 2286.
- **L29 docs/ tie**: docs/ holdout is too small (4 items per fold).
- **L30 genuine optimum**: characterize signal-to-noise per primitive count to find genuine (≥3-primitive) optimum.

## Audit trail

- Generated 2026-08-09T22:50:00 via guided-curve-ideate (cycle-10, measured)
- Source skill: session/guided-curve-ideate/SKILL.md
- Implementation: inline sweep (cycle-10 driver)
- Active NSS axes (from cycle-9 L26): audience, recursion
- Zero-coverage NSS axes (dropped in L28): mode, assumption_set, adjacent_problems, failure_modes, lifecycle, composition, knowledge_sources, calibration
- L29: k=5 cross-validation, seed=42
- L30: 512-pattern sweep, 501 non-degenerate per corpus
- Input: /var/workspace/session/zip_digest/cycle-10/constraints-catalog-2026-08-09-cycle10.md
- Output: /var/workspace/session/zip_digest/cycle-10/new-ideas-cycle10.md
- LOCAL ONLY — not committed to any repo
