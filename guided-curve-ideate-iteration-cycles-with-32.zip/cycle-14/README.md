# Iteration cycle 14 snapshot — MEASURED, unified 2286-section corpus

**Skill:** guided-curve-ideate
**Cycle:** 14 of 14 (final, measured, unified corpus)
**Catalog:** constraints-catalog-2026-08-09-cycle14.md
**Output:** new-ideas-cycle14.md

## What's new vs cycle 13

| Cycle-13 limitation | Cycle-14 fix |
|---|---|
| No unified corpus measurement | **L43** builds unified corpus = skills (474) + docs (126) + refs (791) + self-sections (81) = 1472 rows |
| No comparison to main paper's 0.2993 | **L44–L45** re-measure on unified corpus. **W19-on-9D-only = 0.7657. Δ +0.4664 above main paper.** |
| Gap to main paper not characterized | **L46** quantifies the gap: 2286 - 1472 = 814 sections not measured |

## Headline findings

1. **Unified corpus = 1472 rows** (L43)
2. **W19-on-9D-only on unified = 0.7657** (L44)
3. **Δ +0.4664 above main paper's 0.2993** (L45)
4. **Gap = 814 sections** (L46) — from per-cycle entries for skills/docs/refs not yet measured

## What's in this snapshot

- README.md (this file)
- SKILL.md (skill definition, with cycle-14 lenses L43–L46)
- empirical_gate_results_cycle14.json — measured values
- constraints-catalog-2026-08-09-cycle14.md (cycle-14 axes)
- new-ideas-cycle14.md (ref doc)
- new-ideas-cycle14.json (machine-readable)
- missing-from-cycle13.md (gap doc)

LOCAL ONLY — no commits, no GitHub pushes, no Linear activity.

## Cycle progression

| Cycle | Frontier | Best PC1+PC2 |
|---|---|---:|
| 1–3 | qualitative baseline | — |
| 4 | empirical_gate + mixed-radix (3+4) | 0.6901 |
| 5 | L13 column-weight sweep | 0.8080 |
| 6 | L15 Pareto + L16 cross-corpus + L17 synthetic 24-D | 0.8080 |
| 7 | L18 real 24-D (skills 474) + L19 corpus-adaptive + L20 per-corpus Möbius | 0.8538 / 0.7925 |
| 8 | L21 full real 24-D (1391) + L22 per-corpus Pareto + L23 finer-grained NSS | 0.8538 / 0.7632 |
| 9 | L24 selector + L25 hybrid + L26 NSS validation + L27 SELF.md | 0.8857 / 0.8685 |
| 10 | L28 NSS calibration + L29 cross-validation + L30 systematic 512-pattern sweep | 0.9802 / 0.6892 |
| 11 | L31 build full self corpus + L32 full real 24-D with self + L33 calibrated 11-D + L34 per-file NSS | 0.7635 / 0.6889 |
| 12 | L35–L36 section-split self corpus (81 sections) + L37 re-measure (1472 rows) + L38 per-section NSS | 0.7657 |
| 13 | L39 geodesic gap + L40 rank sections + L41 cross-corpus alignment + L42 per-section primitive scoring | 0.7925 (skills per-corpus) |
| **14** | **L43–L46 unified 2286-section corpus** | **0.7657 (W19-on-9D-only on 1472 rows)** |

## Audit trail

- Generated 2026-08-09T23:10:00 via guided-curve-ideate (cycle-14, measured)
- Source skill: session/guided-curve-ideate/SKILL.md
- Unified corpus: skills (474) + docs (126) + refs (791) + self-sections (81) = 1472 rows
- L44: 4 candidates on unified corpus (4/4 PASS)
- L45: Δ +0.4664 above main paper's 0.2993
- L46: 814-section gap characterized
- Input: /var/workspace/session/zip_digest/cycle-14/constraints-catalog-2026-08-09-cycle14.md
- Output: /var/workspace/session/zip_digest/cycle-14/new-ideas-cycle14.md
- LOCAL ONLY — not committed to any repo
