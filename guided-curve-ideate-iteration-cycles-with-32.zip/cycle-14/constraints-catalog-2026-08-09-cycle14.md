# Constraints Catalog — 2026-08-09 cycle 14

**Cycle:** 14 (unified 2286-section corpus)
**Driver:** close cycle-13 limitations — build unified corpus, compare to main paper.

## Cycle-13 limitations addressed

1. **No unified corpus measurement** → cycle-14 L43 builds unified corpus = 1472 rows
2. **No comparison to main paper's 0.2993** → cycle-14 L44–L45 re-measure and compare
3. **Gap to main paper not characterized** → cycle-14 L46 quantifies the gap (814 sections)

## Cycle-14 axes (NEW)

- **Axis 36 — Unified corpus**: skills (474) + docs (126) + refs (791) + self-sections (81) = 1472 rows
- **Axis 37 — Comparison to main paper**: Δ from main paper's 0.2993 measurement
- **Axis 38 — Gap characterization**: 2286 - 1472 = 814 sections not measured

## Cycle-14 lens coverage

| Lens | Tests | Source |
|---|---|---|
| L43 — Unified corpus | 1472 rows from 4 corpora | Cycle-13 measured separately |
| L44 — Re-measure | 4 candidates on 1472 rows | Cycle-13 had separate measurements |
| L45 — Compare to main paper | Δ from 0.2993 | New |
| L46 — Close gap | 814-section gap characterization | New |

## Audit trail

- Generated 2026-08-09T23:10:00
- Source: cycle-13 limitations (cycle-14 closes them)
- Output: new-ideas-cycle14.md
