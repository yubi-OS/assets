# New Ideas — guided-curve-ideate output (2026-08-09, cycle 12 — MEASURED, self corpus section-split)

**Source skill:** `guided-curve-ideate` (LOCAL ONLY, not committed)
**Input catalog:** `/var/workspace/session/zip_digest/cycle-12/constraints-catalog-2026-08-09-cycle12.md`
**Measurement backend:** `empirical_gate.py` (cycle-4 adapter) over `papers/scripts/fit-full-curve-map.py`
**Self corpus source:** `/var/workspace/memory/personal-WbtUgeUv/` — section-split into 81 entries
**Candidates measured:** 81 (self sections) + 4 (L37 full-corpus) + 972 (L38 per-section NSS)
**Output target:** `/var/workspace/session/zip_digest/cycle-12/new-ideas-cycle12.md`

## Cycle progression (cumulative)

| Cycle | Lens frontier | Best measured PC1+PC2 | Δ over baseline (0.6637) |
|---|---|---:|---:|
| 1–3 | qualitative baseline | — | — |
| 4 | empirical_gate + mixed-radix (3+4) | 0.6901 | +0.0264 |
| 5 | L13 column-weight sweep | 0.8080 | +0.1443 |
| 6 | L15 Pareto combined + L16 cross-corpus + L17 synthetic 24-D | 0.8080 | +0.1443 |
| 7 | L18 real 24-D (skills 474) + L19 corpus-adaptive + L20 per-corpus Möbius | 0.8538 (docs) / 0.7925 (real 24-D) | +0.4932 (real 24-D) |
| 8 | L21 full real 24-D (1391) + L22 per-corpus Pareto + L23 finer-grained NSS | 0.8538 (docs) / 0.7632 (full real 24-D) | +0.4639 (full real 24-D) |
| 9 | L24 selector + L25 hybrid + L26 NSS validation + L27 SELF.md | 0.8857 (L24 avg) / 0.8685 (L25 keep-m3-m6-m9) | +0.3363 (L24 avg) |
| 10 | L28 NSS calibration + L29 cross-validation + L30 systematic 512-pattern sweep | 0.9802 (L29 docs W19) / 0.6892 (L28 calibrated W19) | +0.3165 (L28) |
| 11 | L31 build full self corpus + L32 full real 24-D with self + L33 calibrated 11-D with self + L34 per-file NSS | 0.7635 (L32) / 0.6889 (L33) | +0.0998 (L32) |
| **12** | **L35–L36 section-split self corpus (34 + 47 = 81 sections) + L37 re-measure (1472 rows) + L38 per-section NSS** | **0.7657 (L37 W19-on-9D-only)** | **+0.1020** |

## Top new ideas from cycle 11 → cycle 12 applied

| Cycle-11 limitation | Cycle-12 fix |
|---|---|
| Self corpus was 10 files = 10 items (too coarse) | **L35** splits SELF-CHANGELOG.md into 34 sections using `## YYYY-MM-DD — vN.N — Title` headers |
| Other self files treated as single items | **L36** splits SELF.md, USER_PREFERENCES.md, SAUNA_TOOLS.md, RULES.md, COMPANY.md into per-section entries (47 total) |
| Full real 24-D measured on 1401 rows (file-level self) | **L37** re-measures on 1472 rows (section-level self) |
| Per-file NSS scoring (10 files × 12 axes = 120) | **L38** per-section NSS scoring (81 sections × 12 axes = 972) |

## L35 — SELF-CHANGELOG.md section-splitting (34 sections)

SELF-CHANGELOG.md uses `## YYYY-MM-DD — vN.N — Title` headers. The regex `^## (\d{4}-\d{2}-\d{2}) — (v[\d.]+) — (.+?)$` finds **34 sections** spanning 2026-07-31 → 2026-08-09.

**First 5 sections:**
| Section ID | Chars | NSS axes |
|---|---:|---|
| SELF-CHANGELOG:2026-07-31:v0.1 | 1,775 | 2/12 |
| SELF-CHANGELOG:2026-07-31:v0.2 | 1,514 | 0/12 |
| SELF-CHANGELOG:2026-07-31:v0.3 | 1,496 | 0/12 |
| SELF-CHANGELOG:2026-07-31:v0.4 | 1,054 | 0/12 |
| SELF-CHANGELOG:2026-07-31:v0.5 | 3,542 | 1/12 |

**Last 3 sections:**
| Section ID | Chars | NSS axes |
|---|---:|---|
| SELF-CHANGELOG:2026-08-09:v0.31 | 4,464 | 0/12 |
| SELF-CHANGELOG:2026-08-09:v0.32 | 3,367 | 0/12 |
| SELF-CHANGELOG:2026-08-09:v0.33 | 9,436 | 1/12 |

**Total: 34 sections, ~106K chars** (vs the 226K-char file treated as 1 item in cycle-11).

## L36 — Other self files section-splitting (47 sections)

| File | Sections | Notes |
|---|---:|---|
| SELF.md | 9 | Soul, Strengths, Biases, Anti-patterns, etc. |
| USER_PREFERENCES.md | 14 | Per-preference sections |
| SAUNA_TOOLS.md | 6 | Tool registry sections |
| RULES.md | 10 | Per-rule sections |
| COMPANY.md | 8 | Per-section breakdown |

**Total: 47 sections across 5 files.**

## L37 — Re-measure with section-split self corpus (1472 rows)

Concatenating skills (474) + docs (126) + refs (791) + self-sections (81) = **1472 rows × 24 columns**.

| ID | Weights | PC1+PC2 | Gate |
|---|---|---:|---|
| L37-uniform-24d-sections | uniform | 0.6446 | PASS |
| L37-W18-24d-sections | `[1,1,1,0,0,1,0,0,1,0,...,1,1,1]` | 0.7363 | PASS |
| L37-W19-24d-sections | `[0,0,0,1,1,0,1,1,0,0,...,1,1,1]` | 0.7016 | PASS |
| **L37-W19-on-9D-only-24d-sections** | `[0,0,0,1,1,0,1,1,0,0,...,0,0,0]` | **0.7657** | PASS |

**4/4 PASS.** W19-on-9D-only on the 1472-row section-split corpus = **0.7657** (Δ +0.0025 from cycle-8's 0.7632, Δ +0.0022 from cycle-11's 0.7635 file-level). Section-splitting adds 71 more rows (file-level: 10, section-level: 81) and gives a small gate improvement.

## L38 — Per-section NSS scoring (972 measurements)

81 sections × 12 NSS axes = 972 measurements. Global coverage:

| NSS axis | Sections activating | Coverage |
|---|---:|---:|
| **audience** | 29/81 | 35.8% |
| **recursion** | 31/81 | 38.3% |
| inputs | 2/81 | 2.5% |
| outputs | 5/81 | 6.2% |
| mode | 0/81 | 0.0% |
| assumption_set | 0/81 | 0.0% |
| adjacent_problems | 0/81 | 0.0% |
| failure_modes | 0/81 | 0.0% |
| lifecycle | 0/81 | 0.0% |
| composition | 0/81 | 0.0% |
| knowledge_sources | 0/81 | 0.0% |
| calibration | 0/81 | 0.0% |

**Only 2 NSS axes activate on the self corpus: audience (35.8%) and recursion (38.3%).** This is *fewer* than the 4 axes that activated on the file-level self corpus (cycle-11 L34). Section-splitting reduces NSS activation because shorter sections are less likely to match the regex patterns.

## Combined cycle-12 recommendation

**Best gate-improvement**: L37-W19-on-9D-only → PC1+PC2 = **0.7657** on the 1472-row section-split corpus. Δ +0.0025 from cycle-8.

**Section-splitting finding**: SELF-CHANGELOG.md's 34 sections expose the temporal trajectory of self-development. Per-section NSS is sparser than per-file NSS (2 axes vs 4 axes) because shorter sections are less likely to match the regex patterns.

## Key assumptions (now measurable)

- [x] SELF-CHANGELOG.md splits into 34 sections via `## YYYY-MM-DD — vN.N — Title` regex
- [x] Other self files split into 47 sections via `## Title` regex
- [x] Section-split corpus = 1472 rows (vs file-level 1401 rows)
- [x] W19-on-9D-only holds at 0.7657 on section-split corpus (Δ +0.0025 from cycle-8)
- [x] Per-section NSS is sparser than per-file NSS (2 axes vs 4 axes)

## What's still open (cycle-13 candidates)

- **Self-archaeology RSI**: apply single-action-atom methodology to the 81 self sections. Compute geodesic gap (d_pre, d_post, Δ) per section. Rank sections by Δ (highest priority for editing).
- **Cross-corpus alignment**: measure all 4 corpora (skills/docs/refs/self) separately and compare gate outcomes.
- **Full 2286-section main paper corpus**: section-splitting all 4 corpora would reach closer to the main paper's measurement.

## Audit trail

- Generated 2026-08-09T23:00:00 via guided-curve-ideate (cycle-12, measured)
- Measurement: inline sweep via run_script (sandbox executor)
- Self corpus: section-split into 81 entries from `memory/personal-WbtUgeUv/`
- L35: 34 SELF-CHANGELOG sections
- L36: 47 other-file sections
- L37: 1472-row full real 24-D with section-split self
- L38: 972 per-section NSS measurements
- Input: /var/workspace/session/zip_digest/cycle-12/constraints-catalog-2026-08-09-cycle12.md
- Output: /var/workspace/session/zip_digest/cycle-12/new-ideas-cycle12.md
- LOCAL ONLY — not committed to any repo
