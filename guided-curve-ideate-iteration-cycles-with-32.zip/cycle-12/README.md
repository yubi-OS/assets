# Iteration cycle 12 snapshot — MEASURED, self corpus section-split

**Skill:** guided-curve-ideate
**Cycle:** 12 of 14 (measured, section-split self corpus)
**Catalog:** constraints-catalog-2026-08-09-cycle12.md
**Output:** new-ideas-cycle12.md

## What's new vs cycle 11

| Cycle-11 limitation | Cycle-12 fix |
|---|---|
| Self corpus was 10 files = 10 items | **L35** splits SELF-CHANGELOG.md into 34 sections via `## YYYY-MM-DD — vN.N — Title` regex |
| Other self files treated as single items | **L36** splits SELF.md, USER_PREFERENCES.md, SAUNA_TOOLS.md, RULES.md, COMPANY.md into 47 per-section entries |
| Full real 24-D measured on 1401 rows (file-level) | **L37** re-measures on 1472 rows (section-level) |
| Per-file NSS scoring (120 measurements) | **L38** per-section NSS scoring (972 measurements) |

## Headline findings

1. **Self corpus splits into 81 sections** (34 from SELF-CHANGELOG + 47 from other files).
2. **W19-on-9D-only holds at 0.7657** on the 1472-row section-split corpus (Δ +0.0025 from cycle-8's 0.7632 file-level).
3. **Per-section NSS is sparser than per-file NSS** (2 axes: audience 35.8%, recursion 38.3% — vs file-level 4 axes).
4. **8 NSS axes have 0% coverage** on section-split self corpus (mode, assumption_set, adjacent_problems, failure_modes, lifecycle, composition, knowledge_sources, calibration).

## What's in this snapshot

- README.md (this file)
- SKILL.md (skill definition, with cycle-12 lenses L35–L38)
- empirical_gate_results_cycle12.json — measured values
- constraints-catalog-2026-08-09-cycle12.md (cycle-12 axes)
- new-ideas-cycle12.md (ref doc)
- new-ideas-cycle12.json (machine-readable)
- missing-from-cycle11.md (gap doc)

LOCAL ONLY — no commits, no GitHub pushes, no Linear activity.

## Cycle progression

| Cycle | Frontier | Best PC1+PC2 |
|---|---|---:|
| 1–3 | qualitative baseline | — |
| 4 | empirical_gate + mixed-radix (3+4) | 0.6901 |
| 5 | L13 column-weight sweep | 0.8080 |
| 6 | L15 Pareto + L16 cross-corpus + L17 synthetic 24-D | 0.8080 |
| 7 | L18 real 24-D (skills 474) + L19 corpus-adaptive + L20 per-corpus Möbius | 0.8538 / 0.7925 |
| 8 | L21 full real 24-D (1391) + L22 per-corpus Pareto + L23 finer-grained NSS | 0.8538 / 0.7632 |
| 9 | L24 selector + L25 hybrid + L26 NSS validation + L27 SELF.md | 0.8857 / 0.8685 |
| 10 | L28 NSS calibration + L29 cross-validation + L30 systematic 512-pattern sweep | 0.9802 / 0.6892 |
| 11 | L31 build full self corpus + L32 full real 24-D with self + L33 calibrated 11-D with self + L34 per-file NSS | 0.7635 / 0.6889 |
| **12** | **L35–L36 section-split self corpus (81 sections) + L37 re-measure (1472 rows) + L38 per-section NSS (972 measurements)** | **0.7657** |

## Audit trail

- Generated 2026-08-09T23:00:00 via guided-curve-ideate (cycle-12, measured)
- Source skill: session/guided-curve-ideate/SKILL.md
- Self corpus: 81 section-split entries from `memory/personal-WbtUgeUv/`
- L35: 34 SELF-CHANGELOG sections
- L36: 47 other-file sections
- L37: 1472-row full real 24-D with section-split self
- L38: 972 per-section NSS measurements
- Input: /var/workspace/session/zip_digest/cycle-12/constraints-catalog-2026-08-09-cycle12.md
- Output: /var/workspace/session/zip_digest/cycle-12/new-ideas-cycle12.md
- LOCAL ONLY — not committed to any repo
