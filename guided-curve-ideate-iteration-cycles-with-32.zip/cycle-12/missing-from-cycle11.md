# What's missing from cycle 11 — and how cycle 12 addresses it

## Gaps in cycle 11

1. **Self corpus was file-level (10 items).** SELF-CHANGELOG.md (226K chars, 1,721 lines) and other files were treated as single items. Too coarse for per-section analysis.
2. **Full real 24-D measured on 1401 rows (file-level self).** Section-level would give more rows and finer-grained measurement.
3. **Calibrated 11-D measured on 1401 rows (file-level self).** Same gap.
4. **Per-file NSS scoring (120 measurements).** Per-section NSS would give more detail.

## Cycle-12 fix

| Gap | Cycle-12 fix |
|---|---|
| Self corpus was file-level (10 items) | **L35** splits SELF-CHANGELOG.md into 34 sections. **L36** splits 5 other self files into 47 sections. Total: **81 self sections** (vs 10 file-level items). |
| Full real 24-D measured on 1401 rows | **L37** re-measures on 1472 rows (skills 474 + docs 126 + refs 791 + self-sections 81). W19-on-9D-only = 0.7657 (Δ +0.0025 from cycle-8). |
| Per-file NSS scoring (120 measurements) | **L38** per-section NSS scoring (972 measurements). Only 2 axes activate (audience 35.8%, recursion 38.3%) — sparser than per-file NSS because shorter sections are less likely to match regex patterns. |

## What cycle-12 still doesn't address (open for cycle 13)

1. **Self-archaeology RSI.** Apply single-action-atom methodology to the 81 self sections. Compute geodesic gap (d_pre, d_post, Δ) per section. Rank sections by Δ (highest priority for editing). This is the self-archaeology cadence that runs weekly.
2. **Cross-corpus alignment.** Measure all 4 corpora (skills/docs/refs/self) separately and compare gate outcomes. The main paper's measurement is over a unified 2286-section corpus.
3. **Full 2286-section main paper corpus.** Section-splitting all 4 corpora would reach closer to the main paper's measurement.
4. **Per-section primitive scoring.** Self sections currently assume all 9 primitives are present. A per-section primitive scoring would give finer-grained measurement.

## Cycle-13 candidate lenses

- **L39 — Self-archaeology RSI**: apply single-action-atom methodology to the 81 self sections. Compute geodesic gap per section.
- **L40 — Rank self sections by Δ**: identify which sections need editing most urgently.
- **L41 — Cross-corpus alignment**: measure skills/docs/refs/self separately and compare.
- **L42 — Per-section primitive scoring**: score 9 primitives per self section (not all-present assumption).

These are the cycle-13 lenses if the user wants another iteration.
