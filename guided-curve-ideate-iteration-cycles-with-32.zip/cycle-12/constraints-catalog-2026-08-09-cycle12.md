# Constraints Catalog — 2026-08-09 cycle 12

**Cycle:** 12 (section-split self corpus)
**Driver:** close cycle-11 limitations — file-level self too coarse.

## Cycle-11 limitations addressed

1. **Self corpus was file-level (10 items)** → cycle-12 L35/L36 section-split into 81 entries
2. **Full real 24-D measured on 1401 rows** → cycle-12 L37 re-measures on 1472 rows
3. **Per-file NSS scoring** → cycle-12 L38 per-section NSS scoring

## Cycle-12 axes (NEW)

- **Axis 30 — SELF-CHANGELOG section-split**: 34 sections via `## YYYY-MM-DD — vN.N — Title` regex
- **Axis 31 — Other self files section-split**: 47 sections across 5 files via `## Title` regex
- **Axis 32 — Per-section 24-D construction**: each section = 1 row with all 9 primitives + NSS scores + run-metadata

## Cycle-12 lens coverage

| Lens | Tests | Source |
|---|---|---|
| L35 — SELF-CHANGELOG sections | 34 sections, ~106K chars | Cycle-11 file-level too coarse |
| L36 — Other self sections | 47 sections, ~401K chars | Cycle-11 file-level too coarse |
| L37 — Full 24-D section-split | 4 candidates on 1472 rows | Cycle-11 measured on 1401 rows |
| L38 — Per-section NSS | 972 measurements (81 × 12) | Cycle-11 had 120 per-file |

## Audit trail

- Generated 2026-08-09T23:00:00
- Source: cycle-11 limitations (cycle-12 closes them)
- Output: new-ideas-cycle12.md
