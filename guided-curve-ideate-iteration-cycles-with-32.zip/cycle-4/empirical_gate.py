#!/usr/bin/env python3
"""
empirical_gate.py — measured PC1+PC2 gate for guided-curve-ideate candidates.

Adapter over the main-repo classifier (papers/scripts/fit-full-curve-map.py):
loads the 79-skill corpus design matrix from
papers/data/rsi-79-corpus-multi-cycle-2026-08-06.json (cycle-1 missing_primitives
field gives the 9-D binary primitive coverage), runs PCA top-2 with each
candidate's basis convention, and emits measured pc1_plus_pc2 + gate.

Usage:
    python3 empirical_gate.py <path-to-rsi-79-corpus-multi-cycle-2026-08-06.json> \
        --candidate '{"D":384,"lobe_convention":"3-fold","freq_sym":"3-fold",...}'

Constraints:
    stdlib + numpy only. No external API calls.
"""
from __future__ import annotations
import argparse
import json
import sys
from pathlib import Path

import numpy as np


PRIMITIVES = [
    "attestation", "trust_chain", "least_privilege", "declarative_policy",
    "continuous_adaptive", "immutability", "audit_evidence",
    "cryptographic_identity", "segmentation",
]
N_PRIM = len(PRIMITIVES)
GATE = 0.40


def load_corpus_79(path: Path) -> dict:
    """Load the 79-skill corpus. Each cycle-1 entry has missing_primitives;
    presence = 1 (covered), absence = 0 (missing).
    """
    with open(path) as f:
        doc = json.load(f)
    items = []
    seen = set()
    for entry in doc.get("all_cycles", []):
        if entry.get("cycle") != 1:
            continue
        slug = entry["slug"]
        if slug in seen:
            continue
        seen.add(slug)
        missing = set(entry.get("missing_primitives", []))
        cov = [0 if p in missing else 1 for p in PRIMITIVES]
        items.append({"slug": slug, "coverage": cov})
    return {
        "n_items": len(items),
        "primitives": PRIMITIVES,
        "items": items,
    }


def build_coverage_matrix(corpus: dict) -> tuple[np.ndarray, list[str]]:
    n = corpus["n_items"]
    C = np.zeros((n, N_PRIM), dtype=np.float64)
    slugs = []
    for i, it in enumerate(corpus["items"]):
        C[i, :] = it["coverage"]
        slugs.append(it["slug"])
    assert np.all((C == 0) | (C == 1)), "non-binary values in coverage matrix"
    return C, slugs


def candidate_basis_mask(candidate: dict) -> np.ndarray:
    """Return a (N_PRIM,) boolean mask: which primitives the candidate's basis
    'covers' for PCA purposes. The 9-D binary coverage IS the basis; the
    candidate's D/lobe/freq axes act as a *weighting* on which primitives
    contribute to the projection. The simplest honest model: the candidate's
    lobe_convention determines the weighting — primitives aligned with the
    3-fold ladder (12, 24, 48) get full weight, others reduced.

    For empirical PC1+PC2 we need a (re)weighting of the 9-D coverage columns.
    Convention map:
        3-fold:     identity (current regime)
        all-m:      identity
        mixed:      full weight on mult-of-3, half on mult-of-4, third on others
        multi-radix: identity (more axes = same 9-D coverage)
        negative-m: identity (sphere is symmetric)
        D<D_default: identity (basis already only spans 9 primitives)
        Möbius non-frozen: identity (reparameterization does not change coverage)
    """
    n_prim = N_PRIM
    mask = np.ones(n_prim, dtype=np.float64)
    lobe = candidate.get("lobe_convention", "3-fold")
    if lobe == "mixed-radix" or lobe == "mixed (3k + 4k)":
        # 3-fold axes (m_k=3k) align with primitives 0..2 (low m); 4-fold
        # pulls in higher m. Weight mults of 3 fully, mults of 4 half, others 1/3.
        weights = np.array([
            1.0, 1.0, 1.0,   # 0..2 (m=1,2,3)
            0.5, 0.5, 1.0,   # 3..5 (m=4,5,6 — partial)
            0.5, 0.5, 1.0,   # 6..8 (m=7,8,9 — partial)
        ])
        return weights
    return mask


def pca_top2_measured(C: np.ndarray, weights: np.ndarray) -> tuple[float, float, int]:
    """Run PCA top-2 on column-weighted coverage matrix and return
    (pc1, pc2, n_eigenvalues_above_eps).
    """
    W = np.diag(weights)
    Cw = C @ W
    mu = Cw.mean(axis=0, keepdims=True)
    Mc = Cw - mu
    # SVD
    try:
        U, S, Vt = np.linalg.svd(Mc, full_matrices=False)
    except np.linalg.LinAlgError:
        return 0.0, 0.0, 0
    # explained variance ratio = S^2 / sum(S^2)
    s2 = S ** 2
    total = s2.sum()
    if total < 1e-12:
        return 0.0, 0.0, 0
    pc1 = float(s2[0] / total)
    pc2 = float(s2[1] / total) if len(s2) > 1 else 0.0
    return pc1, pc2, len(s2)


def evaluate_candidate(corpus: dict, candidate: dict) -> dict:
    C, slugs = build_coverage_matrix(corpus)
    weights = candidate_basis_mask(candidate)
    pc1, pc2, rank = pca_top2_measured(C, weights)
    pc1pc2 = pc1 + pc2
    gate_pass = pc1pc2 >= GATE
    return {
        "id": candidate.get("id", "?"),
        "axes": {
            "D": candidate.get("D"),
            "lobe_convention": candidate.get("lobe_convention"),
            "freq_sym": candidate.get("freq_sym"),
            "Moebius": candidate.get("Moebius"),
        },
        "pc1_measured": round(pc1, 4),
        "pc2_measured": round(pc2, 4),
        "pc1_plus_pc2_measured": round(pc1pc2, 4),
        "gate_threshold": GATE,
        "gate": "PASS" if gate_pass else "FAIL",
        "rank": rank,
        "n_items": corpus["n_items"],
        "weights_applied": weights.tolist(),
        "qualitative_estimate": candidate.get("qualitative_pc1pc2_estimate", "unknown"),
    }


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("corpus_path", help="Path to rsi-79-corpus-multi-cycle-2026-08-06.json")
    ap.add_argument("--candidate", help="Single candidate JSON string")
    ap.add_argument("--candidates-file", help="Path to JSON file with list of candidates")
    ap.add_argument("--output", help="Output JSON path (default: stdout)")
    args = ap.parse_args()

    corpus = load_corpus_79(Path(args.corpus_path))

    if args.candidate:
        candidates = [json.loads(args.candidate)]
    elif args.candidates_file:
        with open(args.candidates_file) as f:
            candidates = json.load(f)
    else:
        sys.exit("Provide --candidate or --candidates-file")

    results = [evaluate_candidate(corpus, c) for c in candidates]

    out = {
        "corpus_source": str(args.corpus_path),
        "n_items": corpus["n_items"],
        "gate_threshold": GATE,
        "results": results,
    }
    s = json.dumps(out, indent=2)
    if args.output:
        with open(args.output, "w") as f:
            f.write(s)
        print(f"Wrote {args.output}")
    else:
        print(s)


if __name__ == "__main__":
    main()
