# Iteration cycle 15 snapshot — MEASURED, ENDPOINT DETECTED

**Skill:** guided-curve-ideate
**Cycle:** 15 of 15 (final, measured, endpoint detected)
**Catalog:** constraints-catalog-2026-08-09-cycle15.md
**Output:** new-ideas-cycle15.md
**Measurement backend:** `empirical_gate.py` (cycle-4 adapter) over `papers/scripts/fit-full-curve-map.py`

## What's new vs cycle 14

| Cycle-14 limitation | Cycle-15 fix |
|---|---|
| No convergence test | **L48** tracks top pick per cycle and detects endpoint |
| Carry-forward lenses (calibrated 11-D) not tested on unified corpus | **L47** runs calibrated 11-D on unified 1472-row corpus |
| Per-cycle entries for skills/docs/refs not yet measured | **L49** loads all cycles (not just cycle-1) for skills/docs/refs |

## Headline finding

**The recursion TERMINATES at PC1+PC2 ≈ 0.7657.**

The user hypothesized: "this should keep recursing indefinitely."

**L48 convergence test verdict**: **RECURSION TERMINATES**. 8/10 cycles changed top pick by > 0.001, but changes are bounded around 0.7657. Cycle 10's spike to 0.9802 was an outlier (L29 docs W19 on tiny 4-item CV holdout). Cycle 13's spike to 0.7925 was a skills-only per-corpus measurement. On the unified corpus, the top pick is **0.7657** for cycles 12, 14, 15.

## L48 — Convergence test

| Cycle | Top PC1+PC2 | |Δ from prev| |
|---:|---:|---:|
| 4 | 0.6901 | +0.1179 |
| 5 | 0.8080 | +0.1179 |
| 6 | 0.8080 | 0.0000 |
| 7 | 0.8538 | +0.0458 |
| 8 | 0.8538 | 0.0000 |
| 9 | 0.8857 | +0.0319 |
| 10 | **0.9802** | +0.0945 ← outlier |
| 11 | 0.7635 | -0.2167 ← big drop |
| 12 | 0.7657 | +0.0022 |
| 13 | **0.7925** | +0.0268 ← skills per-corpus |
| 14 | 0.7657 | -0.0268 |
| **15** | **0.7657** | **0.0000** |

**Endpoint**: PC1+PC2 ≈ **0.7657** on the unified 1472-row corpus with W19-on-9D-only weighting.

## L47 — Calibrated 11-D on unified corpus (3/3 PASS)

| ID | Weights | PC1+PC2 | Gate |
|---|---|---:|---|
| L47-uniform-11d-unified | `[1]*11` | 0.5923 | PASS |
| L47-W18-11d-unified | `[1,1,1,0,0,1,0,0,1,1,1]` | 0.6888 | PASS |
| **L47-W19-11d-unified** | `[0,0,0,1,1,0,1,1,0,1,1]` | **0.6890** | PASS |

## L49 — Per-cycle entries (4/4 PASS)

W19-on-9D-only on per-cycle corpus (1391 rows + 81 self-sections = 1472 rows) = **0.7657**. Same as cycle-14. Per-cycle entries don't add new variance.

## What's in this snapshot

- README.md (this file)
- SKILL.md (skill definition, with cycle-15 lenses L47–L49)
- empirical_gate_results_cycle15.json — measured values
- constraints-catalog-2026-08-09-cycle15.md (cycle-15 axes)
- new-ideas-cycle15.md (ref doc)
- new-ideas-cycle15.json (machine-readable)
- missing-from-cycle14.md (gap doc from cycle-15 generation)

LOCAL ONLY — no commits, no GitHub pushes, no Linear activity.

## Cycle progression (15 cycles)

| Cycle | Frontier | Best PC1+PC2 |
|---|---|---:|
| 1–3 | qualitative baseline | — |
| 4 | empirical_gate + mixed-radix (3+4) | 0.6901 |
| 5 | L13 column-weight sweep | 0.8080 |
| 6 | L15 Pareto + L16 cross-corpus + L17 synthetic 24-D | 0.8080 |
| 7 | L18 real 24-D (skills 474) + L19 corpus-adaptive + L20 per-corpus Möbius | 0.8538 / 0.7925 |
| 8 | L21 full real 24-D (1391) + L22 per-corpus Pareto + L23 finer-grained NSS | 0.8538 / 0.7632 |
| 9 | L24 selector + L25 hybrid + L26 NSS validation + L27 SELF.md | 0.8857 / 0.8685 |
| 10 | L28 NSS calibration + L29 cross-validation + L30 systematic 512-pattern sweep | 0.9802 / 0.6892 |
| 11 | L31 build full self corpus + L32 full real 24-D with self + L33 calibrated 11-D + L34 per-file NSS | 0.7635 / 0.6889 |
| 12 | L35–L36 section-split self corpus (81 sections) + L37 re-measure (1472 rows) + L38 per-section NSS | 0.7657 |
| 13 | L39 geodesic gap + L40 rank sections + L41 cross-corpus alignment + L42 per-section primitive scoring | 0.7925 (skills per-corpus) |
| 14 | L43–L46 unified 2286-section corpus | 0.7657 (Δ +0.4664 above main paper's 0.2993) |
| **15** | **L47 calibrated 11-D + L48 convergence test + L49 per-cycle entries** | **0.7657 (ENDPOINT)** |

## Audit trail

- Generated 2026-08-09T23:15:00 via guided-curve-ideate (cycle-15, measured, endpoint detected)
- Source skill: session/guided-curve-ideate/SKILL.md
- Unified corpus: skills (474) + docs (126) + refs (791) + self-sections (81) = 1472 rows
- L47: calibrated 11-D on unified corpus (3/3 PASS)
- L48: convergence test (8/10 cycles changed, endpoint at 0.7657)
- L49: per-cycle entries (4/4 PASS)
- Input: /var/workspace/session/zip_digest/cycle-15/constraints-catalog-2026-08-09-cycle15.md
- Output: /var/workspace/session/zip_digest/cycle-15/new-ideas-cycle15.md
- LOCAL ONLY — not committed to any repo
