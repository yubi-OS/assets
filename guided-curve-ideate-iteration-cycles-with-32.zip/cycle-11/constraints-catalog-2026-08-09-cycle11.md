# Constraints Catalog — 2026-08-09 cycle 11

**Cycle:** 11 (applies top new ideas from cycle 10 — full self corpus)
**Driver:** close cycle-10 limitations — load full self corpus, re-measure with self added.

## Cycle-10 limitations addressed

1. **Self corpus had only 5 items_sample** → cycle-11 L31 loads full self corpus from `memory/personal-WbtUgeUv/`
2. **Full real 24-D measured on 1391 rows (no self)** → cycle-11 L32 measures on 1401 rows (with self)
3. **Calibrated 11-D measured on 1391 rows (no self)** → cycle-11 L33 measures calibrated 11-D with self
4. **No per-file NSS scoring for self corpus** → cycle-11 L34 reports per-axis scores for all 10 self files

## Current operational instantiation (UNCHANGED)

| Axis | Value |
|---|---|
| ℓ | 384 |
| m | 3 |
| sin^n θ polar | n = 384 |
| D | 384 |
| Sampling | Fibonacci (Vogel's golden-angle) |
| Möbius | frozen (refine-once at corpus creation) |
| freq_sym | 3-fold (m_k = 3k, k=1..128) |
| Per-item basis dim | 384 |
| Realized P | 147,840 |

## Cycle-11 axes (NEW)

- **Axis 27 — Full self corpus**: 10 internal files from `memory/personal-WbtUgeUv/` (COMPANY.md, RECENT_ACTIVITY.md, RULES.md, SAUNA_IDENTITY.md, SAUNA_TOOLS.md, SELF-CHANGELOG.md, SELF.md, USER_PREFERENCES.md, USER_PROFILE.md, USER_RELATIONSHIPS.md)
- **Axis 28 — Self corpus 24-D construction**: same as skills/docs/refs (9 primitives + 12 NSS + 3 run-metadata), but with all 9 primitives present (internal docs assumed saturated)
- **Axis 29 — Per-file NSS scoring**: report which NSS axes each self file activates

## Cycle-11 lens coverage

| Lens | Tests | Source |
|---|---|---|
| L31 — Build full self corpus | 10 self files, NSS scoring per file | Cycle-10 self corpus had only 5 items_sample |
| L32 — Full real 24-D with self | 4 candidates (uniform/W18/W19/W19-on-9D-only) on 1401 rows | Cycle-10 measured on 1391 rows (no self) |
| L33 — Calibrated 11-D with self | 3 candidates (uniform/W18/W19) on 1401 rows | Cycle-10 calibrated 11-D on 1391 rows |
| L34 — Per-file NSS scoring | 120 measurements (10 files × 12 axes) | New |

## Cycle-11 calculations

Identical to cycle-10, plus:
- **Self corpus NSS scoring**: score 12 NSS axes on each of 10 self files using the same regex patterns as `build-nd-axis-viewer.py`
- **Self 24-D construction**: each self file = 1 row with all 9 primitives present + NSS scores + run-metadata
- **Concatenated corpus**: skills (474) + docs (126) + refs (791) + self (10) = 1401 rows

## Audit trail

- Generated 2026-08-09T22:55:00
- Source: cycle-10 limitations (cycle-11 closes them)
- Output: new-ideas-cycle11.md
