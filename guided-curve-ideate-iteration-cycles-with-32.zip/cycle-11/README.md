# Iteration cycle 11 snapshot — MEASURED, full self corpus

**Skill:** guided-curve-ideate
**Cycle:** 11 of 11 (final, measured, full self corpus)
**Catalog:** constraints-catalog-2026-08-09-cycle11.md
**Output:** new-ideas-cycle11.md
**Measurement backend:** inline sweep via `run_script` (sandbox executor) over `empirical_gate.py` (cycle-4 adapter)

## What's new vs cycle 10

Cycle 10 used the self-corpus-listing.json which had only 5 items_sample (n_items=111 claimed). The user clarified that the **full self corpus is in `memory/personal-WbtUgeUv/`** — the same corpus `curve-guided-rsi-self` was built on (session ses_034a2fddfffeydbV3RN6IzlJMI).

| Cycle-10 limitation | Cycle-11 fix |
|---|---|
| Self corpus had only 5 items_sample | **L31** loads the full self corpus from `memory/personal-WbtUgeUv/` — 10 files (507,161 chars total) |
| Full real 24-D measured on 1391 rows (no self) | **L32** measures on 1401 rows (skills 474 + docs 126 + refs 791 + self 10) |
| Calibrated 11-D measured on 1391 rows (no self) | **L33** measures calibrated 11-D with self on 1401 rows |
| Per-file NSS scoring not done | **L34** reports per-axis scores for all 10 self files (120 measurements) |

## Headline findings

1. **Self corpus loads cleanly**: 10 files, 507,161 chars, 4 active NSS axes (audience, inputs, outputs, recursion). SELF-CHANGELOG.md is the largest at 226K chars.
2. **W19-on-9D holds at 1401 rows**: L32-W19-on-9D-only → PC1+PC2 = **0.7635** (Δ +0.0003 from cycle-8's 0.7632 without self). The self corpus doesn't move PCA meaningfully.
3. **Calibrated 11-D preserves the gate with self**: L33-W19 → PC1+PC2 = **0.6889** on 1401 rows. Cycle-11 confirms cycle-10's NSS calibration finding.
4. **Self corpus activates more NSS axes than skills/**: 4 axes (audience, inputs, outputs, recursion) vs 2 axes on skills/ (audience, recursion). Internal docs follow the "Audience/Inputs/Outputs" pattern.

## What's in this snapshot

- README.md (this file)
- SKILL.md (skill definition, with cycle-11 lenses L31–L34)
- empirical_gate_results_cycle11.json — measured values
- constraints-catalog-2026-08-09-cycle11.md (cycle-11 axes)
- new-ideas-cycle11.md (ref doc)
- new-ideas-cycle11.json (machine-readable)
- missing-from-cycle10.md (gap doc from cycle-11 generation)

LOCAL ONLY — no commits, no GitHub pushes, no Linear activity.

## Cycle progression

| Cycle | Frontier | Best measured PC1+PC2 |
|---|---|---:|
| 1–3 | qualitative baseline | — |
| 4 | empirical_gate + mixed-radix (3+4) | 0.6901 |
| 5 | L13 column-weight sweep | 0.8080 |
| 6 | L15 Pareto + L16 cross-corpus + L17 synthetic 24-D | 0.8080 |
| 7 | L18 real 24-D (skills 474) + L19 corpus-adaptive + L20 per-corpus Möbius | 0.8538 (docs) / 0.7925 (real 24-D) |
| 8 | L21 full real 24-D (1391) + L22 per-corpus Pareto + L23 finer-grained NSS | 0.8538 (docs) / 0.7632 (full real 24-D) |
| 9 | L24 selector + L25 hybrid + L26 NSS validation + L27 SELF.md | 0.8857 (L24 avg) / 0.8685 (L25 keep-m3-m6-m9) |
| 10 | L28 NSS calibration + L29 cross-validation + L30 systematic 512-pattern sweep | 0.9802 (L29 docs W19) / 0.6892 (L28 calibrated W19) |
| **11** | **L31 build full self corpus + L32 full real 24-D with self + L33 calibrated 11-D with self + L34 per-file NSS scoring** | **0.7635 (L32 full real 24-D with self)** / **0.6889 (L33 calibrated 11-D with self)** |

## What cycle-11 settled

1. **Full self corpus is loadable and measurable**: 10 files, 507,161 chars, 4 active NSS axes.
2. **Self corpus fits the 24-D construction**: W19-on-9D holds at 0.7635 with self added (Δ +0.0003).
3. **NSS calibration is robust to self corpus**: calibrated 11-D with self → W19 = 0.6889 (above 0.40 gate).
4. **Self corpus activates 4 NSS axes** (audience, inputs, outputs, recursion) — more than skills/ (2 axes).

## What's still open

- **Self corpus section-splitting**: SELF-CHANGELOG.md has 1,721 lines and could be split into ~50+ section entries.
- **Self-archaeology RSI**: schedules/self-archaeology-cadence/ exists — cycle-11 should run RSI on the self corpus to find which sections need editing.
- **Full 2286-section main paper corpus**: the main paper's measurement is over 2286 sections across 4 corpora. Cycle-11's 1401 rows is closer but not there yet.

## Audit trail

- Generated 2026-08-09T22:55:00 via guided-curve-ideate (cycle-11, measured)
- Source skill: session/guided-curve-ideate/SKILL.md
- Self corpus: `/var/workspace/memory/personal-WbtUgeUv/` (10 files, same corpus as `curve-guided-rsi-self`)
- Implementation: inline sweep (cycle-11 driver)
- L31: 10 self files, 507,161 chars, 4 active NSS axes
- L32: full real 24-D with self, 1401 rows, 4/4 PASS
- L33: calibrated 11-D with self, 1401 rows, 3/3 PASS
- L34: per-file per-axis NSS scoring, 120 measurements
- Input: /var/workspace/session/zip_digest/cycle-11/constraints-catalog-2026-08-09-cycle11.md
- Output: /var/workspace/session/zip_digest/cycle-11/new-ideas-cycle11.md
- LOCAL ONLY — not committed to any repo
