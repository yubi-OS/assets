# What's missing from cycle 10 — and how cycle 11 addresses it

## Gaps in cycle 10

1. **Self corpus had only 5 items_sample.** The self-corpus-listing.json said n_items=111 but only 5 in items_sample. Cycle-10 L27 added SELF.md from the workspace, but the full self corpus wasn't loaded.
2. **Full real 24-D measured on 1391 rows (no self).** Cycle-10 L21 measured on skills + docs + refs only. The self corpus was missing.
3. **Calibrated 11-D measured on 1391 rows (no self).** Same gap.
4. **No per-file NSS scoring for self corpus.** Cycle-10 didn't report which NSS axes each self file activates.

## Cycle-11 fix

| Gap | Cycle-11 fix |
|---|---|
| Self corpus had only 5 items_sample | **L31** loads the full self corpus from `memory/personal-WbtUgeUv/` — 10 files (507,161 chars total). The user's hint ("self corpus IS internal where you keep self-changelog") confirmed this is the right location. |
| Full real 24-D measured on 1391 rows | **L32** measures on 1401 rows (skills 474 + docs 126 + refs 791 + self 10). All 4 candidates PASS. W19-on-9D-only = 0.7635 (Δ +0.0003 from cycle-8). |
| Calibrated 11-D measured on 1391 rows | **L33** measures calibrated 11-D with self on 1401 rows. All 3 candidates PASS. W19 = 0.6889. |
| No per-file NSS scoring | **L34** reports per-axis scores for all 10 self files (120 measurements). Self corpus activates 4 NSS axes: audience (9/10), recursion (7/10), outputs (5/10), inputs (3/10). |

## What cycle-11 still doesn't address (open for cycle 12)

1. **Self corpus section-splitting.** SELF-CHANGELOG.md has 1,721 lines and could be split into ~50+ section entries (like the main paper's 2286-section corpus). Currently each file = 1 item. Section-splitting would bring the corpus closer to the main paper's 2286 rows.
2. **Self-archaeology RSI.** schedules/self-archaeology-cadence/ exists — cycle-12 should run RSI on the self corpus to find which sections need editing (like cycle-2 did for SELF-CHANGELOG canonical in session ses_034a2fddfffeydbV3RN6IzlJMI, which found PC1+PC2 = 0.6479 for the expanded 11-file corpus with 154 items).
3. **Full 2286-section main paper corpus.** The main paper's measurement is over 2286 sections across 4 corpora (skills/docs/refs/self). Cycle-11's 1401 rows is closer but not there yet. Section-splitting the self corpus would add ~50 rows.
4. **Cross-corpus alignment.** The main paper measures 4 corpora separately (skills/docs/refs/self). Cycle-11 confirms the self corpus fits the same 24-D construction. A unified 4-corpus measurement would close the gap to the main paper's setup.

## Cycle-12 candidate lenses

- **L35 — Self corpus section-splitting**: split SELF-CHANGELOG.md (1,721 lines), SELF.md, USER_PREFERENCES.md, etc. into per-section entries. Add ~50+ rows to reach ~1450 total.
- **L36 — Self-archaeology RSI**: run RSI on the full self corpus to find which sections need editing. Apply the cycle-2 methodology from session ses_034a2fddfffeydbV3RN6IzlJMI.
- **L37 — Full 2286-section measurement**: re-measure PC1+PC2 on the unified 4-corpus section-split corpus. Compare to the main paper's 0.2993 baseline.
- **L38 — Per-section NSS scoring**: report which sections activate which NSS axes. Use for targeted editing.

These are the cycle-12 lenses if the user wants another iteration.
