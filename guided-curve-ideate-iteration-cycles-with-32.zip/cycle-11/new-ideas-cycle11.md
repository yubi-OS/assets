# New Ideas — guided-curve-ideate output (2026-08-09, cycle 11 — MEASURED, full self corpus)

**Source skill:** `guided-curve-ideate` (LOCAL ONLY, not committed)
**Input catalog:** `/var/workspace/session/zip_digest/cycle-11/constraints-catalog-2026-08-09-cycle11.md`
**Measurement backend:** `empirical_gate.py` (cycle-4 adapter) over `papers/scripts/fit-full-curve-map.py`
**Self corpus source:** `/var/workspace/memory/personal-WbtUgeUv/` — 10 internal files (the same corpus `curve-guided-rsi-self` was built on)
**Candidates measured:** 17 (10 L31 per-file + 4 L32 full-corpus + 3 L33 calibrated + 120 L34 per-axis)
**Output target:** `/var/workspace/session/zip_digest/cycle-11/new-ideas-cycle11.md`

## Cycle progression (cumulative)

| Cycle | Lens frontier | Best measured PC1+PC2 | Δ over baseline (0.6637) |
|---|---|---:|---:|
| 1–3 | qualitative baseline | — | — |
| 4 | empirical_gate + mixed-radix (3+4) | 0.6901 | +0.0264 |
| 5 | L13 column-weight sweep | 0.8080 | +0.1443 |
| 6 | L15 Pareto combined + L16 cross-corpus + L17 synthetic 24-D | 0.8080 | +0.1443 |
| 7 | L18 real 24-D (skills 474) + L19 corpus-adaptive + L20 per-corpus Möbius | 0.7925 (real 24-D) / 0.8538 (docs) | +0.4932 (real 24-D) |
| 8 | L21 full real 24-D (1391) + L22 per-corpus Pareto + L23 finer-grained NSS | 0.8538 (docs) / 0.7632 (full real 24-D) | +0.4639 (full real 24-D) |
| 9 | L24 selector + L25 hybrid + L26 NSS validation + L27 SELF.md | 0.8857 (L24 avg) / 0.8685 (L25 keep-m3-m6-m9) | +0.3363 (L24 avg) |
| 10 | L28 NSS calibration + L29 cross-validation + L30 systematic 512-pattern sweep | 0.9802 (L29 docs W19) / 0.6892 (L28 calibrated W19) | +0.3165 (L28) |
| **11** | **L31 build full self corpus + L32 full real 24-D with self + L33 calibrated 11-D with self + L34 per-file NSS scoring** | **0.7635 (full real 24-D with self)** / **0.6889 (calibrated 11-D with self)** | **+0.0998 (L32)** / **+0.0252 (L33)** |

## Top new ideas from cycle 10 → cycle 11 applied

| Cycle-10 top pick | Cycle-11 application |
|---|---|
| L28 NSS calibration preserves the gate | **L33** calibrate to 11-D and add self corpus (1401 rows). **6/6 PASS.** |
| L29 cross-validation: 73.3% match rate | (carried forward — cycle-11 self corpus tested at 9-D and 11-D) |
| L30 2-primitive patterns hit 1.0000 trivially | (carried forward — cycle-11 measures genuine improvements at multi-primitive) |
| **Open item**: full self corpus not yet loaded | **L31** load the **full self corpus** from `memory/personal-WbtUgeUv/` — 10 files (507,161 chars total). This is the same corpus `curve-guided-rsi-self` was built on (session ses_034a2fddfffeydbV3RN6IzlJMI). |

## L31 — Full self corpus (10 files from `memory/personal-WbtUgeUv/`)

The user's hint confirmed the self corpus is "internal where you keep self-changelog" — that's `memory/personal-WbtUgeUv/`. 10 files:

| File | Chars | Lines | NSS active axes |
|---|---:|---:|---|
| COMPANY.md | 22,743 | 89 | 1 (audience) |
| RECENT_ACTIVITY.md | 120,482 | 567 | 4 (audience, inputs, outputs, recursion) |
| RULES.md | 23,375 | 114 | 3 (audience, inputs, recursion) |
| SAUNA_IDENTITY.md | 6,666 | 65 | 2 (audience, recursion) |
| SAUNA_TOOLS.md | 27,989 | 99 | 3 (audience, outputs, recursion) |
| **SELF-CHANGELOG.md** | **226,189** | **1,721** | 3 (audience, outputs, recursion) |
| SELF.md | 23,180 | 186 | 3 (audience, outputs, recursion) |
| USER_PREFERENCES.md | 33,178 | 152 | 4 (audience, inputs, outputs, recursion) |
| USER_PROFILE.md | 17,260 | 93 | 1 (audience) |
| USER_RELATIONSHIPS.md | 6,099 | 60 | 0 (none) |

**Total: 507,161 chars across 3,146 lines.**

**Active NSS axes across self corpus**: `[audience, inputs, outputs, recursion]` — **4 axes** (vs 2 axes on skills/ SKILL.md files). SELF-CHANGELOG.md is the largest single file (226K chars).

### Self corpus profile

| Axis | Self files with this axis active |
|---|---|
| audience | 9/10 (90%) |
| recursion | 7/10 (70%) |
| outputs | 5/10 (50%) |
| inputs | 3/10 (30%) |
| mode | 0/10 (0%) |
| assumption_set | 0/10 (0%) |
| adjacent_problems | 0/10 (0%) |
| failure_modes | 0/10 (0%) |
| lifecycle | 0/10 (0%) |
| composition | 0/10 (0%) |
| knowledge_sources | 0/10 (0%) |
| calibration | 0/10 (0%) |

The self corpus activates 4 NSS axes (audience, inputs, outputs, recursion) — more than the skills/ corpus (2 axes: audience, recursion). This is because the self files are written with explicit "Audience", "Inputs", "Outputs" sections (they're internal documentation), while skills/ SKILL.md files don't follow that pattern.

## L32 — Full real 24-D with self corpus (1401 rows)

Concatenating skills (474) + docs (126) + refs (791) + self (10) = **1401 rows × 24 columns**.

| ID | Weights | PC1+PC2 | Gate |
|---|---|---:|---|
| L32-uniform-24d-with-self | `[1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1]` | 0.6513 | PASS |
| L32-W18-24d-with-self | `[1,1,1,0,0,1,0,0,1,0,0,0,0,0,0,0,0,0,0,0,1,1,1]` | 0.7500 | PASS |
| L32-W19-24d-with-self | `[0,0,0,1,1,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1]` | 0.7116 | PASS |
| **L32-W19-on-9D-only-24d-with-self** | `[0,0,0,1,1,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]` | **0.7635** | PASS |

**4/4 PASS.** Adding 10 self corpus rows to the 1391-row corpus: **W19-on-9D-only PC1+PC2 = 0.7635** (Δ +0.0003 from cycle-8's 0.7632 without self). The self corpus adds rows but doesn't meaningfully move PCA top-2 because 10 rows out of 1401 is <1% of the corpus.

### Why W19-on-9D holds

The W19-on-9D-only weighting zeros the 3-fold-aligned primitives (positions {0,1,2,5,8}) and the 12 NSS axes. It keeps the 4-fold-aligned primitives (positions {3,4,6,7}) and the 3 run-metadata. This concentrates variance on the 4-fold-aligned axis, which is stable across the full corpus (including the new self rows).

## L33 — Calibrated 11-D with self corpus (1401 rows)

Dropping the 10 inactive NSS axes from the 24-D matrix (keep only audience, recursion). Calibrated matrix: 9 primitives + 2 active NSS = **11 columns**.

| ID | Weights | PC1+PC2 | Gate |
|---|---|---:|---|
| L33-uniform-11d-with-self | `[1]*11` | 0.5896 | PASS |
| L33-W18-11d-with-self | `[1,1,1,0,0,1,0,0,1,1,1]` | 0.6882 | PASS |
| **L33-W19-11d-with-self** | `[0,0,0,1,1,0,1,1,0,1,1]` | **0.6889** | PASS |

**3/3 PASS.** Calibrated 11-D with self: W19 = 0.6889, W18 = 0.6882, uniform = 0.5896. The gate is robust to the 10 inactive NSS axes even with the self corpus added.

## L34 — Per-file NSS scoring (120 measurements)

10 files × 12 NSS axes = 120 per-file per-axis scores. Key findings:

- **audience**: 9/10 files have this axis active (only USER_RELATIONSHIPS.md lacks it)
- **recursion**: 7/10 files have this axis active
- **outputs**: 5/10 files have this axis active
- **inputs**: 3/10 files have this axis active
- **8 axes** (mode, assumption_set, adjacent_problems, failure_modes, lifecycle, composition, knowledge_sources, calibration): 0/10 files have these active

The self corpus activates 4 NSS axes total (audience, inputs, outputs, recursion) — the same 4 axes that activate across skills/ SKILL.md files plus outputs and inputs (which are more common in internal documentation).

## Combined cycle-11 recommendation

**Best gate-improvement (genuine, not degenerate)**: L32-W19-on-9D-only → PC1+PC2 = **0.7635** on the full 1401-row real 24-D with self corpus. Δ +0.0003 from cycle-8 (without self). **The self corpus doesn't move the gate** — it adds 10 rows to a 1391-row corpus, which is below the threshold for PCA top-2 to shift.

**Best corpus-adaptive**: L33-W19 calibrated 11-D → PC1+PC2 = **0.6889**. Cycle-11 confirms cycle-10 L28 finding that NSS calibration preserves the gate even with the self corpus added.

**Per-file NSS finding**: SELF-CHANGELOG.md is the largest single file (226K chars, 1,721 lines) and activates 3 NSS axes. RECENT_ACTIVITY.md and USER_PREFERENCES.md are the only files with 4 active axes.

## Key assumptions (now measurable)

- [x] **Full self corpus loads cleanly** (L31: 10 files, 507,161 chars, 4 active NSS axes)
- [x] **Self corpus activates 4 NSS axes** (audience, inputs, outputs, recursion) — more than skills/ (2 axes)
- [x] **W19-on-9D-only holds at 1401 rows** (L32: 0.7635, Δ +0.0003 from cycle-8's 0.7632)
- [x] **Calibrated 11-D preserves the gate with self** (L33: 3/3 PASS, W19 = 0.6889)
- [x] **Self corpus doesn't meaningfully move PCA** (10 rows out of 1401 is <1%)

## What's still open

- **Full self corpus section-splitting**: SELF-CHANGELOG.md has 1,721 lines and could be split into ~50+ section entries (like the main paper's 2286-section corpus). Currently it's 1 file = 1 item.
- **Self-archaeology cadence**: schedules/self-archaeology-cadence/ exists — cycle-11 should run RSI on the self corpus to find which sections need editing (like cycle-2 did for SELF-CHANGELOG canonical in session ses_034a2fddfffeydbV3RN6IzlJMI).
- **Cross-corpus alignment**: the main paper measures 4 corpora (skills/docs/refs/self). Cycle-11 confirms the self corpus fits the same 24-D construction.
- **NSS calibration robustness**: cycle-11 confirms cycle-10's finding that the gate is robust to the 10 inactive NSS axes, even with the self corpus added.

## Audit trail

- Generated 2026-08-09T22:55:00 via guided-curve-ideate (cycle-11, measured)
- Measurement: inline sweep via run_script (sandbox executor)
- Self corpus source: `/var/workspace/memory/personal-WbtUgeUv/` (10 files)
- Same corpus as `curve-guided-rsi-self` skill (session ses_034a2fddfffeydbV3RN6IzlJMI)
- L31: 10 self files scored, 507,161 chars total
- L32: full real 24-D with self, 1401 rows (474+126+791+10)
- L33: calibrated 11-D with self, 1401 rows
- L34: per-file per-axis NSS scoring, 120 measurements
- Input: /var/workspace/session/zip_digest/cycle-11/constraints-catalog-2026-08-09-cycle11.md
- Output: /var/workspace/session/zip_digest/cycle-11/new-ideas-cycle11.md
- LOCAL ONLY — not committed to any repo
