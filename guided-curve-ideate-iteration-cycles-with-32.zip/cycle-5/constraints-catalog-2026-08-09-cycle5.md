# Constraints Catalog — 2026-08-09 cycle 5

**Cycle:** 5 (extends cycle-4 empirical-gate findings)
**Driver:** apply top 2 from cycle-4 (mixed-radix weighting + Möbius decoupling) as cycle-5 lens frontier.

## Current operational instantiation (UNCHANGED)

| Axis | Value |
|---|---|
| ℓ | 384 |
| m | 3 |
| sin^n θ polar | n = 384 |
| D | 384 |
| Sampling | Fibonacci (Vogel's golden-angle) |
| Möbius | frozen (refine-once at corpus creation) |
| freq_sym | 3-fold (m_k = 3k, k=1..128) |
| Per-item basis dim | 384 |
| Realized P | 147,840 |

## Cycle-5 axes of variation

Cycle-4 measurement found:
- **Column weighting** moves PC1+PC2 (mixed-radix 3+4 → +4.0%).
- **Möbius DOF** does NOT move PC1+PC2 (decoupled).

Cycle-5 introduces:

### Axis 10 (NEW): Column-weighting vector

Each candidate carries a 9-D weight vector `[w_0, ..., w_8]` applied to the 9 primitives before PCA top-2. Default: `[1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0]` (uniform, gives baseline 0.6637). Cycle-4 hardcoded mixed-radix `[1, 1, 1, 0.5, 0.5, 1, 0.5, 0.5, 1]` gave 0.6901.

- **L13 candidates** sweep structured subsets of {0.0, 0.25, 0.5, 0.75, 1.0, 1.5} across the 9 entries.

### Axis 11 (NEW): Curve-fit cost proxy

Each candidate carries an estimated total ops = ridge_ops + refit_ops, where:
- `ridge_ops = D × n_basis² + n_basis³` (matrix multiply + Cholesky)
- `refit_ops = n_Möbius × D × n_basis` (L-BFGS refit per step)

Default: ridge_ops only (frozen Möbius, refit_ops = 0).

- **L14 candidates** vary n_Möbius and D to find the cost-optimal Möbius-active configuration.

## Cycle-5 calculations

Identical to cycle-4, plus:
- **PC1+PC2 with column weighting**: per-axis weight vector applied to coverage matrix before SVD.
- **Total ops cost**: ridge-solve ops + L-BFGS refit ops.

## Cycle-5 lens coverage

| Lens | Tests | Source |
|---|---|---|
| L13 — column-weight sweep | Free weights, find optimum | Cycle-4 mixed-radix finding |
| L14 — Möbius-cost | Cost-optimal Möbius-active | Cycle-4 decoupling finding |

## Audit trail

- Generated 2026-08-09T22:05:00
- Source: cycle-4 measurement (cycle-5 builds on it)
- Output: new-ideas-cycle5.md
