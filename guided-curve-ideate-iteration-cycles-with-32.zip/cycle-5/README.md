# Iteration cycle 5 snapshot — MEASURED, L13 + L14

**Skill:** guided-curve-ideate
**Cycle:** 5 of 5 (final, measured)
**Catalog:** constraints-catalog-2026-08-09-cycle5.md
**Output:** new-ideas-cycle5.md
**Measurement backend:** `empirical_gate_sweep.py` (cycle-5 driver) over `empirical_gate.py` (cycle-4 adapter) over `papers/scripts/fit-full-curve-map.py` (main repo)

## What's new vs cycle 4

Cycle 4 measured all 21 candidates on the 0.40 PC1+PC2 gate and found:
- **Mixed-radix (3+4) column weighting improves the gate**: 0.6637 → 0.6901 (+4.0%).
- **Möbius is decoupled from PC1+PC2**: all 6 Möbius variants measure identically at every D.

Cycle 5 builds on both:
- **L13 — Column-weight sweep**: parametrize weights [w₀…w₈] as free parameters, measure 20 structured-grid combinations, find the optimum. **Best: 0.8080** (W18 pure-3fold weighting = `[1,1,1,0,0,1,0,0,1]`), +0.1443 above baseline.
- **L14 — Möbius-cost-only lens**: hold D/lobe/freq at current, vary only Möbius DOF, estimate curve-fit downstream cost (ridge ops + L-BFGS refit proxy). **All 11 measure 0.6637** (gate decoupled). Lowest cost: L14-M07 subgroup-2 at D=128 (4×10⁴ total ops).

## Headline finding

| Lens | Best PC1+PC2 | Δ over baseline (0.6637) |
|---|---:|---:|
| Cycle-4 best (mixed-radix 3+4) | 0.6901 | +0.0264 |
| **Cycle-5 L13-W18 (pure-3fold weighting)** | **0.8080** | **+0.1443** |
| Cycle-5 L13-W19 (pure-4fold weighting) | 0.7854 | +0.1217 |

**The W18 pure-3fold weighting is the single biggest measured gate improvement in any cycle so far** — 5.5× the cycle-4 mixed-radix improvement.

## What's in this snapshot

- README.md (this file)
- SKILL.md (skill definition, with cycle-5 lenses L13 + L14)
- empirical_gate_sweep.py — cycle-5 driver (L13 + L14)
- candidates-l13.json — 20 weight-grid candidates
- candidates-l14.json — 11 Möbius-cost candidates
- empirical_gate_results_cycle5.json — measured values for all 31 candidates
- constraints-catalog-2026-08-09-cycle5.md (cycle-5 axes)
- new-ideas-cycle5.md (ref doc)
- new-ideas-cycle5.json (machine-readable)
- missing-from-cycle4.md (gap doc from cycle-5 generation)

LOCAL ONLY — no commits, no GitHub pushes, no Linear activity.

## Cycle progression

| Cycle | Frontier | Best measured PC1+PC2 |
|---|---|---:|
| 1 | baseline 6 lenses | (qualitative) |
| 2 | novelty re-scored, L4-01 (D=256) surfaced | (qualitative) |
| 3 | D-sweep + breakthrough detection | (qualitative) |
| 4 | empirical_gate wired | 0.6901 (mixed 3+4) |
| **5** | **column-weight sweep + Möbius-cost lens** | **0.8080** (pure-3fold) |

## What the cycle-5 measurement settled

1. **The W18 pure-3fold weighting is the gate-improvement optimum** among the 20 structured-grid candidates tested. Zeroing the 4 primitives at positions {3, 4, 6, 7} (m=4, 5, 7, 8) bumps PC1+PC2 from 0.6637 → 0.8080.
2. **Möbius is fully decoupled from the gate**, confirmed under cycle-5's extended D sweep (D=128, 192, 256 with each of {subgroup-2, full-PSL}).
3. **The breakthrough from cycle-3 (D=256) is the cost story, not the gate story.** The gate improvement comes from column weighting (cycle-5), not from rank reduction (cycle-4).
4. **The 31 cycle-5 candidates all PASS the 0.40 gate**, confirming the cycle-4 finding that the gate is robust across all axis variations on the 79-skill corpus.

## What's still open (cycle-6 candidates)

- **L13-W18 on a basis that matches the weighting**: does the gate improvement carry through to a candidate's actual fit, or is it a projection-only finding?
- **Combined candidate**: L13-W18-style weighting at D=128 with subgroup-2 Möbius → if the gate holds at 0.8080 with P=16,514, this is the Pareto-optimal candidate.
- **Full cost model**: ridge-ops + L-BFGS proxy is the cycle-5 cost model; sampling, hyperparameter search, and convergence iterations are excluded.

## Audit trail

- Generated 2026-08-09T22:05:00 via guided-curve-ideate (cycle-5, measured)
- Source skill: session/guided-curve-ideate/SKILL.md
- Implementation: empirical_gate_sweep.py (cycle-5 driver)
- Measurement: empirical_gate.py (cycle-4 adapter) over papers/scripts/fit-full-curve-map.py
- Corpus: papers/data/rsi-79-corpus-multi-cycle-2026-08-06.json (79 skills, 9 primitives)
- Input: /var/workspace/session/zip_digest/cycle-5/constraints-catalog-2026-08-09-cycle5.md
- Output: /var/workspace/session/zip_digest/cycle-5/new-ideas-cycle5.md
- LOCAL ONLY — not committed to any repo
