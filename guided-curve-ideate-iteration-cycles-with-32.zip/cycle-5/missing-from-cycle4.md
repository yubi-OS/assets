# What's missing from cycle 4 — and how cycle 5 addresses it

## Gaps in cycle 4

1. **Mixed-radix weighting was hardcoded.** Cycle-4 L3-02 / L10-04 used the weighting `[1,1,1,0.5,0.5,1,0.5,0.5,1]` (mults of 3 full, mults of 4 half, others 1/3). This is one of many possible weightings, and it improved the gate by +4.0%. But was it the **optimum**?
2. **Möbius-cost dimension wasn't measured.** Cycle-4 confirmed that Möbius is decoupled from PC1+PC2, but it didn't estimate the **downstream curve-fit cost** (ridge ops + L-BFGS refit) for each Möbius variant. Without a cost model, we can't rank the Möbius-active candidates by tractability.
3. **No cost ranking.** Cycle-4 ranked by score (qualitative) and by P. It did not produce a cost-optimal frontier.

## Cycle-5 fix

| Gap | Cycle-5 fix |
|---|---|
| Hardcoded mixed-radix weighting | **L13** sweeps 20 weight combinations (down-selected from 6⁹ = 10M) and measures each. Found: **L13-W18 pure-3fold weighting** = `[1,1,1,0,0,1,0,0,1]` → PC1+PC2 = **0.8080**, +0.1443 above baseline. **5.5× the cycle-4 mixed-radix improvement.** |
| Möbius cost unmeasured | **L14** estimates the curve-fit downstream cost via ridge-ops + L-BFGS refit proxy. **All 11 candidates measure 0.6637** (gate decoupled); cost ranking by total ops. |
| No cost-optimal frontier | L13-W18 + L14-M07 (subgroup-2 D=128) is the **Pareto candidate** to test in cycle 6: highest gate + lowest cost. |

## What cycle-5 still doesn't address (open for cycle 6)

1. **L13-W18 on a basis that matches the weighting.** The 0.8080 measurement is a projection-only finding — the cycle-4 empirical_gate ran PCA on the column-weighted coverage matrix. A candidate whose basis actually excludes the zeroed primitives (m=4,5,7,8) may not produce those primitives in its coverage at all, so the gate improvement may carry through to the downstream fit. This needs to be tested.
2. **Full cost model.** The cycle-5 cost proxy is `D × n_basis² + n_basis³ + n_Möbius × D × n_basis`. It excludes: sampling cost, hyperparameter search, convergence iterations. For a full cost model, run `papers/scripts/build_per_corpus_curves.py` and measure wall-clock.
3. **PC1+PC2 on refs/, docs/ corpora.** Cycle-5 measured only on the 79-skill corpus (skills/). The cycle-3 audit extended to docs/ (21 files), refs/ (113 files), self/. Each will measure differently; the L13-W18 weighting may not transfer.
4. **Beyond-9-D feature space.** The main paper's Table E.1 has 24-D = 0.2993 (FAIL). Cycle-5 candidates don't extend the feature space — they only reweight within the 9 primitives.

## Cycle-6 candidate lenses

- **L15** — basis-side validation of L13-W18: build a basis that spans only the W18-kept primitives (m=1,2,3,6,9), measure classifier downstream.
- **L16** — full cost model: extend L14 with sampling + hyperparameter + convergence costs.
- **L17** — cross-corpus replication: run L13 + L14 on docs/, refs/, self/ corpora.
- **L18** — beyond-9-D: extend L13 weighting to 16-D, 24-D, 384-D feature spaces.

These are the cycle-6 lenses if the user wants another iteration.
