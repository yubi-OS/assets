#!/usr/bin/env python3
"""
empirical_gate_sweep.py — cycle-5 measurement driver.

Wraps empirical_gate.evaluate_candidate() with two cycle-5 lens modes:
  - L13 (weight_grid): pass explicit 9-vector weights
  - L14 (moebius_cost): add n_Moebius, P, downstream-cost proxy

Output: empirical_gate_results_cycle5.json
"""
from __future__ import annotations
import json, sys
from pathlib import Path

sys.path.insert(0, "/var/workspace/session/zip_digest/cycle-4")
from empirical_gate import load_corpus_79, build_coverage_matrix, pca_top2_measured, GATE, PRIMITIVES

import numpy as np


def ridge_cost_proxy(D: int, basis_dim: int, n_basis: int = 16, n_Mobius: int = 0) -> dict:
    """Estimate the closed-form ridge solve cost.
    The fit-full-curve-map.py pipeline does C* = (Phi^T Phi + lambda I)^{-1} Phi^T Z
    where Phi is N x n_basis, Z is N x D. The dominant cost is the n_basis x n_basis
    linear solve. Per-cycle Mobius L-BFGS refit adds n_Mobius gradient steps.
    """
    phi_ops = float(D) * float(n_basis) * float(n_basis)  # matrix multiply
    solve_ops = float(n_basis) ** 3  # Cholesky / LU on n_basis x n_basis
    ridge_ops = phi_ops + solve_ops
    if n_Mobius > 0:
        refit_ops = float(n_Mobius) * float(D) * float(n_basis)  # L-BFGS per-step
    else:
        refit_ops = 0.0
    total_ops = ridge_ops + refit_ops
    return {
        "phi_ops": phi_ops,
        "solve_ops": solve_ops,
        "ridge_ops": ridge_ops,
        "n_Mobius": n_Mobius,
        "refit_ops": refit_ops,
        "total_ops": total_ops,
    }


def evaluate_l13(corpus: dict, cand: dict) -> dict:
    C, slugs = build_coverage_matrix(corpus)
    w = np.array(cand["weights"], dtype=np.float64)
    pc1, pc2, rank = pca_top2_measured(C, w)
    pc1pc2 = pc1 + pc2
    return {
        "id": cand["id"],
        "lens": "L13-weight-sweep",
        "axes": {"D": cand["D"], "lobe_convention": cand["lobe_convention"],
                 "freq_sym": cand["freq_sym"], "Moebius": cand["Moebius"]},
        "weights": cand["weights"],
        "pc1_measured": round(pc1, 4),
        "pc2_measured": round(pc2, 4),
        "pc1_plus_pc2_measured": round(pc1pc2, 4),
        "gate": "PASS" if pc1pc2 >= GATE else "FAIL",
        "rank": rank,
        "n_items": corpus["n_items"],
        "rationale": cand.get("rationale", ""),
    }


def evaluate_l14(corpus: dict, cand: dict) -> dict:
    C, slugs = build_coverage_matrix(corpus)
    # No weight override; L14 holds D/lobe/freq at current
    pc1, pc2, rank = pca_top2_measured(C, np.ones(9, dtype=np.float64))
    pc1pc2 = pc1 + pc2
    cost = ridge_cost_proxy(cand["D"], basis_dim=cand["D"], n_basis=16, n_Mobius=cand["n_Moebius"])
    return {
        "id": cand["id"],
        "lens": "L14-moebius-cost",
        "axes": {"D": cand["D"], "lobe_convention": cand["lobe_convention"],
                 "freq_sym": cand["freq_sym"], "Moebius": cand["Moebius"]},
        "pc1_measured": round(pc1, 4),
        "pc2_measured": round(pc2, 4),
        "pc1_plus_pc2_measured": round(pc1pc2, 4),
        "gate": "PASS" if pc1pc2 >= GATE else "FAIL",
        "rank": rank,
        "n_items": corpus["n_items"],
        "n_Mobius": cand["n_Moebius"],
        "P_realized": cand["P"],
        "ridge_cost": cost,
        "rationale": cand.get("rationale", ""),
    }


def main():
    corpus_path = "/var/workspace/session/main_zip/yubiOS-main/papers/data/rsi-79-corpus-multi-cycle-2026-08-06.json"
    corpus = load_corpus_79(Path(corpus_path))

    with open("/var/workspace/session/zip_digest/cycle-5/candidates-l13.json") as f:
        cands_l13 = json.load(f)
    with open("/var/workspace/session/zip_digest/cycle-5/candidates-l14.json") as f:
        cands_l14 = json.load(f)

    results_l13 = [evaluate_l13(corpus, c) for c in cands_l13]
    results_l14 = [evaluate_l14(corpus, c) for c in cands_l14]

    # Rank L13 by pc1_plus_pc2_measured desc
    results_l13_sorted = sorted(results_l13, key=lambda r: -r["pc1_plus_pc2_measured"])
    for i, r in enumerate(results_l13_sorted):
        r["rank_in_lens"] = i + 1

    # Rank L14 by total_ops asc (cost-minimizing)
    results_l14_sorted = sorted(results_l14, key=lambda r: r["ridge_cost"]["total_ops"])
    for i, r in enumerate(results_l14_sorted):
        r["rank_in_lens"] = i + 1

    out = {
        "cycle": 5,
        "generated": "2026-08-09T22:00:00",
        "corpus_source": corpus_path,
        "n_items": corpus["n_items"],
        "gate_threshold": GATE,
        "l13_results": results_l13_sorted,
        "l14_results": results_l14_sorted,
        "l13_summary": {
            "n_candidates": len(results_l13),
            "n_passed": sum(1 for r in results_l13 if r["gate"] == "PASS"),
            "best_pc1pc2": max(r["pc1_plus_pc2_measured"] for r in results_l13),
            "worst_pc1pc2": min(r["pc1_plus_pc2_measured"] for r in results_l13),
            "improvement_over_baseline_06637": round(
                max(r["pc1_plus_pc2_measured"] for r in results_l13) - 0.6637, 4
            ),
        },
        "l14_summary": {
            "n_candidates": len(results_l14),
            "n_passed": sum(1 for r in results_l14 if r["gate"] == "PASS"),
            "all_decoupled_from_gate": all(
                abs(r["pc1_plus_pc2_measured"] - 0.6637) < 1e-4 for r in results_l14
            ),
            "lowest_cost_candidate": results_l14_sorted[0]["id"],
        },
    }

    with open("/var/workspace/session/zip_digest/cycle-5/empirical_gate_results_cycle5.json", "w") as f:
        json.dump(out, f, indent=2)

    print("=== L13 (weight sweep) ===")
    for r in results_l13_sorted[:5]:
        print(f"  rank {r['rank_in_lens']:>2}  {r['id']:30s}  PC1+PC2={r['pc1_plus_pc2_measured']:.4f}  {r['gate']}")
    print(f"  best: {out['l13_summary']['best_pc1pc2']:.4f}, "
          f"improvement over baseline 0.6637: +{out['l13_summary']['improvement_over_baseline_06637']:.4f}")

    print("\n=== L14 (Moebius cost) ===")
    for r in results_l14_sorted[:5]:
        c = r["ridge_cost"]
        print(f"  rank {r['rank_in_lens']:>2}  {r['id']:30s}  PC1+PC2={r['pc1_plus_pc2_measured']:.4f}  "
              f"n_Mobius={r['n_Mobius']:>2}  total_ops={c['total_ops']:.2e}  P={r['P_realized']:,}")
    print(f"  all_decoupled_from_gate: {out['l14_summary']['all_decoupled_from_gate']}")
    print(f"  lowest_cost: {out['l14_summary']['lowest_cost_candidate']}")

    print(f"\nWrote empirical_gate_results_cycle5.json")


if __name__ == "__main__":
    main()
