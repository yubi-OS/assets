# New Ideas — guided-curve-ideate output (2026-08-09, cycle 5 — MEASURED)

**Source skill:** `guided-curve-ideate` (LOCAL ONLY, not committed)
**Input catalog:** `/var/workspace/session/zip_digest/cycle-5/constraints-catalog-2026-08-09-cycle5.md`
**Measurement backend:** `empirical_gate_sweep.py` (cycle-5 driver) → `empirical_gate.py` (cycle-4 adapter over `papers/scripts/fit-full-curve-map.py`)
**Corpus:** `/var/workspace/session/main_zip/yubiOS-main/papers/data/rsi-79-corpus-multi-cycle-2026-08-06.json` (79 skills, 9 primitives)
**Candidates measured:** 31 (20 L13 + 11 L14)
**Output target:** `/var/workspace/session/zip_digest/cycle-5/new-ideas-cycle5.md`

## Cycle progression (cumulative)

| Cycle | Lens frontier | Best measured PC1+PC2 | Δ over baseline (0.6637) |
|---|---|---:|---:|
| 1 | baseline 6 lenses | (qualitative) | — |
| 2 | novelty re-scored + L4-01 (D=256) surfaced | (qualitative) | — |
| 3 | D-sweep + breakthrough detection (post-hoc filter) | (qualitative) | — |
| 4 | empirical_gate wired, all 21 candidates measured | **0.6901** (mixed 3+4) | **+0.0264** |
| **5** | **L13 column-weight sweep + L14 Möbius-cost lens** | **0.8080** (pure-3fold weighting) | **+0.1443** |

## Top improvements from cycle-4 (now measured into cycle-5)

Cycle-4 surfaced two measured findings:
1. **Mixed-radix (3+4) column weighting improves the gate by +4.0%** (0.6637 → 0.6901).
2. **Möbius is decoupled from PC1+PC2** (all 6 Möbius variants measure identically at every D).

Cycle-5 builds directly on these:
- **L13** asks: can we do better than the cycle-4 hardcoded weighting `[1,1,1,0.5,0.5,1,0.5,0.5,1]`? Sweep 20 weight combinations.
- **L14** asks: since Möbius is decoupled, what's the cost-optimal Möbius choice across D? Estimate the curve-fit downstream cost (ridge ops + L-BFGS refit) and rank by total ops.

## L13 — column-weight sweep (top 5 of 20)

| Rank | ID | Weights | PC1+PC2 | Δ over baseline |
|---|---|---|---:|---:|
| **1** | **L13-W18 pure-3fold** | `[1, 1, 1, 0, 0, 1, 0, 0, 1]` | **0.8080** | **+0.1443** |
| 2 | L13-W19 pure-4fold | `[0, 0, 0, 1, 1, 0, 1, 1, 0]` | 0.7854 | +0.1217 |
| 3 | L13-W15 zigzag | `[1.5, 0.5, 1.5, 0.5, 1.5, 0.5, 1.5, 0.5, 1.5]` | 0.7838 | +0.1201 |
| 4 | L13-W07 all-m4-down | `[1, 1, 1, 0.25, 0.25, 1, 0.25, 0.25, 1]` | 0.7675 | +0.1038 |
| 5 | L13-W17 decel-odd | `[0.5, 1, 0.5, 1, 0.5, 1, 0.5, 1, 0.5]` | 0.7537 | +0.0900 |

**20/20 L13 candidates PASS** the 0.40 gate. The full sweep range is 0.6523 (worst) → **0.8080** (best) → +0.1443 above baseline.

### What L13-W18 (pure-3fold) means

The weighting `[1, 1, 1, 0, 0, 1, 0, 0, 1]` zeros out the four primitives at positions {3, 4, 6, 7} (m=4, 5, 7, 8) and keeps the four at positions {0, 1, 2, 5, 8} (m=1, 2, 3, 6, 9). What remains is a **3-fold-aligned** primitive subset: those that resonate with m_k = 3k (m=3, 6, 9) and m_k = 3k±1 (m=2, 5, 8).

This is the **strongest gate-improvement measurement** in any cycle. It says: if we commit to a 3-fold ladder and zero out the 4-fold-aligned primitives from the coverage matrix, the PCA concentrates better — because the remaining primitives carry the same symmetry, and PCA top-2 finds it cleanly.

**Caveat**: this is a **measurement on the 9-D binary coverage matrix**, not on a candidate's basis fit. A candidate whose basis actually spans the zeroed primitives will not produce those primitives in the corpus coverage (the corpus's coverage is fixed at 79 skills × 9 primitives). So this is a *projection* finding, not a *basis* finding. Cycle-6 work should test whether a candidate whose lobe convention matches the L13-W18 weighting (i.e., a pure-3fold basis) actually *fits* the corpus with PC1+PC2 = 0.8080 in the classifier's downstream ridge solve.

## L14 — Möbius-cost lens (top 5 of 11 by total ops)

| Rank | ID | D | Möbius | n_Möbius | Total ops | PC1+PC2 | P |
|---|---|---:|---|---:|---:|---:|---:|
| **1** | **L14-M07 sub2-D128** | 128 | subgroup-2 | 2 | **4.10e+04** | 0.6637 | 16,514 |
| 2 | L14-M10 full-PSL-D128 | 128 | full-PSL | 6 | 4.92e+04 | 0.6637 | 16,518 |
| 3 | L14-M06 sub2-D192 | 192 | subgroup-2 | 2 | 5.94e+04 | 0.6637 | 37,058 |
| 4 | L14-M09 full-PSL-D192 | 192 | full-PSL | 6 | 7.17e+04 | 0.6637 | 37,062 |
| 5 | L14-M05 sub2-D256 | 256 | subgroup-2 | 2 | 7.78e+04 | 0.6637 | 65,794 |

**11/11 L14 candidates PASS** the 0.40 gate. **All measure identically at PC1+PC2 = 0.6637** — Möbius is confirmed decoupled from the gate. The cost proxy sorts cleanly by D (lower D = lower cost), with subgroup-2 < full-PSL within each D band.

### What L14-M07 (sub2-D128) means

**Möbius is decoupled from PC1+PC2**. The cycle-4 finding holds under cycle-5's extended D sweep. The cost-optimal configuration is **subgroup-2 at D=128**: n_Möbius=2 (just enough to refine), P=16,514 (38% of current's 147,840), total ops ≈ 4×10⁴. This is the **lowest-cost Möbius-active** configuration that preserves the gate.

The cycle-5 cost model is a **ridge-solve proxy** (Φ ops + n_basis³ Cholesky + L-BFGS refit steps). It doesn't include sampling cost, hyperparameter search cost, or convergence iterations. For a full cost model, see `papers/scripts/build_per_corpus_curves.py` line 582 (which measures wall-clock fit time per corpus).

## Combined cycle-5 recommendation

**Best gate-improvement candidate**: L13-W18 (pure-3fold weighting, D=384) → **PC1+PC2 = 0.8080** measured. **Penalty**: the projection zeros 4 primitives, which may not be a basis the corpus's primitive coverage actually spans. **Test**: build a basis that matches the W18 weighting (e.g., 3-fold-only primitive basis at the cycle-1 L7-01 negative-m-style exclusion) and re-measure.

**Best cost-reduction candidate**: L14-M07 (subgroup-2 Möbius at D=128) → **PC1+PC2 = 0.6637** measured, **P = 16,514** (11% of current), **total ops = 4×10⁴**. **Penalty**: same gate as baseline, no improvement. **Use as**: a regression-safe cost-reduction fallback.

**Best combined**: L13-W18-style weighting at D=128 (subgroup-2 Möbius) → if a 3-fold-aligned basis at D=128 produces PC1+PC2 = 0.8080 on the same corpus, this would be the **Pareto-optimal** candidate (highest gate + lowest cost). Cycle-6 should test this combined candidate.

## Test sequence (recommended order)

1. **Run L13-W18-style basis at D=128, 256, 384** — build a basis that only spans the W18-weighted primitives (m=1,2,3,6,9) and measure the gate. If 0.8080 holds, this is the cycle-6 breakthrough.
2. **Run L14-M07 (subgroup-2 D=128) classifier** — confirm the cycle-4 finding that Möbius is decoupled, on a fresh seed.
3. **Run L14-M10 (full-PSL D=128) classifier** — test the highest-Möbius-DOF at the lowest-D; if the cost gap closes (because n_basis³ is now tiny), full-PSL becomes competitive at D=128.
4. **Last**: L13-W19 (pure-4fold weighting) — does the symmetric case (zero the 3-fold-aligned primitives) also work? If so, the gate improvement is symmetry-driven, not 3-fold-specific.

For each candidate, the empirical signature is:

- **PC1+PC2 ≥ 0.40 (measured)** — confirmed for all 31 cycle-5 candidates
- **PC1+PC2 improvement over baseline** — L13-W18: +0.1443; L13-W19: +0.1217; others: +0.05 to +0.10
- **Möbius decoupled** — L14 confirms cycle-4's finding; gate is invariant under Möbius DOF variation
- **Cost (ops)** — L14-M07: 4×10⁴ (lowest); L14-M04 per-tier-D=384: 3.6×10⁶ (highest among tested)

## Key assumptions (now measurable)

- [x] PC1+PC2 is a corpus-coverage property, not a candidate-basis property (cycle-4 finding, cycle-5 confirms)
- [x] Column weighting moves the gate; the W18 weighting is the best measured (cycle-5 L13)
- [x] Möbius is decoupled from PC1+PC2 (cycle-4 + cycle-5 L14 confirms)
- [x] The 0.40 gate is robust across 31 axis variations (cycle-5 confirms)
- [x] **NEW**: Zero-weighting on certain primitives improves the gate by +0.1443 (cycle-5 L13-W18)

## What remains unmeasured

- **L13-W18 on a basis that matches the weighting** — does the gate improvement carry through to a candidate's actual fit, or is it a projection-only finding?
- **Full cost model** — the cycle-5 cost proxy is ridge-ops + L-BFGS; sampling, hyperparameter search, and convergence iterations are excluded.
- **PC1+PC2 on different corpora** — refs/, docs/ corpora will measure differently; the L13-W18 weighting may not transfer.
- **Beyond-9-D feature space** — 24-D and 384-D extensions go to the main paper's classifier at `papers/scripts/build-nd-axis-viewer.py`.

## Audit trail

- Generated 2026-08-09T22:05:00 via guided-curve-ideate (cycle-5, measured)
- Measurement: empirical_gate_sweep.py (cycle-5 driver) → empirical_gate.py (cycle-4 adapter)
- Source: papers/scripts/fit-full-curve-map.py (main repo, PCA top-2 on 9-D coverage)
- Corpus: papers/data/rsi-79-corpus-multi-cycle-2026-08-06.json (79 skills, 9 primitives)
- L13 candidates: 20 weight-grid combinations (down-selected from 6⁹ = 10M)
- L14 candidates: 11 Möbius-cost candidates (6 DOF variants × 4 D values, minus per-tier × full D)
- Input: /var/workspace/session/zip_digest/cycle-5/constraints-catalog-2026-08-09-cycle5.md
- Output: /var/workspace/session/zip_digest/cycle-5/new-ideas-cycle5.md
- LOCAL ONLY — not committed to any repo
