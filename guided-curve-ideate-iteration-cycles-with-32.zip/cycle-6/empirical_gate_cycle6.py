#!/usr/bin/env python3
"""
empirical_gate_cycle6.py — cycle-6 measurement driver.

Three lenses built on cycle-5 top picks:
  - L15 — Pareto-optimal combined (W18 weighting × D-sweep × Möbius variants)
  - L16 — Cross-corpus replication (skills/ docs/ refs/)
  - L17 — Beyond-9-D feature spaces (24-D synthetic extension)

Reuses empirical_gate.py from cycle-4 as the measurement backend.
"""
from __future__ import annotations
import json, sys
from pathlib import Path

sys.path.insert(0, "/var/workspace/session/zip_digest/cycle-4")
from empirical_gate import build_coverage_matrix, pca_top2_measured, GATE, PRIMITIVES

import numpy as np


CORPORA = {
    "skills": "/var/workspace/session/main_zip/yubiOS-main/papers/data/rsi-79-corpus-multi-cycle-2026-08-06.json",
    "docs":   "/var/workspace/session/main_zip/yubiOS-main/papers/data/rsi-docs-21-corpus-2026-08-06.json",
    "refs":   "/var/workspace/session/main_zip/yubiOS-main/papers/data/rsi-refs-113-corpus-2026-08-06.json",
}


def load_corpus_any(path: Path) -> dict:
    """Unified loader for skills/docs/refs corpus files.
    skills: cycle-1 entries have 'slug' key
    docs/refs: cycle-1 entries have 'file' key
    Both: 'missing_primitives' field gives the 9-D coverage.
    """
    with open(path) as f:
        doc = json.load(f)
    items = []
    seen = set()
    for entry in doc.get("all_cycles", []):
        if entry.get("cycle") != 1:
            continue
        slug = entry.get("slug") or entry.get("file")
        if slug in seen:
            continue
        seen.add(slug)
        missing = set(entry.get("missing_primitives", []))
        cov = [0 if p in missing else 1 for p in PRIMITIVES]
        items.append({"slug": slug, "coverage": cov})
    return {
        "n_items": len(items),
        "primitives": PRIMITIVES,
        "items": items,
        "source": str(path),
    }


def measure(C: np.ndarray, weights: np.ndarray) -> tuple[float, float, float, int]:
    pc1, pc2, rank = pca_top2_measured(C, weights)
    return pc1, pc2, pc1 + pc2, rank


def ridge_cost_proxy(D, n_basis=16, n_Mobius=0):
    phi_ops = float(D) * float(n_basis) * float(n_basis)
    solve_ops = float(n_basis) ** 3
    ridge_ops = phi_ops + solve_ops
    refit_ops = float(n_Mobius) * float(D) * float(n_basis) if n_Mobius > 0 else 0.0
    return {"phi_ops": phi_ops, "solve_ops": solve_ops, "ridge_ops": ridge_ops,
            "n_Mobius": n_Mobius, "refit_ops": refit_ops, "total_ops": ridge_ops + refit_ops}


# ===========================================================================
# L15 candidates — Pareto-optimal combined (W18 × D × Möbius)
# ===========================================================================
W18 = [1.0, 1.0, 1.0, 0.0, 0.0, 1.0, 0.0, 0.0, 1.0]
W19 = [0.0, 0.0, 0.0, 1.0, 1.0, 0.0, 1.0, 1.0, 0.0]

L15_CANDIDATES = []
for D in [128, 192, 256, 384]:
    for Moebius, n_Mobius in [("frozen", 0), ("subgroup-2", 2), ("full-PSL", 6)]:
        L15_CANDIDATES.append({
            "id": f"L15-W18-D{D}-{(Moebius or 'frozen').replace('-', '')}",
            "weights": W18, "D": D, "Moebius": Moebius, "n_Moebius": n_Mobius,
            "lens": "L15-pareto-combined",
            "rationale": f"W18 weighting × D={D} × Möbius={Moebius}",
        })
    # Plus W19 + W18 × D=384 with per-tier Möbius (highest DOF)
    L15_CANDIDATES.append({
        "id": f"L15-W19-D{D}-frozen",
        "weights": W19, "D": D, "Moebius": "frozen", "n_Moebius": 0,
        "lens": "L15-pareto-combined",
        "rationale": f"W19 weighting × D={D}",
    })


# ===========================================================================
# L16 candidates — Cross-corpus replication
# ===========================================================================
L16_CANDIDATES = []
for corpus_name in ["skills", "docs", "refs"]:
    for weights, label in [(W18, "W18"), (W19, "W19"), ([1.0]*9, "uniform")]:
        L16_CANDIDATES.append({
            "id": f"L16-{corpus_name}-{label}",
            "weights": weights,
            "D": 384, "Moebius": "frozen", "n_Moebius": 0,
            "lens": "L16-cross-corpus",
            "corpus": corpus_name,
            "rationale": f"{label} weighting on {corpus_name} corpus",
        })


# ===========================================================================
# L17 candidates — Beyond-9-D feature spaces (24-D synthetic)
# ===========================================================================
def synthesize_24d(C9: np.ndarray) -> np.ndarray:
    """Recreate the 24-D feature extension per main paper Table E.1:
    9-D + 12 NSS (pod-security-standards) + 3 meta features.
    We approximate the extension deterministically:
      - 12 NSS: each is a noisy projection of the 9-D binary vector
      - 3 meta: row-mean, row-sum, density
    """
    rng = np.random.default_rng(seed=7913)
    N = C9.shape[0]
    # 12 NSS columns: each = projection onto a fixed random direction + Gaussian noise
    nss_dirs = rng.standard_normal((12, 9))
    nss = (C9 @ nss_dirs.T) + 0.05 * rng.standard_normal((N, 12))
    # 3 meta columns: row-mean, row-sum (already in {0..9}), density
    meta = np.column_stack([
        C9.mean(axis=1),
        C9.sum(axis=1) / 9.0,
        (C9.sum(axis=1) >= 5).astype(float),
    ])
    return np.column_stack([C9, nss, meta])


L17_CANDIDATES = [
    # Baseline: 24-D uniform weighting (should FAIL like the main paper)
    {
        "id": "L17-24D-uniform-baseline",
        "feature_dim": 24,
        "weights_9d": [1.0]*9,
        "weights_nss": [1.0]*12,
        "weights_meta": [1.0]*3,
        "D": 384, "Moebius": "frozen",
        "lens": "L17-beyond-9d",
        "rationale": "24-D uniform — replicates main paper 24-D failure (expected ~0.30)",
    },
    # Hypothesis: W18 weighting on the 9-D portion, zero out NSS+meta
    {
        "id": "L17-24D-W18-on-9D-only",
        "feature_dim": 24,
        "weights_9d": W18,
        "weights_nss": [0.0]*12,
        "weights_meta": [0.0]*3,
        "D": 384, "Moebius": "frozen",
        "lens": "L17-beyond-9d",
        "rationale": "W18 on 9-D, zero NSS+meta — tests if W18 recovers the 24-D failure",
    },
    # Hybrid: W18 on 9-D + reduced weight on NSS+meta
    {
        "id": "L17-24D-W18-reduced-NSS",
        "feature_dim": 24,
        "weights_9d": W18,
        "weights_nss": [0.25]*12,
        "weights_meta": [0.5]*3,
        "D": 384, "Moebius": "frozen",
        "lens": "L17-beyond-9d",
        "rationale": "W18 on 9-D + reduced NSS/meta weight — partial credit",
    },
]


def evaluate_l15(corpus_skills: dict, cand: dict) -> dict:
    C, _ = build_coverage_matrix(corpus_skills)
    w = np.array(cand["weights"], dtype=np.float64)
    pc1, pc2, pc1pc2, rank = measure(C, w)
    cost = ridge_cost_proxy(cand["D"], n_Mobius=cand["n_Moebius"])
    return {
        "id": cand["id"], "lens": cand["lens"],
        "corpus": "skills",
        "D": cand["D"], "Moebius": cand["Moebius"], "n_Moebius": cand["n_Moebius"],
        "weights": cand["weights"],
        "pc1_measured": round(pc1, 4), "pc2_measured": round(pc2, 4),
        "pc1_plus_pc2_measured": round(pc1pc2, 4),
        "gate": "PASS" if pc1pc2 >= GATE else "FAIL",
        "rank": rank, "n_items": corpus_skills["n_items"],
        "ridge_cost": cost,
        "rationale": cand["rationale"],
    }


def evaluate_l16(corpora: dict, cand: dict) -> dict:
    corpus = corpora[cand["corpus"]]
    C, _ = build_coverage_matrix(corpus)
    w = np.array(cand["weights"], dtype=np.float64)
    pc1, pc2, pc1pc2, rank = measure(C, w)
    return {
        "id": cand["id"], "lens": cand["lens"],
        "corpus": cand["corpus"],
        "D": cand["D"], "Moebius": cand["Moebius"],
        "weights": cand["weights"],
        "pc1_measured": round(pc1, 4), "pc2_measured": round(pc2, 4),
        "pc1_plus_pc2_measured": round(pc1pc2, 4),
        "gate": "PASS" if pc1pc2 >= GATE else "FAIL",
        "rank": rank, "n_items": corpus["n_items"],
        "rationale": cand["rationale"],
    }


def evaluate_l17(corpus_skills: dict, cand: dict) -> dict:
    C, _ = build_coverage_matrix(corpus_skills)
    C24 = synthesize_24d(C)
    weights = np.concatenate([
        np.array(cand["weights_9d"], dtype=np.float64),
        np.array(cand["weights_nss"], dtype=np.float64),
        np.array(cand["weights_meta"], dtype=np.float64),
    ])
    pc1, pc2, pc1pc2, rank = measure(C24, weights)
    return {
        "id": cand["id"], "lens": cand["lens"],
        "corpus": "skills",
        "feature_dim": cand["feature_dim"],
        "weights_9d": cand["weights_9d"],
        "weights_nss": cand["weights_nss"],
        "weights_meta": cand["weights_meta"],
        "pc1_measured": round(pc1, 4), "pc2_measured": round(pc2, 4),
        "pc1_plus_pc2_measured": round(pc1pc2, 4),
        "gate": "PASS" if pc1pc2 >= GATE else "FAIL",
        "rank": rank, "n_items": corpus_skills["n_items"],
        "rationale": cand["rationale"],
    }


def main():
    corpora = {name: load_corpus_any(Path(path)) for name, path in CORPORA.items()}
    print("=== Corpus sizes ===")
    for name, c in corpora.items():
        print(f"  {name}: n_items={c['n_items']}")

    # L15
    print("\n=== L15 (Pareto combined) ===")
    l15_results = [evaluate_l15(corpora["skills"], c) for c in L15_CANDIDATES]
    # Sort by pc1pc2 desc, then by total_ops asc (Pareto front)
    l15_sorted = sorted(l15_results, key=lambda r: (-r["pc1_plus_pc2_measured"], r["ridge_cost"]["total_ops"]))
    for i, r in enumerate(l15_sorted):
        r["rank_in_lens"] = i + 1

    for r in l15_sorted[:5]:
        c = r["ridge_cost"]
        print(f"  rank {r['rank_in_lens']:>2}  {r['id']:35s}  PC1+PC2={r['pc1_plus_pc2_measured']:.4f}  "
              f"D={r['D']:>3}  Möbius={r['Moebius']:12s}  total_ops={c['total_ops']:.2e}  {r['gate']}")

    # L16
    print("\n=== L16 (cross-corpus) ===")
    l16_results = [evaluate_l16(corpora, c) for c in L16_CANDIDATES]
    # Group by corpus, sort by pc1pc2 desc within each
    l16_sorted = sorted(l16_results, key=lambda r: (r["corpus"], -r["pc1_plus_pc2_measured"]))
    for i, r in enumerate(l16_sorted):
        r["rank_in_lens"] = i + 1

    # Pivot: show W18, W19, uniform per corpus
    for corpus_name in ["skills", "docs", "refs"]:
        print(f"  --- {corpus_name} corpus (N={corpora[corpus_name]['n_items']}) ---")
        for r in l16_sorted:
            if r["corpus"] != corpus_name:
                continue
            print(f"    {r['id']:30s}  PC1+PC2={r['pc1_plus_pc2_measured']:.4f}  {r['gate']}")

    # L17
    print("\n=== L17 (beyond-9-D) ===")
    l17_results = [evaluate_l17(corpora["skills"], c) for c in L17_CANDIDATES]
    l17_sorted = sorted(l17_results, key=lambda r: -r["pc1_plus_pc2_measured"])
    for i, r in enumerate(l17_sorted):
        r["rank_in_lens"] = i + 1
    for r in l17_sorted:
        print(f"  rank {r['rank_in_lens']:>2}  {r['id']:30s}  PC1+PC2={r['pc1_plus_pc2_measured']:.4f}  {r['gate']}")

    # Compose output
    out = {
        "cycle": 6,
        "generated": "2026-08-09T22:10:00",
        "corpus_sources": CORPORA,
        "gate_threshold": GATE,
        "l15_results": l15_sorted,
        "l16_results": l16_sorted,
        "l17_results": l17_sorted,
        "l15_summary": {
            "n_candidates": len(l15_results),
            "n_passed": sum(1 for r in l15_results if r["gate"] == "PASS"),
            "best_pc1pc2": max(r["pc1_plus_pc2_measured"] for r in l15_results),
            "worst_pc1pc2": min(r["pc1_plus_pc2_measured"] for r in l15_results),
            "lowest_cost_candidate": min(l15_results, key=lambda r: r["ridge_cost"]["total_ops"])["id"],
        },
        "l16_summary": {
            "n_candidates": len(l16_results),
            "n_passed": sum(1 for r in l16_results if r["gate"] == "PASS"),
            "w18_pc1pc2_by_corpus": {
                name: next((r["pc1_plus_pc2_measured"] for r in l16_results
                            if r["corpus"] == name and r["id"].endswith("W18")), None)
                for name in ["skills", "docs", "refs"]
            },
            "w19_pc1pc2_by_corpus": {
                name: next((r["pc1_plus_pc2_measured"] for r in l16_results
                            if r["corpus"] == name and r["id"].endswith("W19")), None)
                for name in ["skills", "docs", "refs"]
            },
        },
        "l17_summary": {
            "n_candidates": len(l17_results),
            "n_passed": sum(1 for r in l17_results if r["gate"] == "PASS"),
            "w18_recovers_24d_failure": None,  # filled below
        },
    }
    # Test: does W18 recover the 24-D failure?
    baseline_24d = next(r for r in l17_results if r["id"] == "L17-24D-uniform-baseline")
    w18_24d = next(r for r in l17_results if r["id"] == "L17-24D-W18-on-9D-only")
    out["l17_summary"]["w18_recovers_24d_failure"] = w18_24d["pc1_plus_pc2_measured"] >= GATE
    out["l17_summary"]["baseline_24d_pc1pc2"] = baseline_24d["pc1_plus_pc2_measured"]
    out["l17_summary"]["w18_24d_pc1pc2"] = w18_24d["pc1_plus_pc2_measured"]

    out_path = "/var/workspace/session/zip_digest/cycle-6/empirical_gate_results_cycle6.json"
    with open(out_path, "w") as f:
        json.dump(out, f, indent=2)
    print(f"\nWrote {out_path}")


if __name__ == "__main__":
    main()
