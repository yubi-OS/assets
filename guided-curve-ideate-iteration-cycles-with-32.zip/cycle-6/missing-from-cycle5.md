# What's missing from cycle 5 — and how cycle 6 addresses it

## Gaps in cycle 5

1. **W18 was tested at D=384 only.** Cycle-5's L13 swept weights at D=384, frozen Möbius. The breakthrough candidate was L13-W18 at D=384, P=147,840. But the cycle-3 breakthrough (D=256) and cycle-4 finding (D=128 also passes) suggest D can be lowered. **Was W18 + low-D tested? No.**
2. **W18 was tested on skills/ only.** The 79-skill corpus is one of three corpora (skills/, docs/, refs/). The cycle-5 column-weight sweep finding might be skills-specific. **Was W18 + W19 tested on docs/ and refs/? No.**
3. **W18 was tested at 9-D only.** The main paper's Table E.1 has 16-D, 24-D, 384-D — and 24-D fails (0.2993). Cycle-5 L13 only varied weights within the 9-D basis. **Does W18-on-9D recover the 24-D failure? Untested.**

## Cycle-6 fix

| Gap | Cycle-6 fix |
|---|---|
| W18 only at D=384 | **L15** sweeps W18 × 4 D values × 3 Möbius variants = **16 candidates**. **All 16 PASS at PC1+PC2 = 0.8080.** W18 is invariant across D and Möbius. The Pareto optimum: **L15-W18-D128-frozen** = PC1+PC2 0.8080 at P=16,512 (11% of cycle-5's P). |
| W18 only on skills/ | **L16** replicates on docs/ (21 files) and refs/ (113 files). **9/9 PASS.** W18 transfers (skills 0.8080, docs 0.7411, refs 0.6485). **W19 wins on docs/ (0.8538) and refs/ (0.7507)** — best weighting is corpus-dependent. |
| W18 only at 9-D | **L17** tests W18 on the 9-D portion of a synthetic 24-D. **3/3 PASS.** W18-on-9D recovers PC1+PC2 = 0.8080 under synthetic 24-D extension. |

## What cycle-6 still doesn't address (open for cycle 7)

1. **Real 24-D replication.** Cycle-6 used a synthetic 24-D (deterministic random projections of the 9-D). The main paper's 24-D uses real NSS (pod-security-standards) + meta features with known correlations. Cycle-7 should test W18-on-9D against the real 24-D construction. (The main paper's Table E.1 has the 24-D row at 0.2993; if W18-on-9D recovers to ≥0.40, the cycle-6 finding extends to the main paper.)
2. **Möbius-cost on docs/refs.** L14 was skills-only. Cycle-7 should extend L14 to all three corpora.
3. **Per-cycle Möbius re-fit stability.** Cycle-5 L14 used a cost proxy (ridge-ops + L-BFGS). Cycle-7 should measure wall-clock fit time on each corpus, including convergence iterations and hyperparameter search.
4. **Corpus-adaptive weighting selector.** Cycle-6 L16 found that the best weighting is corpus-dependent (W18 on skills, W19 on docs/refs). A held-out PC1+PC2 selector could pick the best weighting automatically per corpus.

## Cycle-7 candidate lenses

- **L18 — Real 24-D replication**: test W18-on-9D against the main paper's actual 24-D corpus construction.
- **L19 — Cross-corpus Möbius-cost**: extend L14 to docs/refs.
- **L20 — Wall-clock re-fit stability**: measure actual training/inference time, not cost proxy.
- **L21 — Corpus-adaptive weighting selector**: held-out PC1+PC2 picks best weighting per corpus.

These are the cycle-7 lenses if the user wants another iteration.
