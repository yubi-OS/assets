# Constraints Catalog — 2026-08-09 cycle 6

**Cycle:** 6 (extends cycle-5 L13 + L14 with L15 Pareto combined, L16 cross-corpus, L17 beyond-9-D)
**Driver:** apply top picks from cycle-5 (W18 weighting + Möbius decoupling) as cycle-6 lens frontier.

## Current operational instantiation (UNCHANGED)

| Axis | Value |
|---|---|
| ℓ | 384 |
| m | 3 |
| sin^n θ polar | n = 384 |
| D | 384 |
| Sampling | Fibonacci (Vogel's golden-angle) |
| Möbius | frozen (refine-once at corpus creation) |
| freq_sym | 3-fold (m_k = 3k, k=1..128) |
| Per-item basis dim | 384 |
| Realized P | 147,840 |

## Cycle-5 axes (carried forward)

- **Axis 10 — Column-weighting vector**: `[w_0, ..., w_8]` applied to the 9 primitives before PCA top-2.
- **Axis 11 — Curve-fit cost proxy**: `total_ops = D × n_basis² + n_basis³ + n_Möbius × D × n_basis`.

## Cycle-6 axes (NEW)

- **Axis 12 — Multiple corpora**: skills/ (79), docs/ (21), refs/ (113). L16 measures W18 / W19 / uniform on each.
- **Axis 13 — Feature-space dimension**: 9-D (binary) or 24-D (9-D + 12 NSS + 3 meta). L17 tests W18 on the 9-D portion under synthetic 24-D extension.

## Cycle-6 lens coverage

| Lens | Tests | Source |
|---|---|---|
| L15 — Pareto combined | W18 × D-sweep × Möbius variants (16 candidates) | Cycle-5 W18 + D-reduction breakthrough |
| L16 — Cross-corpus | W18 / W19 / uniform × 3 corpora (9 candidates) | Cycle-5 W18 needs replication |
| L17 — Beyond-9-D | W18-on-9D / uniform / hybrid under synthetic 24-D (3 candidates) | Main paper Table E.1 24-D row |

## Cycle-6 calculations

Identical to cycle-5, plus:
- **Cross-corpus PC1+PC2**: load each corpus's `all_cycles[cycle=1]` entries, build per-corpus coverage matrix, run PCA top-2.
- **Beyond-9-D coverage**: 9-D + 12 synthetic NSS (random projections of 9-D + Gaussian noise) + 3 meta (row-mean, row-sum, density). PC1+PC2 on the 24-D matrix with W18-on-9D + zero NSS/meta.

## Audit trail

- Generated 2026-08-09T22:10:00
- Source: cycle-5 measurement (cycle-6 builds on it)
- Output: new-ideas-cycle6.md
