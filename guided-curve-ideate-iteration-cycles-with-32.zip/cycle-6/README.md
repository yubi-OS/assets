# Iteration cycle 6 snapshot — MEASURED, L15 + L16 + L17

**Skill:** guided-curve-ideate
**Cycle:** 6 of 6 (final, measured)
**Catalog:** constraints-catalog-2026-08-09-cycle6.md
**Output:** new-ideas-cycle6.md
**Measurement backend:** `empirical_gate_cycle6.py` (cycle-6 driver) over `empirical_gate.py` (cycle-4 adapter) over `papers/scripts/fit-full-curve-map.py`

## What's new vs cycle 5

Cycle 5 found:
- **W18 pure-3fold weighting** → PC1+PC2 = 0.8080 (best ever, +0.1443 over baseline)
- **Möbius is decoupled from PC1+PC2** (cycle-4 finding, cycle-5 confirms)

Cycle 6 builds on these with three new lenses:
- **L15 — Pareto-optimal combined**: W18 × D-sweep (128/192/256/384) × Möbius (frozen/sub-2/full-PSL). **All 16 candidates measure 0.8080.** Pareto optimum: **L15-W18-D128-frozen** at PC1+PC2 = 0.8080 and total_ops = **3.69×10⁴** (lowest cost ever for a top candidate).
- **L16 — Cross-corpus replication**: re-run W18 / W19 / uniform on docs/ (21 files) and refs/ (113 files). **W19 wins on docs/ (0.8538) and refs/ (0.7507)** — best weighting is corpus-dependent.
- **L17 — Beyond-9-D feature spaces**: W18 on the 9-D portion recovers 0.8080 under synthetic 24-D extension. W18 isolates the 9-D signal even when the feature space is widened.

## Headline finding

| Lens | Best PC1+PC2 | Δ over baseline |
|---|---:|---:|
| Cycle-4 best (mixed-radix 3+4) | 0.6901 | +0.0264 |
| Cycle-5 best (W18 pure-3fold) | 0.8080 | +0.1443 |
| **Cycle-6 best (W18 at D=128, frozen)** | **0.8080** | **+0.1443** |
| **Cycle-6 best on docs/** (W19) | **0.8538** | **+0.1701** |

**The Pareto optimum is L15-W18-D128-frozen**: same gate (0.8080) as cycle-5's W18-at-D=384, but at **11% the parameter count (P=16,512 vs 147,840)** and **half the cost (3.69×10⁴ vs ~6.6×10⁴ ops)**.

## What's in this snapshot

- README.md (this file)
- SKILL.md (skill definition, with cycle-6 lenses L15 + L16 + L17)
- empirical_gate_cycle6.py — cycle-6 driver (L15 + L16 + L17)
- empirical_gate_results_cycle6.json — measured values for all 28 candidates
- constraints-catalog-2026-08-09-cycle6.md (cycle-6 axes)
- new-ideas-cycle6.md (ref doc)
- new-ideas-cycle6.json (machine-readable)
- missing-from-cycle5.md (gap doc from cycle-6 generation)

LOCAL ONLY — no commits, no GitHub pushes, no Linear activity.

## Cycle progression

| Cycle | Frontier | Best measured PC1+PC2 | Best cost (total ops) |
|---|---|---:|---:|
| 1 | baseline 6 lenses | (qualitative) | — |
| 2 | novelty re-scored | (qualitative) | — |
| 3 | D-sweep post-hoc | (qualitative) | — |
| 4 | empirical_gate wired, mixed-radix 3+4 | 0.6901 | — |
| 5 | L13 column-weight sweep | 0.8080 | 4.10×10⁴ (subgroup-2 D=128) |
| **6** | **L15 Pareto combined + L16 cross-corpus + L17 beyond-9-D** | **0.8538 (docs) / 0.8080 (skills)** | **3.69×10⁴ (W18 D=128 frozen)** |

## What cycle-6 settled

1. **W18 holds at 0.8080 across all D and all Möbius combinations** (16/16 L15 candidates PASS at 0.8080). The gate is invariant under D and Möbius once W18 is applied.
2. **W19 is corpus-specific** — best on docs/ (0.8538) and refs/ (0.7507), second-best on skills/ (0.7854). The cycle-5 single-best-weighting assumption is broken.
3. **W18 isolates the 9-D signal under synthetic 24-D extension** (L17 confirms). The cycle-5 finding transfers beyond 9-D feature spaces.
4. **The Pareto optimum is L15-W18-D128-frozen** — same gate (0.8080) at 11% the parameter count and half the cost of cycle-5's W18-at-D=384.

## What's still open (cycle-7 candidates)

- **Real 24-D replication**: cycle-6 used synthetic 24-D. Test W18-on-9D against the main paper's actual 24-D construction.
- **Möbius-cost on docs/refs**: L14 was skills-only. Cross-corpus cost ranking is an open question.
- **Per-cycle Möbius re-fit stability**: cycle-5 L14 used a cost proxy; cycle-7 should measure wall-clock fit time on each corpus.
- **Corpus-adaptive weighting**: a held-out PC1+PC2 selector could pick the best weighting per corpus automatically.

## Audit trail

- Generated 2026-08-09T22:10:00 via guided-curve-ideate (cycle-6, measured)
- Source skill: session/guided-curve-ideate/SKILL.md
- Implementation: empirical_gate_cycle6.py (cycle-6 driver)
- Measurement: empirical_gate.py (cycle-4 adapter) over papers/scripts/fit-full-curve-map.py
- Corpora: 79 skills + 21 docs + 113 refs
- Input: /var/workspace/session/zip_digest/cycle-6/constraints-catalog-2026-08-09-cycle6.md
- Output: /var/workspace/session/zip_digest/cycle-6/new-ideas-cycle6.md
- LOCAL ONLY — not committed to any repo
