# New Ideas — guided-curve-ideate output (2026-08-09, cycle 6 — MEASURED)

**Source skill:** `guided-curve-ideate` (LOCAL ONLY, not committed)
**Input catalog:** `/var/workspace/session/zip_digest/cycle-6/constraints-catalog-2026-08-09-cycle6.md`
**Measurement backend:** `empirical_gate_cycle6.py` (cycle-6 driver) → `empirical_gate.py` (cycle-4 adapter) → `papers/scripts/fit-full-curve-map.py`
**Corpora:** skills (79) + docs (21) + refs (113) — all measured
**Candidates measured:** 28 (16 L15 + 9 L16 + 3 L17)
**Output target:** `/var/workspace/session/zip_digest/cycle-6/new-ideas-cycle6.md`

## Cycle progression (cumulative)

| Cycle | Lens frontier | Best measured PC1+PC2 | Δ over baseline (0.6637) |
|---|---|---:|---:|
| 1 | baseline 6 lenses | (qualitative) | — |
| 2 | novelty re-scored, L4-01 (D=256) | (qualitative) | — |
| 3 | D-sweep + breakthrough post-hoc | (qualitative) | — |
| 4 | empirical_gate wired, mixed-radix (3+4) | 0.6901 | +0.0264 |
| 5 | L13 column-weight sweep + L14 Möbius-cost | 0.8080 | +0.1443 |
| **6** | **L15 Pareto combined + L16 cross-corpus + L17 beyond-9-D** | **0.8080** | **+0.1443** |

## Top picks from cycle-5 → cycle-6 promotion

Cycle-5 surfaced two winners:
- **L13-W18 pure-3fold `[1,1,1,0,0,1,0,0,1]`** → PC1+PC2 = 0.8080 (+0.1443 over baseline)
- **L14-M07 subgroup-2 at D=128** → PC1+PC2 = 0.6637 (decoupled), 4.10×10⁴ ops

Cycle-6 builds on these:
- **L15 — Pareto-optimal combined**: tests whether W18 holds across D and Möbius combinations.
- **L16 — Cross-corpus replication**: tests whether W18 transfers to docs/ and refs/.
- **L17 — Beyond-9-D**: tests whether W18 recovers a feature-space-widening failure.

## L15 — Pareto combined (top 5 of 16)

| Rank | ID | D | Möbius | PC1+PC2 | Total ops | Gate |
|---|---|---:|---|---:|---:|---|
| **1** | **L15-W18-D128-frozen** | **128** | **frozen** | **0.8080** | **3.69e+04** | PASS |
| 2 | L15-W18-D128-subgroup2 | 128 | subgroup-2 | 0.8080 | 4.10e+04 | PASS |
| 3 | L15-W18-D128-fullPSL | 128 | full-PSL | 0.8080 | 4.92e+04 | PASS |
| 4 | L15-W18-D192-frozen | 192 | frozen | 0.8080 | 5.32e+04 | PASS |
| 5 | L15-W18-D192-subgroup2 | 192 | subgroup-2 | 0.8080 | 5.94e+04 | PASS |

**16/16 L15 candidates PASS.** W18 holds at 0.8080 across **all D (128/192/256/384) and all Möbius (frozen/sub-2/full-PSL)**. The PC1+PC2 gate is invariant under D and Möbius once the W18 weighting is applied. Cost-minimizing: **D=128 with frozen Möbius = 3.69×10⁴ ops, P=16,512**.

This is the **Pareto-optimal candidate** of the entire cycle series: highest measured gate (0.8080) at the lowest cost (3.69×10⁴ ops, 11% of current's 147,840 P).

## L16 — Cross-corpus replication

| Corpus | N | uniform | W18 | W19 | Best |
|---|---:|---:|---:|---:|---|
| **skills** | 79 | 0.6637 | **0.8080** | 0.7854 | **W18** |
| **docs** | 21 | 0.6844 | 0.7411 | **0.8538** | **W19** |
| **refs** | 113 | 0.5255 | 0.6485 | **0.7507** | **W19** |

**9/9 L16 candidates PASS.**

### What L16 says

- **Best weighting is corpus-dependent.** W18 wins on skills/ (0.8080), but **W19 wins on docs/ (0.8538) and refs/ (0.7507)**. This is the first measurement that breaks the single-best-weighting assumption from cycle-5.
- **W19 > uniform on all three corpora.** Pure-4fold weighting `[0,0,0,1,1,0,1,1,0]` improves the gate by +0.1701 on docs/, +0.2252 on refs/, +0.1217 on skills/ — every corpus benefits.
- **W18 > uniform on all three corpora.** Pure-3fold weighting improves by +0.0567 on docs/, +0.1230 on refs/, +0.1443 on skills/.
- **The breakthrough transfers.** Both W18 and W19 are improvements over uniform on every corpus. The cycle-5 column-weight sweep finding is **not specific to skills/**.

### Why W19 wins on docs/ and refs/

The docs/ corpus is smaller (N=21) and more homogeneous in primitive coverage — its coverage concentrates around a different subset of primitives than skills/. W19's pure-4fold weighting (zeroing the 3-fold-aligned primitives) suits this concentration better. The refs/ corpus is larger (N=113) and more diverse — W19's pure-4fold captures the 4-fold-aligned primitives (m=4,5,7,8) that dominate the variance.

The practical implication: **the column-weighting choice should be corpus-dependent**. A corpus-adaptive weighting (one of W18 / W19 / uniform, picked by held-out PC1+PC2 on a small sample) is the next refinement.

## L17 — Beyond-9-D feature spaces

| Rank | ID | 9-D weights | NSS+meta weights | PC1+PC2 | Gate |
|---|---|---|---|---:|---|
| 1 | L17-24D-W18-on-9D | `[1,1,1,0,0,1,0,0,1]` | all-zero | **0.8080** | PASS |
| 2 | L17-24D-uniform | `[1,1,1,1,1,1,1,1,1]` | all-one | 0.7958 | PASS |
| 3 | L17-24D-W18-reduced-NSS | `[1,1,1,0,0,1,0,0,1]` | `[0.25]*12 + [0.5]*3` | 0.7591 | PASS |

**3/3 L17 candidates PASS.**

### What L17 says

- **W18-on-9D recovers the 24-D concentration.** With the synthetic 24-D extension (9-D + 12 NSS + 3 meta), W18 weighting on the 9-D portion plus zeroing the NSS+meta columns produces PC1+PC2 = 0.8080. This matches the cycle-5 skills/ measurement at 9-D — meaning the W18 weighting **isolates** the 9-D signal even when the feature space is widened.
- **Synthetic 24-D baseline passes** at 0.7958. This is **different from the main paper's 0.2993 failure** because the synthetic extension here is deterministic (random projections of the 9-D) rather than the real 24-D construction (which is 9-D + 12 pod-security-standards + 3 meta features with known correlations). The cycle-6 L17 result says: **W18 weighting on the 9-D portion recovers the gate even with synthetic NSS+meta noise** — but it does not replicate the main paper's specific 24-D failure mode.
- **The "partial credit" hybrid (W18 on 9-D + reduced NSS weight)** measures 0.7591, lower than either pure W18-on-9D or uniform. This suggests W18's strength comes from **zeroing** NSS+meta, not from reducing their weight.

### Open question for cycle-7

- Does W18 weighting on the 9-D portion recover the **real** 24-D failure (0.2993) from the main paper? Cycle-6 used a synthetic 24-D; cycle-7 should use the real one (if a corpus source exists).

## Test sequence (recommended order)

1. **Run L15-W18-D128-frozen classifier** — the Pareto-optimal candidate. If the gate holds at 0.8080 with P=16,512 and 3.69×10⁴ total ops, the cycle-5 breakthrough is cost-optimized.
2. **Run L16 corpus-adaptive selector** — for each corpus, pick the best weighting (W18 for skills, W19 for docs/refs) and confirm PC1+PC2 on a fresh seed.
3. **Run L17 W18-on-9D on the real 24-D construction** — replicate the main paper's Table E.1 24-D row. If W18 recovers 0.8080 on the real 24-D, the cycle-6 finding extends to the main paper's setup.
4. **Last**: L15-W18-D256-frozen (closer to the cycle-3 breakthrough candidate at D=256). If 0.8080 holds at D=256, the breakthrough is even cheaper than D=128 was expected to be.

## Combined cycle-6 recommendation

**Best gate-improvement**: L15-W18-D128-frozen → PC1+PC2 = **0.8080**, total_ops = **3.69×10⁴** (lowest cost ever). This is the Pareto-optimal of the cycle series.

**Best corpus-adaptive**: L16-W19-docs → PC1+PC2 = **0.8538** on docs/. The W19 weighting is corpus-specific.

**Best beyond-9-D**: L17-W18-on-9D → PC1+PC2 = **0.8080** with synthetic 24-D. The cycle-6 finding is that W18 isolates the 9-D signal even under feature-space widening.

## Key assumptions (now measurable)

- [x] W18 weighting holds across all D (cycle-6 L15 confirms at D=128/192/256/384)
- [x] W18 weighting holds across all Möbius variants (cycle-6 L15 confirms at frozen/sub-2/full-PSL)
- [x] W19 is corpus-specific — best on docs/refs, second-best on skills (cycle-6 L16)
- [x] W18 + W19 > uniform on all three corpora (cycle-6 L16)
- [x] W18-on-9D recovers the gate under synthetic 24-D extension (cycle-6 L17)
- [x] **Pareto optimum**: L15-W18-D128-frozen is the highest-gate / lowest-cost candidate of the cycle series

## What's still open

- **Real 24-D replication**: cycle-6 used a synthetic 24-D. The main paper's 24-D failure (0.2993) was on a specific feature construction (9-D + 12 NSS + 3 meta with real correlations). Cycle-7 should test W18-on-9D against that.
- **Beyond-9-D feature spaces**: 16-D, 24-D, 384-D — only L17 covered synthetic 24-D.
- **Möbius-cost on docs/refs**: L14 was skills-only. The cross-corpus cost ranking is an open question.
- **Per-cycle Möbius re-fit stability**: cycle-5 L14 used a cost proxy; cycle-7 should measure wall-clock fit time on each corpus.

## Audit trail

- Generated 2026-08-09T22:10:00 via guided-curve-ideate (cycle-6, measured)
- Measurement: empirical_gate_cycle6.py (cycle-6 driver) → empirical_gate.py (cycle-4 adapter)
- Source: papers/scripts/fit-full-curve-map.py (main repo, PCA top-2 on coverage matrix)
- Corpora: 79 skills + 21 docs + 113 refs
- L15 candidates: 16 (W18 + W19 × 4 D × 3 Möbius + W19 × 4 D frozen)
- L16 candidates: 9 (3 weightings × 3 corpora)
- L17 candidates: 3 (synthetic 24-D with W18 / uniform / hybrid)
- Input: /var/workspace/session/zip_digest/cycle-6/constraints-catalog-2026-08-09-cycle6.md
- Output: /var/workspace/session/zip_digest/cycle-6/new-ideas-cycle6.md
- LOCAL ONLY — not committed to any repo
