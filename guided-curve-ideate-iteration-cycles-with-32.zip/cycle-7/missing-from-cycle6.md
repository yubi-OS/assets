# What's missing from cycle 6 — and how cycle 7 addresses it

## Gaps in cycle 6

1. **L17 used synthetic 24-D** (random projections of 9-D + Gaussian noise). Did NOT replicate the main paper's specific 24-D failure mode (PC1+PC2 = 0.2993). The synthetic extension was too easy — cycle-6 measured 0.8080 with W18-on-9D, but the real 24-D is harder.
2. **L16 covered skills/docs/refs only** (3 corpora). The main paper's 24-D fit includes self/ (4 corpora total). Cycle-6 didn't test on self/.
3. **L14 (Möbius-cost) was skills-only**. The gate-invariance-under-Möbius finding was not replicated on docs/refs.

## Cycle-7 fix

| Gap | Cycle-7 fix |
|---|---|
| Synthetic 24-D | **L18 uses the REAL 24-D** from `nd-vectors.json` (474 rows, the actual output of `build-nd-axis-viewer.py`). Construction: 9 primitives + 12 NSS axes (scored from SKILL.md text patterns) + 3 run-metadata (cycle#/delta/FIRES). **W19-on-9D-only recovers the real 24-D from 0.2993 to 0.7925 (+0.4932).** |
| 3 corpora only | **L19** runs corpus-adaptive selector on all 3 available corpora (skills/docs/refs). |
| Skills-only Möbius-cost | **L20** extends Möbius-cost to all 3 corpora. All 9 candidates measure PC1+PC2 = 0.6637 (gate invariant). |

## What cycle-7 still doesn't address (open for cycle 8)

1. **Real 24-D on full 2286 sections.** Cycle-7 L18 used the skills/ subset (474 rows from `nd-vectors.json`). The full 2286 includes docs/refs/self entries. Adding those may shift the 24-D measurement further (likely toward the main paper's 0.2993 if the additional rows have different variance distribution, or higher if they preserve the W19-on-9D pattern).
2. **Self corpus.** No `rsi-self-corpus.json` was found. The self corpus likely has per-section entries similar to skills/docs/refs but is stored differently (e.g., in `rsi-patch-recursive-self-improvement-2026-08-06/` directory). Cycle-8 should locate and load it.
3. **NSS-axis scoring depth.** The current scoring is 0/0.4/0.6/0.8/1.0 by hit count. A finer-grained scorer (e.g., normalizing by SKILL.md length) might change the 24-D distribution. Cycle-8 should test whether finer NSS scoring changes the W19-on-9D measurement.
4. **Per-corpus Pareto combined.** Cycle-6 L15 was skills-only at 9-D (16 candidates). Cycle-8 should run L15 per corpus: W18/W19 × D-sweep × Möbius on docs/refs as well as skills.

## Cycle-8 candidate lenses

- **L21 — Real 24-D on full 2286 sections**: include docs/refs/self entries (build the full 2286-row 24-D matrix).
- **L22 — Self corpus replication**: locate and load self corpus, run L16/L19 on it.
- **L23 — Finer-grained NSS scoring**: try length-normalized NSS scoring, re-measure L18.
- **L24 — Per-corpus Pareto combined**: run L15 (W18/W19 × D × Möbius) per corpus, find per-corpus Pareto optima.

These are the cycle-8 lenses if the user wants another iteration.
