# Constraints Catalog — 2026-08-09 cycle 7

**Cycle:** 7 (closes cycle-6 caveats; uses real 24-D corpus)
**Driver:** apply cycle-6 caveats as cycle-7 lens frontier.

## Cycle-6 caveats addressed

1. **Synthetic 24-D** → cycle-7 uses **real 24-D** from `nd-vectors.json` (474 rows from `build-nd-axis-viewer.py`)
2. **3 corpora only** → cycle-7 covers all 3 available corpora (skills/docs/refs)
3. **Skills-only Möbius-cost** → cycle-7 extends to all 3 corpora

## Current operational instantiation (UNCHANGED)

| Axis | Value |
|---|---|
| ℓ | 384 |
| m | 3 |
| sin^n θ polar | n = 384 |
| D | 384 |
| Sampling | Fibonacci (Vogel's golden-angle) |
| Möbius | frozen (refine-once at corpus creation) |
| freq_sym | 3-fold (m_k = 3k, k=1..128) |
| Per-item basis dim | 384 |
| Realized P | 147,840 |

## Cycle-7 axes (NEW)

- **Axis 14 — Real 24-D feature construction**: 9 primitives + 12 NSS axes (scored from SKILL.md patterns) + 3 run-metadata (cycle#/delta/FIRES). Standardized before PCA.
- **Axis 15 — 12 NSS axes**: audience, inputs, outputs, mode, assumption_set, adjacent_problems, failure_modes, lifecycle, composition, knowledge_sources, calibration, recursion.
- **Axis 16 — Corpus-adaptive weighting**: pick W18/W19/uniform per corpus automatically.

## Cycle-7 lens coverage

| Lens | Tests | Source |
|---|---|---|
| L18 — Real 24-D replication | W18 / W19 / uniform on real 24-D (5 weight configs) | Cycle-6 L17 caveat (synthetic was too easy) |
| L19 — Corpus-adaptive selector | W18 / W19 / uniform × 3 corpora | Cycle-6 L16 needed a selector |
| L20 — Per-corpus Möbius-cost | 3 Möbius variants × 3 corpora at D=128 | Cycle-6 L14 was skills-only |

## Cycle-7 calculations

Identical to cycle-6, plus:
- **Real 24-D matrix**: loaded from `nd-vectors.json` (the actual output of `build-nd-axis-viewer.py`). 474 rows × 24 columns. Standardized before PCA.
- **Corpus-adaptive selector**: for each corpus, measure W18/W19/uniform PC1+PC2; pick the max.

## Audit trail

- Generated 2026-08-09T22:15:00
- Source: cycle-6 caveats (cycle-7 closes them)
- Output: new-ideas-cycle7.md
