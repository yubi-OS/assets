# Iteration cycle 7 snapshot — MEASURED, real 24-D

**Skill:** guided-curve-ideate
**Cycle:** 7 of 7 (final, measured, real 24-D)
**Catalog:** constraints-catalog-2026-08-09-cycle7.md
**Output:** new-ideas-cycle7.md
**Measurement backend:** `empirical_gate_cycle7.py` (cycle-7 driver) over `empirical_gate.py` (cycle-4 adapter)
**Real 24-D source:** `papers/data/nd-viewer-output/nd-vectors.json` (the actual output of `build-nd-axis-viewer.py`)

## What's new vs cycle 6

Cycle 6 had three caveats that cycle 7 closes:

| Cycle-6 caveat | Cycle-7 fix |
|---|---|
| **L17 used synthetic 24-D** (random projections of 9-D + Gaussian noise) — did NOT replicate the main paper's specific 24-D failure mode (0.2993) | **L18 uses the real 24-D** from `nd-vectors.json`. Construction: 9 primitives + 12 NSS axes (scored from SKILL.md patterns) + 3 run-metadata (cycle#/delta/FIRES). |
| L16 covered skills/docs/refs only (3 corpora) | **L19** adds corpus-adaptive weighting selector |
| L14 (Möbius-cost) was skills-only | **L20** extends to docs/refs |

## Headline finding

**W19-on-9D-only recovers the real 24-D from PC1+PC2 = 0.2993 (FAIL) to 0.7925 (PASS), a +0.4932 improvement.** The cycle-6 L17 caveat is closed.

| Lens | Best PC1+PC2 | Δ over main paper baseline (0.2993) |
|---|---:|---:|
| **L18 — W19-on-9D-only on real 24-D** | **0.7925** | **+0.4932** |
| L18 — W18-on-9D-only on real 24-D | 0.6840 | +0.3847 |
| L18 — uniform-24D on real 24-D | 0.4754 | +0.1761 |
| L19 — W19-docs (corpus-adaptive best) | 0.8538 | n/a (9-D corpus) |

## What's in this snapshot

- README.md (this file)
- SKILL.md (skill definition, with cycle-7 lenses L18 + L19 + L20)
- empirical_gate_cycle7.py — cycle-7 driver
- empirical_gate_results_cycle7.json — measured values for all 23 candidates
- constraints-catalog-2026-08-09-cycle7.md (cycle-7 axes)
- new-ideas-cycle7.md (ref doc)
- new-ideas-cycle7.json (machine-readable)
- missing-from-cycle6.md (gap doc from cycle-7 generation)

LOCAL ONLY — no commits, no GitHub pushes, no Linear activity.

## Cycle progression

| Cycle | Frontier | Best measured PC1+PC2 |
|---|---|---:|
| 1–3 | qualitative baseline | — |
| 4 | empirical_gate + mixed-radix (3+4) | 0.6901 |
| 5 | L13 column-weight sweep | 0.8080 |
| 6 | L15 Pareto combined + L16 cross-corpus + L17 **synthetic** 24-D | 0.8080 |
| **7** | **L18 real 24-D + L19 corpus-adaptive + L20 per-corpus Möbius-cost** | **0.8538 (docs) / 0.7925 (real 24-D)** |

## What cycle-7 settled

1. **W19-on-9D recovers the real 24-D from 0.2993 to 0.7925** (+0.4932). The cycle-6 L17 caveat (synthetic 24-D) is closed.
2. **W19 > W18 on the 24-D feature space.** On 9-D corpus projection, W18 wins on skills/ and W19 wins on docs/refs. On the 24-D feature space, W19 wins outright.
3. **Corpus-adaptive selector works**: pick W18/W19/uniform per corpus automatically. Best per-corpus PC1+PC2 = 0.8538 on docs/.
4. **Gate is invariant under Möbius DOF across all 3 corpora** (cycle-7 L20 confirms cycle-4/5 finding).

## What's still open (cycle-8 candidates)

- **Real 24-D on full 2286 sections** (cycle-7 used the 474-row skills/ subset)
- **Self corpus**: not yet loaded
- **NSS-axis scoring depth**: the current 0/0.4/0.6/0.8/1.0 scorer might be too coarse
- **Per-corpus Pareto combined**: cycle-6 L15 was skills-only; cycle-8 should test per corpus

## Audit trail

- Generated 2026-08-09T22:15:00 via guided-curve-ideate (cycle-7, measured)
- Source skill: session/guided-curve-ideate/SKILL.md
- Implementation: empirical_gate_cycle7.py (cycle-7 driver)
- Real 24-D source: papers/data/nd-viewer-output/nd-vectors.json (474 rows, the actual output of build-nd-axis-viewer.py)
- Corpora: 79 skills + 21 docs + 113 refs
- Input: /var/workspace/session/zip_digest/cycle-7/constraints-catalog-2026-08-09-cycle7.md
- Output: /var/workspace/session/zip_digest/cycle-7/new-ideas-cycle7.md
- LOCAL ONLY — not committed to any repo
