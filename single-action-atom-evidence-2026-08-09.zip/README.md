# Single-Action Atom Evidence Bundle — 2026-08-09

This bundle is the cryptographic and procedural proof of the single-action atom insight from session `ses_02311d1deffe3OSD1UVOduG3ej` (2026-08-07).

## What this proves

1. **The .ods file (`Untitled-1-37a4939f.ods`) is the input.** SHA-256: `36b85eb0da92c9d865a2550026b54d030ba06f431d3e37a45ffa3e7d920f55b3`.
2. **The three-regime decomposition (eligible/deferred/refused) holds for the worked example.** Counts: 13 eligible + 17 deferred + 4 refused = 34 content rows.
3. **The Merkle root commits to all six session artifacts.** Root: `3e32eef859a758db124e91aa04724f1bbc0481ef9968e600d7fcafb8f1d7ff4e`.
4. **The analysis is reproducible from the bytes alone.** No prior trust required.

## How to verify

Run:

```bash
bash VERIFY.sh
```

This performs three independent verifications:

1. **SHA-256 of every file** in the bundle is computed and listed.
2. **The Merkle root is recomputed** from the six leaves (the `.ods` file, the paper TeX, four canonical text strings) and compared to the expected root.
3. **The regime classification is reproduced independently** by parsing the `.ods` file with the single-action-atom-skill classifier and comparing to the published enumeration.

Expected output: "ALL VERIFICATIONS PASSED" at the end.

## Contents

```
.
├── README.md                                   # This file
├── MANIFEST.json                               # File list with SHA-256
├── EXTERNAL_REFS.md                            # Public references (GitHub, Linear, etc.)
├── VERIFY.sh                                   # One-shot verification script
├── chat-export-2026-08-07.md                   # The chat history (9 turns)
├── merkle-tree-2026-08-07.json                 # The Merkle-tree manifest
├── single-action-atom-merkle-2026-08-07.md     # The refs/ doc published to yubiOS
├── per-row-enumeration-2026-08-07.md          # NEW: full per-row walkthrough
├── paper-section-worked-example.tex            # NEW: LaTeX addendum for the paper
├── 8-6.tex                                     # The paper TeX source
├── data/
│   ├── Untitled-1-37a4939f.ods                 # The worked-example spreadsheet
│   └── image-1a055d0f.png                      # Screenshot of Set A's ratios
├── scripts/
│   ├── verify_merkle.py                        # Reproduce Merkle root
│   └── reproduce_regimes.py                    # Independent regime reproduction
└── skills/
    └── single-action-atom-skill/
        ├── SKILL.md                            # The skill definition
        └── scripts/
            └── classify_regimes.py              # The classifier implementation
```

## Public reference trail

This bundle ties back to the following public artifacts:

| System | Reference |
|--------|-----------|
| GitHub `yubi-OS/yubiOS` | commit `3bfef1dfb0e3eb00f8d87d3d162b668cfd4882cc` (refs doc + manifest) |
| GitHub `yubi-OS/agent-skills` | commit `90982e3941e85c3378dc7008a1b472f93b9de02e` (mirror) |
| Linear OMN-163 | comment `1f2a93f4-cfd7-4538-b5c2-8e5a63eb005c` |
| `SELF-CHANGELOG.md` v0.28 | append-only thread, dated 2026-08-07 |

See `EXTERNAL_REFS.md` for full URLs and verification instructions.

## The single-action atom insight

The 40-row spreadsheet parameterizes the single-action atom from `learned-latent-curves-2026-08-06.tex` §4 along three axes:

- **Block 1** (rows 1-10): basis-element coefficient view of `eq:flat`. $a, b$ are $(a_{j,m}, b_{j,m})$; $n = f_m$ is the frequency.
- **Block 2** (rows 14-23): corpus-application view of `eq:composition`. $a$ is corpus weight, $b$ is per-primitive weight, $a \cdot b$ is $\Delta_{f_i}$.
- **Block 3** (rows 27-32): single-action atom under the geodesic-only criterion. $n = 4$ is the cycle index, $b = 1/8$ is the per-primitive weight.

The three regimes:
- **Atom-eligible** (13 rows): $b/a$ is in the standard primitive ladder. Atom acts; $\Delta_{f_i} > 0$.
- **Atom-deferred** (17 rows): $b/a$ is defined but outside the ladder. Atom defers; Möbius refinement (Section 3.4) re-fits $\phi_\theta$ when corpus growth > 25%.
- **Atom-refused** (4 rows): $b/a$ is undefined (a=0). Atom refuses per Lemma 1.

The composition rule `eq:composition` ($\Delta_{\mathrm{corpus}} = \sum_i \Delta_{f_i}$) holds across all three regimes: eligible contribute positive deltas, deferred contribute zero in the current cycle, refused contribute undefined (vacuously zero). Total: $\Delta_{\mathrm{corpus}} = \sum_{13} \Delta_{f_i}$, non-negative. Consistent with the 474-dispatch atom experiment on the 79-skill corpus (Section §4).

## Why a Merkle tree?

The Merkle root commits to the six artifacts as one corpus of evidence. Anyone with the bundle can:

1. Hash each file independently (verify the bytes).
2. Build the Merkle tree using the canonical pairing scheme.
3. Compare the computed root to the expected root.
4. Cross-reference the root against the three public references (GitHub commit message, Linear comment, SELF-CHANGELOG entry).

This is the structural separation of proof from prose: the proof is the bytes + their hashes; the prose is the analysis. The root is independently verifiable without re-reading the analysis.

## Files in this bundle

Every file is independently useful:

- **`README.md`** — overview and verification instructions.
- **`MANIFEST.json`** — file list with SHA-256, computed at bundle creation.
- **`EXTERNAL_REFS.md`** — public reference URLs.
- **`VERIFY.sh`** — one-shot reproduction script.
- **`chat-export-2026-08-07.md`** — the full chat history (9 turns, original analytical thread).
- **`merkle-tree-2026-08-07.json`** — the published Merkle manifest with leaf hashes.
- **`single-action-atom-merkle-2026-08-07.md`** — the refs/ doc published to `yubi-OS/yubiOS` on commit `3bfef1df`.
- **`per-row-enumeration-2026-08-07.md`** — the full per-row walkthrough (NEW in this bundle).
- **`paper-section-worked-example.tex`** — LaTeX addendum for the paper (NEW in this bundle).
- **`8-6.tex`** — the paper TeX source (`learned-latent-curves-2026-08-06.tex`).
- **`data/Untitled-1-37a4939f.ods`** — the worked-example spreadsheet.
- **`data/image-1a055d0f.png`** — screenshot of Set A's ratios from the chat.
- **`scripts/verify_merkle.py`** — recompute Merkle root from files.
- **`scripts/reproduce_regimes.py`** — independent regime reproduction.
- **`skills/single-action-atom-skill/SKILL.md`** — the skill definition.
- **`skills/single-action-atom-skill/scripts/classify_regimes.py`** — the classifier.

## Last updated

2026-08-09 12:32 PT (built in session `ses_02311d1deffe3OSD1UVOduG3ej` continuation).
