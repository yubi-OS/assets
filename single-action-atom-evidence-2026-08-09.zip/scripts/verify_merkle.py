#!/usr/bin/env python3
"""
verify_merkle.py — Merkle tree root reproduction.

Recomputes the SHA-256 Merkle root over a set of artifact files and
compares to an expected root. Pairs files in order; if odd count,
duplicates the last file (canonical Merkle scheme).

Usage:
    python3 verify_merkle.py --manifest merkle-tree-2026-08-07.json [--dir path/to/files/]

The manifest is the JSON at merkle-tree-2026-08-07.json. The script
loads `leaves` from the manifest, hashes each file, builds the tree,
and compares the computed root to the manifest's `root` field.

For files not in the manifest, you can pass them positionally:
    python3 verify_merkle.py file1.txt file2.txt file3.txt
"""
import argparse
import hashlib
import json
import os
import sys


def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(8192), b""):
            h.update(chunk)
    return h.hexdigest()


def merkle_root_from_files(file_paths):
    """Build a Merkle tree over the file contents (raw bytes)."""
    if not file_paths:
        raise ValueError("No files provided")
    level = [sha256_file(p) for p in file_paths]
    if len(level) % 2 == 1:
        level.append(level[-1])
    while len(level) > 1:
        next_level = []
        for i in range(0, len(level), 2):
            left = level[i]
            right = level[i + 1] if i + 1 < len(level) else level[i]
            combined = (left + right).encode("utf-8")
            next_level.append(hashlib.sha256(combined).hexdigest())
        level = next_level
    return level[0]


def merkle_root_from_strings(strings):
    """Build a Merkle tree over the given string contents."""
    if not strings:
        raise ValueError("No strings provided")
    level = [hashlib.sha256(s.encode("utf-8") if isinstance(s, str) else s).hexdigest() for s in strings]
    if len(level) % 2 == 1:
        level.append(level[-1])
    while len(level) > 1:
        next_level = []
        for i in range(0, len(level), 2):
            left = level[i]
            right = level[i + 1] if i + 1 < len(level) else level[i]
            combined = (left + right).encode("utf-8")
            next_level.append(hashlib.sha256(combined).hexdigest())
        level = next_level
    return level[0]


def main():
    parser = argparse.ArgumentParser(description="Recompute and verify a Merkle root.")
    parser.add_argument("--manifest", help="Path to a Merkle manifest JSON. Used to look up leaf names + expected root.")
    parser.add_argument("--dir", help="Directory containing the leaf files (when using --manifest).")
    parser.add_argument("files", nargs="*", help="Files to hash (when not using --manifest).")
    args = parser.parse_args()

    if args.manifest:
        with open(args.manifest) as f:
            manifest = json.load(f)
        if not args.dir:
            sys.exit("--dir is required when using --manifest")
        leaves = manifest.get("leaves", [])
        expected_root = manifest.get("root", "")
        file_paths = []
        print(f"Verifying {len(leaves)} leaves against manifest {args.manifest}:")
        print(f"  Expected root: {expected_root}")
        for leaf in leaves:
            name = leaf["name"]
            expected_hash = leaf["hash"]
            # Try common locations for each file
            candidates = [
                os.path.join(args.dir, name),
                os.path.join(args.dir, name + ".txt"),
                os.path.join(args.dir, name + ".md"),
                os.path.join(args.dir, "data", name),
                os.path.join(args.dir, name.replace("-", " ")),
                os.path.join(args.dir, "data", name.replace("-", " ")),
            ]
            found = None
            for c in candidates:
                if os.path.exists(c):
                    found = c
                    break
            if not found:
                sys.exit(f"Leaf file not found: {name} (tried: {candidates})")
            computed_hash = sha256_file(found)
            match = "MATCH" if computed_hash == expected_hash else "MISMATCH"
            print(f"  {match}: {name} ({found})")
            if computed_hash != expected_hash:
                print(f"    expected: {expected_hash}")
                print(f"    computed: {computed_hash}")
                sys.exit(1)
            file_paths.append(found)
        # Build the tree using the order from the manifest
        # The manifest's tree_structure shows the order, but simpler to use the
        # canonical pairing scheme (0-1, 2-3, ...) per the published manifest.
        computed_root = merkle_root_from_files(file_paths)
        print(f"\nComputed root: {computed_root}")
        print(f"Expected root: {expected_root}")
        if computed_root == expected_root:
            print("\nROOT VERIFICATION: PASS")
        else:
            print("\nROOT VERIFICATION: FAIL")
            sys.exit(1)
    elif args.files:
        computed_root = merkle_root_from_files(args.files)
        print(f"Computed Merkle root over {len(args.files)} files:")
        for f in args.files:
            print(f"  {sha256_file(f)} {f}")
        print(f"\nRoot: {computed_root}")
    else:
        parser.print_help()
        sys.exit(1)


if __name__ == "__main__":
    main()
