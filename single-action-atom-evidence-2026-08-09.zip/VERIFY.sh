#!/usr/bin/env bash
# VERIFY.sh — One-shot reproduction of all proof claims in this evidence bundle.
#
# Usage:
#   bash VERIFY.sh
#
# Exits 0 if all verifications pass, non-zero otherwise.
# Designed for a third-party auditor: no prior trust required.

set -e

EVIDENCE_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$EVIDENCE_DIR"

echo "============================================================"
echo "Evidence bundle verification: $(basename "$EVIDENCE_DIR")"
echo "============================================================"

echo ""
echo "--- 1. SHA-256 of every file in the bundle ---"
echo ""

# Compute SHA-256 of each file in the bundle (sorted, deterministic)
find . -type f \! -name "*.sha256" \! -path "./VERIFY.sh" \! -path "./MANIFEST.json" | sort | while read -r f; do
    h=$(sha256sum "$f" | cut -d' ' -f1)
    echo "  $h  $f"
done > /tmp/bundle-sha256.txt

cat /tmp/bundle-sha256.txt

echo ""
echo "--- 2. Merkle root reproduction ---"
echo ""

EXPECTED_ROOT="3e32eef859a758db124e91aa04724f1bbc0481ef9968e600d7fcafb8f1d7ff4e"

# Build the Merkle root from the leaf content strings (matching manifest leaves order)
# Leaves (in pairing order):
#   1. ods-untitled-1-37a4939f (file bytes)
#   2. tex-learned-latent-curves-2026-08-06 (file bytes)
#   3. insight-single-action-atom (text)
#   4. three-regimes-eligible-deferred-refused (text)
#   5. ratios-of-ratios-analysis (text)
#   6. whole-self-output-2026-08-07 (text)

# Compute file leaf hashes
LEAF1=$(sha256sum data/Untitled-1-37a4939f.ods | cut -d' ' -f1)
LEAF2=$(sha256sum 8-6.tex | cut -d' ' -f1)

echo "Leaf 1 (.ods file):       $LEAF1"
echo "Leaf 2 (paper TeX):       $LEAF2"

# Compute the text-leaf hashes by hashing the published text strings
# Note: the manifest's text-leaf hashes were computed from the EXACT text strings;
# we re-encode the same canonical strings here.
LEAF3=$(python3 -c "import hashlib; print(hashlib.sha256('The single-action atom is the one primitive the entire framework admits. The .ods spreadsheet is the algebraic unfolding of one atom dispatch per row. Every ratio in the spreadsheet is one candidate atom action. The three regimes (eligible/deferred/refused) correspond to: rows in the corpus ladder (atom acts, Delta_f >= 0); rows outside the ladder (atom defers until corpus grows; Mobius refinement re-fits phi_theta); rows where b/a is undefined (atom refuses: c=0 weighted aggregate, no pole, no geodesic gap, no action). The hyperspherical-harmonic curve on S^2 is the one geometry where all three regimes compose linearly: compact (no outside), bounded chordal distance (Delta_f well-defined), stereographic lift well-defined except at infinity.'.encode()).hexdigest())")

LEAF4=$(python3 -c "import hashlib; print(hashlib.sha256('Three regimes from the .ods analysis: ATOM-ELIGIBLE, ATOM-DEFERRED, ATOM-REFUSED. Each regime corresponds to a specific paper equation. The hyperspherical-harmonic variant on S^2 is the geometry that closes both failure modes.'.encode()).hexdigest())")

LEAF5=$(python3 -c "import hashlib; print(hashlib.sha256('Per-row enumeration of which ratios are outside the corpus ladder and which are undefined. The Block 1/2/3 structure parameterizes the same multiplicative structure along different axes. Cross-set comparisons show A:B=3 and A:C=3/2 for the first 5 rows.'.encode()).hexdigest())")

LEAF6=$(python3 -c "import hashlib; print(hashlib.sha256('Whole-self output: when the user already knows the destination, the agent job is to provide the structured path. The merkle tree is the structural artifact. The single-action atom is the primitive. S^2 closes both failure modes.'.encode()).hexdigest())")

echo "Leaf 3 (insight):        $LEAF3"
echo "Leaf 4 (regimes):        $LEAF4"
echo "Leaf 5 (ratios analysis): $LEAF5"
echo "Leaf 6 (whole-self):     $LEAF6"

# Build the tree (pairing: L1+L2, L3+L4, L5+L6; then (L1L2+L3L4) and (L5L6+L5L6); then root)
L1N0=$(python3 -c "import hashlib; print(hashlib.sha256(('$LEAF1' + '$LEAF2').encode()).hexdigest())")
L1N1=$(python3 -c "import hashlib; print(hashlib.sha256(('$LEAF3' + '$LEAF4').encode()).hexdigest())")
L1N2=$(python3 -c "import hashlib; print(hashlib.sha256(('$LEAF5' + '$LEAF6').encode()).hexdigest())")

L2N0=$(python3 -c "import hashlib; print(hashlib.sha256(('$L1N0' + '$L1N1').encode()).hexdigest())")
L2N1=$(python3 -c "import hashlib; print(hashlib.sha256(('$L1N2' + '$L1N2').encode()).hexdigest())")

ROOT=$(python3 -c "import hashlib; print(hashlib.sha256(('$L2N0' + '$L2N1').encode()).hexdigest())")

echo ""
echo "Computed Merkle root:   $ROOT"
echo "Expected Merkle root:   $EXPECTED_ROOT"

if [ "$ROOT" = "$EXPECTED_ROOT" ]; then
    echo "MERKLE ROOT VERIFICATION: PASS"
else
    echo "MERKLE ROOT VERIFICATION: FAIL"
    exit 1
fi

echo ""
echo "--- 3. Independent regime reproduction ---"
echo ""

python3 scripts/reproduce_regimes.py --evidence-dir "$EVIDENCE_DIR"

echo ""
echo "============================================================"
echo "ALL VERIFICATIONS PASSED"
echo "============================================================"
