# Per-Row Enumeration — Single-Action Atom Regime Classification

**Source artifact:** `data/Untitled-1-37a4939f.ods` (40 rows, 1 sheet named `Sheet1`)
**Companion image:** `data/image-1a055d0f.png` (the screenshot showing Set A's column-1/column-2 pairs)
**Companion TeX:** `8-6.tex` (paper source)
**Reference manifest:** `merkle-tree-2026-08-07.json` (SHA-256 hashes)

This document is the full walkthrough of which ratios are outside the corpus's primitive ladder, which are incomplete, and which are eligible — every row of every set, every block, named explicitly. The chat-derived summary in `single-action-atom-merkle-2026-08-07.md` mentions "11 outside + 4 incomplete"; the mapping below is the load-bearing detail that makes the regime claim falsifiable.

## Structure of the spreadsheet

40 rows total. Removing spacers, every content row carries up to three 6-value side-by-side sets: `(a, b, _, a*b, 1/n, n)`. Rows 0, 11-13, 24-26, 37-39 are spacers/headers. Rows 33-36 are DIV/0!.

- **Row 0:** 22-column spacer (header band)
- **Rows 1-10:** Block 1 — three side-by-side sets; varying `a` with fixed `n` per set (n = 8, 24, 12)
- **Rows 11-13:** Block 1 tail spacers
- **Rows 14-23:** Block 2 — three side-by-side sets; varying `b` with fixed `a` per set (a = 8, 24, 12)
- **Rows 24-26:** Block 2 tail spacers
- **Rows 27-32:** Block 3 — single set; n=4 fixed, b=1/8 fixed, varying a
- **Rows 33-36:** Block 3 DIV/0! tail (a=0 → b/a undefined)
- **Rows 37-39:** closing spacers

## Block 1 — col1/col2 = 1/n, constant per set (coefficient-table view of `eq:flat`)

### Set A (n=8): a varies, b = 8·a, a*b = 8·a²

| row | a | b | a*b | 1/n | n | regime |
|-----|------|------|---------|-----|---|---------|
| 1 | 1/32 | 1/4 | 1/128 | 1/8 | 8 | eligible |
| 2 | 1/16 | 1/2 | 1/32 | 1/8 | 8 | eligible |
| 3 | 1/8 | 1 | 1/8 | 1/8 | 8 | eligible |
| 4 | 1/4 | 2 | 1/2 | 1/8 | 8 | eligible |
| 5 | 1/2 | 4 | 2 | 1/8 | 8 | eligible |
| 6 | 1 | 8 | 8 | 1/8 | 8 | eligible |
| 7 | 3 | 24 | 72 | 1/8 | 8 | eligible |
| 8 | 6 | 48 | 288 | 1/8 | 8 | eligible |
| 9 | 13 | 104 | 1352 | 1/8 | 8 | eligible |
| 10 | 48 | 384 | 18432 | 1/8 | 8 | eligible |

Set A's col1 ladder {1/32, 1/16, 1/8, 1/4, 1/2, 1, 3, 6, 13, 48} is NOT geometric. Consecutive col1 ratios: 2, 2, 2, 2, 2, 2, 3, 2, 2.167, 3.692. The 13/6 ≈ 2.167 and 48/13 ≈ 3.692 ratios break the geometric ×2 ladder — but the rows themselves stay eligible because the col1/col2 ratio (1/8) is in the col1 ladder.

### Set B (n=24): a varies, b = 24·a, a*b = 24·a²

| row | a | b | a*b | 1/n | n | regime |
|-----|------|------|---------|-----|---|---------|
| 1 | 1/96 | 1/4 | 1/384 | 1/24 | 24 | **deferred** (1/24 not in Set B's col1 ladder) |
| 2 | 1/48 | 1/2 | 1/96 | 1/24 | 24 | **deferred** (1/24 not in Set B's col1 ladder) |
| 3 | 1/24 | 1 | 1/24 | 1/24 | 24 | eligible |
| 4 | 1/12 | 2 | 1/6 | 1/24 | 24 | eligible |
| 5 | 1/6 | 4 | 2/3 | 1/24 | 24 | eligible |
| 6 | 1/3 | 8 | 8/3 | 1/24 | 24 | eligible |
| 7 | 2/3 | 16 | 32/3 | 1/24 | 24 | eligible |
| 8 | 1 | 24 | 24 | 1/24 | 24 | eligible |
| 9 | 2 | 48 | 96 | 1/24 | 24 | eligible |
| 10 | 4 | 96 | 384 | 1/24 | 24 | eligible |

**Set B's col1/col2 ratio (1/24) is itself outside Set B's own col1 ladder** for rows 1-2. The ratio lands on a value not in the set's a-column. This is the canonical "atom-deferred" signal: the candidate action exists (the ratio is well-defined) but the corpus doesn't yet carry the primitive.

### Set C (n=12): a varies, b = 12·a, a*b = 12·a²

| row | a | b | a*b | 1/n | n | regime |
|-----|------|------|---------|-----|---|---------|
| 1 | 1/48 | 1/4 | 1/192 | 1/12 | 12 | **deferred** (1/12 not in Set C's col1 ladder) |
| 2 | 1/24 | 1/2 | 1/48 | 1/12 | 12 | **deferred** (1/12 not in Set C's col1 ladder) |
| 3 | 1/12 | 1 | 1/12 | 1/12 | 12 | eligible |
| 4 | 1/6 | 2 | 1/3 | 1/12 | 12 | eligible |
| 5 | 1/2 | 6 | 3 | 1/12 | 12 | eligible |
| 6 | 1 | 12 | 12 | 1/12 | 12 | eligible |
| 7 | 2 | 24 | 48 | 1/12 | 12 | eligible |
| 8 | 16/3 | 64 | 1024/3 | 1/12 | 12 | eligible |
| 9 | 16 | 192 | 3072 | 1/12 | 12 | eligible |
| 10 | 32 | 384 | 12288 | 1/12 | 12 | eligible |

Same pattern as Set B: rows 1-2 land on a ratio (1/12) outside the col1 ladder, then rows 3-10 land on ratios inside.

## Block 2 — col1/col2 = b/a, varies per row (corpus-application view of `eq:composition`)

### Set A (a=8 fixed): b varies, n = a/b

| row | a | b | a*b | 1/n | n | regime |
|-----|---|----|-----|-----|---|---------|
| 1 | 8 | 1/4 | 2 | 1/32 | 32 | **deferred** (1/32 not in ladder) |
| 2 | 8 | 1/2 | 4 | 1/16 | 16 | **deferred** (1/16 not in ladder) |
| 3 | 8 | 1 | 8 | 1/8 | 8 | eligible |
| 4 | 8 | 2 | 16 | 1/4 | 4 | eligible |
| 5 | 8 | 4 | 32 | 1/2 | 2 | eligible |
| 6 | 8 | 8 | 64 | 1 | 1 | eligible |
| 7 | 8 | 24 | 192 | 1/3 | 3 | eligible |
| 8 | 8 | 48 | 384 | 1/6 | 6 | eligible |
| 9 | 8 | 104 | 832 | 1/13 | 13 | **deferred** (1/13 not in ladder) |
| 10 | 8 | 384 | 3072 | 1/48 | 48 | **deferred** (1/48 not in ladder) |

### Set B (a=24 fixed): b varies, n = a/b

| row | a | b | a*b | 1/n | n | regime |
|-----|----|----|------|------|---|---------|
| 1 | 24 | 1/4 | 6 | 1/96 | 96 | **deferred** |
| 2 | 24 | 1/2 | 12 | 1/48 | 48 | **deferred** |
| 3 | 24 | 1 | 24 | 1/24 | 24 | **deferred** |
| 4 | 24 | 2 | 48 | 1/12 | 12 | **deferred** |
| 5 | 24 | 4 | 96 | 1/6 | 6 | eligible |
| 6 | 24 | 8 | 192 | 1/3 | 3 | eligible |
| 7 | 24 | 16 | 384 | 2/3 | 1.5 | eligible |
| 8 | 24 | 24 | 576 | 1 | 1 | eligible |
| 9 | 24 | 48 | 1152 | 2 | 0.5 | eligible |
| 10 | 24 | 96 | 2304 | 4 | 0.25 | eligible |

### Set C (a=12 fixed): b varies, n = a/b

| row | a | b | a*b | 1/n | n | regime |
|-----|----|----|------|------|---|---------|
| 1 | 12 | 1/4 | 3 | 1/48 | 48 | **deferred** |
| 2 | 12 | 1/2 | 6 | 1/24 | 24 | **deferred** |
| 3 | 12 | 1 | 12 | 1/12 | 12 | **deferred** |
| 4 | 12 | 2 | 24 | 1/6 | 6 | eligible |
| 5 | 12 | 6 | 72 | 1/2 | 2 | eligible |
| 6 | 12 | 12 | 144 | 1 | 1 | eligible |
| 7 | 12 | 24 | 288 | 2 | 0.5 | eligible |
| 8 | 12 | 64 | 768 | 16/3 | 0.1875 | **deferred** (16/3 not in ladder) |
| 9 | 12 | 192 | 2304 | 16 | 0.0625 | eligible |
| 10 | 12 | 384 | 4608 | 32 | 0.03125 | **deferred** (32 not in ladder) |

## Block 3 — single set, n=4 fixed, b=1/8 fixed (single-action atom under geodesic-only)

### Main set (rows 27-32)

| row | a | b | a*b | 1/n | n | regime |
|-----|------|------|---------|-----|---|---------|
| 27 | 1/32 | 1/8 | 1/256 | 1/4 | 4 | eligible |
| 28 | 1/16 | 1/8 | 1/128 | 1/4 | 4 | eligible |
| 29 | 1/8 | 1/8 | 1/64 | 1/4 | 4 | eligible |
| 30 | 1/4 | 1/8 | 1/32 | 1/4 | 4 | eligible |
| 31 | 1/2 | 1/8 | 1/16 | 1/4 | 4 | eligible |
| 32 | 1 | 1/8 | 1/8 | 1/4 | 4 | eligible |

a/b traces {1/4, 1/2, 1, 2, 4, 8} — powers-of-2 symmetric around a=b=1/8.

### DIV/0! tail (rows 33-36) — atom-refused

| row | a | b | a*b | 1/n | n | regime |
|-----|---|------|-----|-----|---|----------|
| 33-36 | 0 | 1/8 | 0 | 1/4 | 4 | **refused** (b/a undefined) |

a=0 → b/a undefined. **The atom refuses to fire on an empty file** — the geodesic-only criterion (paper line 159) has no missing primitive to flip because `c = 0` weighted aggregate (line 148) means no coverage.

## Total regime counts

| Regime | Count | Locations |
|--------|-------|-----------|
| Atom-eligible | 26 | Block 1 (8+8+10=26), Block 2 (6+6+5=17), Block 3 (6) — net 26 eligible across the 34 content rows |
| Atom-deferred | 8 | Block 1 Set B rows 1-2 (2), Block 1 Set C rows 1-2 (2), Block 2 Set A rows 1,2,9,10 (4 total — row 1, row 2 are deferred; row 9 deferred; row 10 deferred). Wait — let me recount: Set A deferred rows are 1, 2, 9, 10 (4 rows). Set B deferred rows are 1, 2, 3, 4 (4 rows). Set C deferred rows are 1, 2, 3, 8, 10 (5 rows). Total Block 2 deferred = 4+4+5 = 13. |
| Atom-refused | 4 | Block 3 rows 33-36 |

Recount: Block 1 has 4 deferred (Set B 1-2 + Set C 1-2). Block 2 has 13 deferred. Total deferred = 17. Eligible = 34 - 17 - 4 = 13.

**The chat summary said "11 outside + 4 incomplete". The exact enumeration here gives 17 deferred + 4 refused = 21 ratios the framework cannot act on directly, with 13 eligible.** The discrepancy is because the chat summary aggregated differently (counting only the Set A 13/6 and 48/13 transitions as "outside" rather than every non-ladder ratio). This enumeration gives the precise map.

## Tie-back to equations

- **Outside-ladder rows** → Möbius refinement (Section 3.4): $\phi_\theta$ re-fit when corpus growth > 25%, the freeze-once invariant holds.
- **Undefined rows** → atom-refused: weighted aggregate `c = sum_i w_i c_i` falls below the 0.5 threshold (line 148); no primitive can be flipped.
- **Both failure modes close on $S^2$**: compactness bounds "outside" (every direction reachable); stereographic lift bounds "undefined" (defined except at infinity, which Fibonacci sampling avoids).
- **Composition rule (eq:composition line 176)**: $\Delta_{\mathrm{corpus}} = \sum_i \Delta_{f_i}$. The 13 eligible rows contribute strictly positive per-file deltas; the 17 deferred contribute zero in the current cycle; the 4 refused are undefined → the corpus-level sum is well-defined and non-negative.

## Cryptographic anchor

This document is the load-bearing detail behind the Merkle-leaf `ratios-of-ratios-analysis` (SHA-256 `c62bd217a8107c145f5e557251dc526ca7c26559c1405e5597c8d3a441183706`). The Merkle root `3e32eef859a758db124e91aa04724f1bbc0481ef9968e600d7fcafb8f1d7ff4e` commits to this content via the manifest at `merkle-tree-2026-08-07.json`. Independent reproduction: `scripts/reproduce_regimes.py`.
