# External References — Single-Action Atom Insight

The single-action atom insight and the three-regime decomposition are anchored to the following public artifacts. Any auditor can verify the bundle against these references.

## GitHub

### `yubi-OS/yubiOS` — commit `3bfef1dfb0e3eb00f8d87d3d162b668cfd4882cc`

- **URL**: https://github.com/yubi-OS/yubiOS/commit/3bfef1dfb0e3eb00f8d87d3d162b668cfd4882cc
- **Commit message**: `refs: single-action atom primitive + merkle tree artifact (self-archaeology 2026-08-07)`
- **Files added**:
  - `refs/single-action-atom-merkle-2026-08-07.md` (5,357 B) — the refs/ doc
  - `refs/single-action-atom-merkle-2026-08-07.json` (4,166 B) — the Merkle manifest
- **Merkle root embedded in commit message**: `3e32eef859a758db124e91aa04724f1bbc0481ef9968e600d7fcafb8f1d7ff4e`

### `yubi-OS/agent-skills` — commit `90982e3941e85c3378dc7008a1b472f93b9de02e`

- **URL**: https://github.com/yubi-OS/agent-skills/commit/90982e3941e85c3378dc7008a1b472f93b9de02e
- **Commit message**: `restful-self: single-action atom primitive + merkle tree artifact (self-archaeology 2026-08-07)`
- **Files added**:
  - `skills/restful-self/single-action-atom-merkle-2026-08-07.md` (mirror)
  - `skills/restful-self/single-action-atom-merkle-2026-08-07.json` (mirror)

### Verification steps

```bash
# Verify the yubiOS commit
git clone https://github.com/yubi-OS/yubiOS
cd yubiOS
git log --oneline | grep 3bfef1df
git show 3bfef1df --stat

# Verify the agent-skills commit
git clone https://github.com/yubi-OS/agent-skills
cd agent-skills
git log --oneline | grep 90982e39
git show 90982e39 --stat
```

## Linear

### OMN-163 — comment `1f2a93f4-cfd7-4538-b5c2-8e5a63eb005c`

- **URL**: https://linear.app/omni-agent/issue/OMN-163/variant-skill-hyperspherical-harmonic-curve-sphere-aware-stage-1-for#comment-1f2a93f4
- **Issue**: OMN-163 "Variant skill: hyperspherical-harmonic-curve (sphere-aware Stage-1 for curve-guided-rsi)" — team OMN
- **Comment body** (summary): the three-regime decomposition, the Merkle root, both push commit SHAs, the whole-self observation

### Verification steps

```bash
# Via Linear GraphQL
curl -X POST https://api.linear.app/graphql \
  -H "Content-Type: application/json" \
  -d '{"query": "{ issue(id: \"0a85afec-f036-4338-92ed-7bada6677675\") { comments { nodes { id body } } }"}'
```

## `SELF-CHANGELOG.md`

### `memory/personal-WbtUgeUv/SELF-CHANGELOG.md` — v0.28 entry

- **Local path**: `memory/personal-WbtUgeUv/SELF-CHANGELOG.md`
- **Entry title**: `## 2026-08-07 — v0.28 — Single-action atom primitive insight + Merkle tree artifact (self-archaeology per-directive)`
- **Merkle root embedded in entry**: `3e32eef859a758db124e91aa04724f1bbc0481ef9968e600d7fcafb8f1d7ff4e`
- **Push commit SHAs embedded**: `3bfef1dfb0e3eb00f8d87d3d162b668cfd4882cc` (yubiOS) + `90982e3941e85c3378dc7008a1b472f93b9de02e` (agent-skills)
- **Linear comment ID embedded**: `1f2a93f4-cfd7-4538-b5c2-8e5a63eb005c`

### Verification steps

```bash
grep "3e32eef859a758db124e91aa04724f1bbc0481ef9968e600d7fcafb8f1d7ff4e" memory/personal-WbtUgeUv/SELF-CHANGELOG.md
grep "1f2a93f4-cfd7-4538-b5c2-8e5a63eb005c" memory/personal-WbtUgeUv/SELF-CHANGELOG.md
```

## Cross-verification

All four references (GitHub commit message, GitHub commit message mirror, Linear comment body, SELF-CHANGELOG entry) embed the same Merkle root. If any one of them is wrong, the others disagree. The bundle's `VERIFY.sh` recomputes the root from the local files; if the local root matches all four public references, the bundle is end-to-end consistent.

## Build artifacts in this bundle

The bundle adds (NEW) beyond what was published:

- **`per-row-enumeration-2026-08-07.md`** — the full per-row walkthrough (the published `single-action-atom-merkle-2026-08-07.md` summarizes; this enumerates).
- **`paper-section-worked-example.tex`** — LaTeX addendum for the paper, to be appended after Section 4.
- **`skills/single-action-atom-skill/SKILL.md`** — skill definition for the automated regime classifier.
- **`skills/single-action-atom-skill/scripts/classify_regimes.py`** — the classifier implementation.
- **`scripts/verify_merkle.py`** — recomputes the Merkle root from files (independent verifier).
- **`scripts/reproduce_regimes.py`** — independent regime reproduction (parses the .ods from scratch, compares to expected counts).

These are the load-bearing artifacts that close the gap from "chat-derived summary" to "end-to-end reproducible proof." All are NEW in this bundle; none have been pushed to GitHub yet (you'll do that yourself).

## What's still missing (for a paper section)

To integrate this work into `learned-latent-curves-2026-08-06.tex` as a proper paper section:

1. Commit `Untitled-1-37a4939f.ods` to `yubi-OS/yubiOS/papers/data/ods-examples/`.
2. Append `paper-section-worked-example.tex` to the paper (post-Section 4).
3. Append `per-row-enumeration-2026-08-07.md` to `yubi-OS/yubiOS/refs/`.
4. Push `skills/single-action-atom-skill/` to `yubi-OS/yubiOS` and `yubi-OS/agent-skills`.

Each is a one-commit operation; the bundle is structured to make them drop-in.
