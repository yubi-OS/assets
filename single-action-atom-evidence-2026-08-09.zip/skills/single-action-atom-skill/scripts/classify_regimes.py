#!/usr/bin/env python3
"""
classify_regimes.py — Single-action atom regime classifier.

Parses a ratio spreadsheet (`.ods` or `.csv`) structured as
`(a, b, a*b, 1/n, n)` rows, classifies each row into one of three regimes
(atom-eligible, atom-deferred, atom-refused), and emits a JSON manifest.

Standalone skill implementation. Reproduces the regime classification from
the input bytes alone, without trusting any prior analysis.

Usage:
    python3 classify_regimes.py path/to/spreadsheet.ods [--ladder path/to/ladder.txt] [--output manifest.json]

Standard ladder (used when --ladder not provided):
    {1/32, 1/16, 1/8, 1/4, 1/2, 1, 2, 3, 4, 6, 8, 16, 24, 32, 48, 64, 96, 192, 384}
"""
import argparse
import hashlib
import json
import os
import sys
import zipfile
from fractions import Fraction
from xml.etree import ElementTree as ET

# Standard primitive ladder — the corpus's observed primitive set
DEFAULT_LADDER = [
    Fraction(1, 32), Fraction(1, 16), Fraction(1, 8), Fraction(1, 4),
    Fraction(1, 2), Fraction(1, 1), Fraction(2, 1), Fraction(3, 1),
    Fraction(4, 1), Fraction(6, 1), Fraction(8, 1), Fraction(16, 1),
    Fraction(24, 1), Fraction(32, 1), Fraction(48, 1), Fraction(64, 1),
    Fraction(96, 1), Fraction(192, 1), Fraction(384, 1),
]

# OpenDocument XML namespaces
ODS_NS = {
    "table": "urn:oasis:names:tc:opendocument:xmlns:table:1.0",
    "text": "urn:oasis:names:tc:opendocument:xmlns:text:1.0",
    "office": "urn:oasis:names:tc:opendocument:xmlns:office:1.0",
}


def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(8192), b""):
            h.update(chunk)
    return h.hexdigest()


def parse_ods(path):
    """Parse an OpenDocument Spreadsheet file into a list of rows.
    Each row is a list of cell values (strings or None for empty/spacer cells).
    Handles office:value-type="string" with number-columns-repeated attributes.
    """
    with zipfile.ZipFile(path) as z:
        content = z.read("content.xml")
    root = ET.fromstring(content)
    rows = []
    for table in root.findall(".//table:table", ODS_NS):
        for row in table.findall("table:table-row", ODS_NS):
            row_values = []
            for cell in row.findall("table:table-cell", ODS_NS):
                repeat = cell.get(
                    "{urn:oasis:names:tc:opendocument:xmlns:table:1.0}number-columns-repeated"
                )
                p = cell.find("text:p", ODS_NS)
                value = p.text if p is not None and p.text is not None else ""
                if repeat:
                    row_values.append(value)
                else:
                    row_values.append(value)
            rows.append(row_values)
        break  # only the first table
    return rows


def parse_value(s):
    """Parse a string cell value into a Fraction, or None if not a number."""
    s = s.strip()
    if not s:
        return None
    try:
        return Fraction(s)
    except (ValueError, ZeroDivisionError):
        try:
            return Fraction(float(s)).limit_denominator(10000)
        except (ValueError, ZeroDivisionError):
            return None


def extract_sets_from_row(row_values):
    """Extract (a, b, _, a*b, 1/n, n) tuples from a row.
    Each row may contain up to 3 side-by-side sets; blanks and `[×2]` spacers
    are skipped.
    """
    sets = []
    i = 0
    while i < len(row_values):
        # Try to read a 6-value set starting at position i
        chunk = row_values[i:i + 6]
        if len(chunk) < 6:
            break
        # The 3rd cell (index 2) should be blank for a content row
        if chunk[2].strip() and not chunk[2].strip().startswith("["):
            # Not a content row pattern; advance by 1
            i += 1
            continue
        a = parse_value(chunk[0])
        b = parse_value(chunk[1])
        ab = parse_value(chunk[3])
        one_over_n = parse_value(chunk[4])
        n = parse_value(chunk[5])
        if all(v is not None for v in [a, b, ab, one_over_n, n]):
            sets.append({
                "a": a, "b": b, "ab": ab,
                "1/n": one_over_n, "n": n,
            })
            i += 6
        else:
            i += 1
    return sets


def classify_set(s, ladder):
    """Classify a single (a, b, ab, 1/n, n) tuple into a regime."""
    a, b = s["a"], s["b"]
    # Atom-refused: a == 0, so b/a is undefined
    if a == 0:
        return "refused", "a=0 → b/a undefined (DIV/0!); atom refuses per Lemma 1"
    b_over_a = b / a
    # Atom-eligible: b/a is in the standard ladder
    if b_over_a in ladder:
        return "eligible", f"b/a={b_over_a} in standard ladder; atom acts, Δ_f > 0"
    # Atom-deferred: b/a is defined but outside the standard ladder
    return "deferred", (
        f"b/a={b_over_a} defined but not in standard ladder; "
        f"atom defers until corpus grows (Möbius refinement, Section 3.4)"
    )


def classify_spreadsheet(path, ladder):
    """Classify every set in every row of the spreadsheet."""
    rows = parse_ods(path)
    classifications = []
    counts = {"eligible": 0, "deferred": 0, "refused": 0}
    for row_idx, row_values in enumerate(rows):
        sets = extract_sets_from_row(row_values)
        for set_idx, s in enumerate(sets):
            regime, reason = classify_set(s, ladder)
            counts[regime] += 1
            classifications.append({
                "row": row_idx,
                "set_index": set_idx,
                "a": str(s["a"]),
                "b": str(s["b"]),
                "a*b": str(s["ab"]),
                "1/n": str(s["1/n"]),
                "n": str(s["n"]),
                "regime": regime,
                "reason": reason,
            })
    return classifications, counts


def load_ladder(path):
    """Load a custom ladder from a file (one Fraction per line)."""
    ladder = []
    with open(path) as f:
        for line in f:
            line = line.strip()
            if line and not line.startswith("#"):
                ladder.append(Fraction(line))
    return ladder


def main():
    parser = argparse.ArgumentParser(description="Classify ratio rows into single-action atom regimes.")
    parser.add_argument("input", help="Path to .ods or .csv input file.")
    parser.add_argument("--ladder", help="Optional custom ladder file (one Fraction per line).")
    parser.add_argument("--output", help="Output manifest path (default: stdout).")
    parser.add_argument("--verify-against", help="Compare output to an existing manifest at this path.")
    args = parser.parse_args()

    if not os.path.exists(args.input):
        sys.exit(f"Input file not found: {args.input}")

    ladder = load_ladder(args.ladder) if args.ladder else DEFAULT_LADDER
    classifications, counts = classify_spreadsheet(args.input, ladder)

    manifest = {
        "input_file": args.input,
        "input_sha256": sha256_file(args.input),
        "standard_ladder_used": [str(x) for x in ladder],
        "regime_counts": counts,
        "classifications": classifications,
    }

    if args.verify_against:
        with open(args.verify_against) as f:
            reference = json.load(f)
        ref_counts = reference.get("regime_counts", {})
        if ref_counts != counts:
            sys.exit(
                f"VERIFICATION FAILED: regime counts mismatch.\n"
                f"  Got:      {counts}\n"
                f"  Expected: {ref_counts}"
            )
        manifest["verification"] = {"against": args.verify_against, "result": "PASS"}
        print(f"VERIFICATION PASS: regime counts match reference manifest.")
        print(f"  eligible:  {counts['eligible']}")
        print(f"  deferred:  {counts['deferred']}")
        print(f"  refused:   {counts['refused']}")

    output = json.dumps(manifest, indent=2)
    if args.output:
        with open(args.output, "w") as f:
            f.write(output)
        print(f"Wrote manifest to {args.output}")
    else:
        print(output)


if __name__ == "__main__":
    main()
