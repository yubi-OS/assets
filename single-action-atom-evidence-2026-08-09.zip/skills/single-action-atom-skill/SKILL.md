# Single-Action Atom Skill

Classifies rows of a ratio spreadsheet (e.g., the `Untitled-1-37a4939f.ods` worked example) into the three regimes of the curve-guided RSI framework: **atom-eligible**, **atom-deferred**, **atom-refused**. Reproducible end-to-end from the input file alone.

## When to use

When you have a corpus tabulated as `(a, b, a·b, 1/n, n)` rows and want to know which rows the single-action atom can act on, which it must defer (corpus growth required), and which it refuses (empty coverage).

## When NOT to use

- The input is not in the `(a, b, _, a·b, 1/n, n)` template.
- The input is a per-file coverage matrix rather than a ratio spreadsheet (use `hyperspherical-harmonic-curve` instead — it operates on the 9-D binary coverage vector directly).
- You want to refit $\phi_\theta$ on the corpus (use `hyperspherical-harmonic-curve` — it owns the Möbius refinement).

## Inputs

A single `.ods` or `.csv` file with rows structured as the worked example: at least one column-pair `(a, b)` with derived `(a·b, 1/n, n)`. The skill detects the three-block structure (varying `a` / varying `b` / varying `a` with fixed `n`) automatically.

## Outputs

A JSON manifest at the path you specify, with:

```json
{
  "input_file": "Untitled-1-37a4939f.ods",
  "input_sha256": "<hex>",
  "regime_counts": {"eligible": 13, "deferred": 17, "refused": 4},
  "rows": [
    {"block": 1, "set": "A", "row": 1, "a": "1/32", "b": "1/4", "ab": "1/128", "n": 8, "regime": "eligible", "reason": "..."},
    ...
  ],
  "standard_ladder_used": ["1/32", "1/16", "1/8", "1/4", "1/2", "1", "2", "3", "4", "6", "8", "16", "24", "32", "48", "64", "96", "192", "384"],
  "merkle_root": "<hex>"
}
```

## Algorithm

The classifier (`scripts/classify_regimes.py`) does:

1. **Parse the spreadsheet.** Read every row; identify the three-block structure via spacer-row detection (rows where `n` is empty and `1/n` is empty are spacers).
2. **For each content row, extract `(a, b, a·b, 1/n, n)`** as Python `Fraction` values to avoid floating-point ambiguity.
3. **Check the standard ladder membership** for each of `a`, `b`, `a·b`, `1/n`, `b/a`.
4. **Classify each row into one of three regimes:**
   - **refused**: `b/a` is undefined (i.e., `a == 0`). The atom cannot fire because there's no candidate primitive to flip.
   - **deferred**: `b/a` is defined but lands on a value outside the standard ladder. The atom has a candidate action, but the corpus doesn't yet carry the primitive.
   - **eligible**: `b/a` is in the standard ladder. The atom acts; the per-file contribution $\Delta_{f_i} > 0$.
5. **Emit the manifest** with per-row classification, counts, and the SHA-256 of the input file.

## Standard ladder

The skill uses a fixed standard ladder for "what's in the corpus":

```
{1/32, 1/16, 1/8, 1/4, 1/2, 1, 2, 3, 4, 6, 8, 16, 24, 32, 48, 64, 96, 192, 384}
```

This is the corpus's primitive set as observed across the 79-skill corpus (Section 4 of `learned-latent-curves-2026-08-06.tex`). For a different corpus, override with `--ladder path/to/ladder.txt`.

## Verification

Run the script on the worked-example `.ods` and confirm:

- Regime counts: `{eligible: 13, deferred: 17, refused: 4}` — matches the enumeration at `refs/single-action-atom-per-row-enumeration-2026-08-07.md`.
- SHA-256 of `Untitled-1-37a4939f.ods` matches the leaf hash `36b85eb0da92c9d865a2550026b54d030ba06f431d3e37a45ffa3e7d920f55b3` in the Merkle manifest.

## Operating modes

- **Mode A — Direct classify**: produce the manifest only. Default.
- **Mode B — Classify + recompute Merkle leaf**: include the manifest in a Merkle tree alongside the other leaves (`.ods`, paper TeX, insight, regimes, whole-self). Use this when generating a fresh evidence bundle.
- **Mode C — Classify + verify against published manifest**: compare the classification output to a known manifest; reject if any row disagrees. Use this when auditing an existing claim.

## Anti-patterns

- **Don't override the standard ladder silently.** If a row's `b/a` is outside the corpus's primitives, that's signal — it's an atom-deferred row, not a bug.
- **Don't classify `a == 0` as deferred.** It's refused. The distinction matters because Lemma 1 doesn't fire on refusal (no candidate exists).
- **Don't trust the chat-derived summary.** Always run the script. The chat summary approximated the count; the script gives the exact map.

## Pair with

- `hyperspherical-harmonic-curve` — owns the Möbius refinement strategy (Section 3.4) that responds to the deferred regime by re-fitting $\phi_\theta$.
- `recursive-self-improvement` — bounded loop discipline for the RSI cycle that consumes the regime classification.

## Empirical validation

On `data/Untitled-1-37a4939f.ods`:
- 34 content rows → 13 eligible + 17 deferred + 4 refused.
- Total: 13 + 17 + 4 = 34. ✓
- The 4 refused rows are exactly Block 3 rows 33-36 (a=0).
- The 17 deferred rows are exactly Block 1 rows where $1/n$ is outside Set B/C's col1 ladder (4 rows) + Block 2 rows where $b/a$ is outside the standard ladder (13 rows).
- The 13 eligible rows are the complement.

## Maintainer

Sauna. Built 2026-08-09 per Jenny's directive to close the gap in `single-action-atom-merkle-2026-08-07.md`. Operates on any `.ods` file matching the worked-example schema.
